variable "aws_region" {
  description = "AWS region where the Databricks workspace will be created."
  type        = string
}

variable "databricks_account_id" {
  description = "Databricks account ID."
  type        = string
}

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID used in S3 bucket policy principal."
  type        = string
}

variable "databricks_cross_account_role_arn" {
  description = "Optional Databricks cross-account IAM role ARN for EBS KMS usage."
  type        = string
  default     = null
}

variable "name_prefix" {
  description = "Prefix for resource names."
  type        = string
}

variable "workspace_name" {
  description = "Name for the new Databricks workspace."
  type        = string
}

variable "workspace_root_bucket_name" {
  description = "S3 bucket name used for Databricks workspace root storage configuration."
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace."
  type        = string
}

variable "private_access_settings_id" {
  description = "Optional MWS private access settings ID (from databricks_mws_private_access_settings or the account console). When set, attaches PrivateLink / private connectivity policy to the new workspace."
  type        = string
  default     = null
}

variable "force_destroy_buckets" {
  description = "Whether Terraform can delete non-empty S3 buckets on destroy."
  type        = bool
  default     = false
}

variable "enable_network_connectivity_config" {
  description = "Create an MWS Network Connectivity Config (NCC) and bind it to the serverless workspace for egress / private endpoint rules."
  type        = bool
  default     = false
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name for the NLB private endpoint rule when ncc_nlb_domain_names is non-empty. May be (known after apply). See mws-network-connectivity-config module."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs for the NCC private endpoint rule; non-empty list creates the rule (service name can resolve at apply time)."
  type        = list(string)
  default     = []
}
