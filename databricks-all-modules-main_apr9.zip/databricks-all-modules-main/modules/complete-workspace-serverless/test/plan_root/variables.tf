# Variables passed through to module "../.." for terratest plan-only checks.

variable "aws_region" {
  type = string
}

variable "databricks_account_id" {
  type = string
}

variable "databricks_aws_account_id" {
  type = string
}

variable "name_prefix" {
  type = string
}

variable "workspace_name" {
  type = string
}

variable "workspace_root_bucket_name" {
  type = string
}

variable "existing_metastore_name" {
  type = string
}

variable "force_destroy_buckets" {
  type    = bool
  default = false
}

variable "private_access_settings_id" {
  type     = string
  nullable = true
  default  = null
}

variable "databricks_cross_account_role_arn" {
  type     = string
  nullable = true
  default  = null
}

variable "enable_network_connectivity_config" {
  type    = bool
  default = false
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  type     = string
  nullable = true
  default  = null
}

variable "ncc_nlb_domain_names" {
  type    = list(string)
  default = []
}
