# Root module for Go terratest: supplies AWS + MWS Databricks providers required by ../..
terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.80.0"
    }
  }
}

provider "aws" {
  region = var.aws_region
}

provider "databricks" {
  alias      = "mws"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

module "serverless" {
  source = "../.."

  providers = {
    databricks.mws = databricks.mws
  }

  aws_region                         = var.aws_region
  databricks_account_id              = var.databricks_account_id
  databricks_aws_account_id          = var.databricks_aws_account_id
  name_prefix                        = var.name_prefix
  workspace_name                     = var.workspace_name
  workspace_root_bucket_name         = var.workspace_root_bucket_name
  existing_metastore_name            = var.existing_metastore_name
  force_destroy_buckets              = var.force_destroy_buckets
  private_access_settings_id         = var.private_access_settings_id
  databricks_cross_account_role_arn  = var.databricks_cross_account_role_arn
  enable_network_connectivity_config = var.enable_network_connectivity_config
  ncc_nlb_vpc_endpoint_service_name  = var.ncc_nlb_vpc_endpoint_service_name
  ncc_nlb_domain_names               = var.ncc_nlb_domain_names
}
