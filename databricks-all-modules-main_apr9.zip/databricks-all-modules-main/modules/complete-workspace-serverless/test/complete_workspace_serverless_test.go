package test

import (
	"path/filepath"
	"regexp"
	"runtime"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// planRootDir is the terratest root that wires providers for the parent module (../..).
func planRootDir() string {
	_, file, _, _ := runtime.Caller(0)
	return filepath.Join(filepath.Dir(file), "plan_root")
}

func baseServerlessPlanVars(t *testing.T, suffix string) map[string]interface{} {
	t.Helper()
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID(suffix)
	bucket := "terratest-plan-" + uniqueID
	if len(bucket) > 63 {
		bucket = bucket[:63]
	}
	// NCC child name is "${name_prefix}-ncc" and must stay within API max length (30).
	return map[string]interface{}{
		"aws_region":                 defaults.AWSRegion,
		"databricks_account_id":      defaults.AccountID,
		"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
		"name_prefix":                "tt-" + suffix,
		"workspace_name":             uniqueID,
		"workspace_root_bucket_name": bucket,
		"existing_metastore_name":    "yankaiz-us-east-1",
		"force_destroy_buckets":      false,
	}
}

func mergeVars(base map[string]interface{}, extra map[string]interface{}) map[string]interface{} {
	out := make(map[string]interface{}, len(base)+len(extra))
	for k, v := range base {
		out[k] = v
	}
	for k, v := range extra {
		out[k] = v
	}
	return out
}

func TestCompleteWorkspaceServerlessModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-ws")
	workspaceName := uniqueID
	bucketName := "terratest-serverless-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates complete workspace serverless module inputs (parameter-only)",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                         defaults.AWSRegion,
			"name_prefix":                        "terratest-serverless",
			"existing_metastore_name":            "yankaiz-us-east-1",
			"force_destroy_buckets":              false,
			"enable_network_connectivity_config": false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateOptionalInputs", func(t *testing.T) {
		assert.Equal(t, defaults.AccountID, opts.Vars["databricks_account_id"])
		assert.Equal(t, defaults.AWSRegion, opts.Vars["aws_region"])
		assert.Equal(t, "terratest-serverless", opts.Vars["name_prefix"])
		assert.Equal(t, "yankaiz-us-east-1", opts.Vars["existing_metastore_name"])
		assert.Equal(t, false, opts.Vars["force_destroy_buckets"])
		assert.Equal(t, false, opts.Vars["enable_network_connectivity_config"])
		_, hasPAS := opts.Vars["private_access_settings_id"]
		assert.False(t, hasPAS, "default config should omit private_access_settings_id (null in module)")
		t.Log("All optional inputs validated")
	})
}

func TestCompleteWorkspaceServerlessModuleMinimal(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-min")
	workspaceName := uniqueID
	bucketName := "terratest-min-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates minimal complete workspace serverless inputs",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                         defaults.AWSRegion,
			"name_prefix":                        "terratest-serverless-min",
			"existing_metastore_name":            "yankaiz-us-east-1",
			"force_destroy_buckets":              false,
			"enable_network_connectivity_config": false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateMinimalConfig", func(t *testing.T) {
		assert.Equal(t, defaults.AWSRegion, opts.Vars["aws_region"])
		assert.Equal(t, "terratest-serverless-min", opts.Vars["name_prefix"])
		assert.Equal(t, "yankaiz-us-east-1", opts.Vars["existing_metastore_name"])
		assert.Equal(t, false, opts.Vars["force_destroy_buckets"])
		assert.Equal(t, false, opts.Vars["enable_network_connectivity_config"])
		t.Log("Minimal configuration validated")
	})
}

func TestCompleteWorkspaceServerlessModuleWithCrossAccountRole(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-ebs")
	workspaceName := uniqueID
	bucketName := "terratest-ebs-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates serverless workspace with cross-account EBS role",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                         defaults.AWSRegion,
			"name_prefix":                        "terratest-serverless-ebs",
			"existing_metastore_name":            "yankaiz-us-east-1",
			"databricks_cross_account_role_arn":  defaults.RoleARN,
			"force_destroy_buckets":              false,
			"enable_network_connectivity_config": false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateCrossAccountRole", func(t *testing.T) {
		assert.NotNil(t, opts.Vars["databricks_cross_account_role_arn"])
		assert.Equal(t, false, opts.Vars["enable_network_connectivity_config"])
		t.Log("Cross-account role configuration validated")
	})
}

func TestCompleteWorkspaceServerlessModuleWithPrivateAccessSettings(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-pas")
	workspaceName := uniqueID
	bucketName := "terratest-pas-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	pasID := common.GetEnvOrDefault("TEST_PRIVATE_ACCESS_SETTINGS_ID", "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates optional private_access_settings_id for MWS workspace PrivateLink policy",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                   defaults.AWSRegion,
			"name_prefix":                  "terratest-serverless-pas",
			"existing_metastore_name":      "yankaiz-us-east-1",
			"force_destroy_buckets":        false,
			"private_access_settings_id":   pasID,
			"enable_network_connectivity_config": false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidatePrivateAccessSettingsPassthrough", func(t *testing.T) {
		assert.Equal(t, pasID, opts.Vars["private_access_settings_id"])
		t.Log("private_access_settings_id passthrough validated")
	})
}

func TestCompleteWorkspaceServerlessModuleWithNetworkConnectivityConfig(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-ncc")
	workspaceName := uniqueID
	bucketName := "terratest-ncc-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates serverless workspace with MWS NCC module and binding enabled",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                         defaults.AWSRegion,
			"name_prefix":                        "terratest-serverless-ncc",
			"existing_metastore_name":            "yankaiz-us-east-1",
			"force_destroy_buckets":              false,
			"enable_network_connectivity_config": true,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateNetworkConnectivityInputs", func(t *testing.T) {
		assert.Equal(t, true, opts.Vars["enable_network_connectivity_config"])
		assert.Equal(t, "terratest-serverless-ncc", opts.Vars["name_prefix"])
		_, hasNLBService := opts.Vars["ncc_nlb_vpc_endpoint_service_name"]
		assert.False(t, hasNLBService, "NCC-only mode leaves ncc_nlb_vpc_endpoint_service_name unset")
		domains, hasDomains := opts.Vars["ncc_nlb_domain_names"]
		if hasDomains {
			assert.Equal(t, []string(nil), domains)
		}
		t.Log("NCC-enabled configuration validated")
	})
}

func TestCompleteWorkspaceServerlessModuleNetworkConnectivityWithNLBPassthrough(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-ncc-nlb")
	workspaceName := uniqueID
	bucketName := "terratest-nccnlb-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates NCC with NLB private endpoint rule variables passed to child module",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                         defaults.AWSRegion,
			"name_prefix":                        "terratest-serverless-ncc-nlb",
			"existing_metastore_name":            "yankaiz-us-east-1",
			"force_destroy_buckets":              false,
			"enable_network_connectivity_config": true,
			"ncc_nlb_vpc_endpoint_service_name":  "com.amazonaws.vpce." + defaults.AWSRegion + ".vpce-svc-planonly00000000",
			"ncc_nlb_domain_names":               []string{"internal.plan-only.example.com"},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateNLBPassthrough", func(t *testing.T) {
		assert.Equal(t, true, opts.Vars["enable_network_connectivity_config"])
		assert.Contains(t, opts.Vars["ncc_nlb_vpc_endpoint_service_name"], "vpce-svc-")
		domains, ok := opts.Vars["ncc_nlb_domain_names"].([]string)
		require.True(t, ok)
		assert.Equal(t, []string{"internal.plan-only.example.com"}, domains)
		t.Log("NLB passthrough variables validated")
	})
}

func TestCompleteWorkspaceServerlessModuleTerraformPlan(t *testing.T) {
	common.SkipIfShortMode(t, "complete-workspace-serverless terraform plan (MWS + AWS)")
	common.RequireDatabricksEnv(t)

	vars := baseServerlessPlanVars(t, "plan-base")
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: planRootDir(),
		Vars:         vars,
		NoColor:      true,
	})

	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Contains(t, plan, "module.serverless.databricks_mws_workspaces.this")
	assert.Contains(t, plan, "compute_mode")
	assert.Contains(t, plan, "SERVERLESS")
	assert.NotContains(t, plan, "module.serverless.databricks_mws_ncc_binding.this[0]",
		"when enable_network_connectivity_config is false, NCC binding must not be in plan")
	t.Log("Baseline serverless plan validated")
}

func TestCompleteWorkspaceServerlessModuleTerraformPlanWithNCCAndNLB(t *testing.T) {
	common.SkipIfShortMode(t, "complete-workspace-serverless NCC + NLB terraform plan")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	vars := mergeVars(baseServerlessPlanVars(t, "plan-ncc-nlb"), map[string]interface{}{
		"enable_network_connectivity_config": true,
		"ncc_nlb_vpc_endpoint_service_name":  "com.amazonaws.vpce." + defaults.AWSRegion + ".vpce-svc-planonly00000000",
		"ncc_nlb_domain_names":               []string{"internal.plan-only.example.com"},
	})

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: planRootDir(),
		Vars:         vars,
		NoColor:      true,
	})

	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Contains(t, plan, "module.serverless.module.network_connectivity_config[0].databricks_mws_network_connectivity_config.this")
	assert.Contains(t, plan, "module.serverless.module.network_connectivity_config[0].databricks_mws_ncc_private_endpoint_rule.nlb[0]")
	assert.Contains(t, plan, "module.serverless.databricks_mws_ncc_binding.this[0]")
	assert.Contains(t, plan, "internal.plan-only.example.com")
	t.Log("NCC + NLB private endpoint rule plan validated")
}

func TestCompleteWorkspaceServerlessModuleTerraformPlanWithPrivateAccessSettings(t *testing.T) {
	common.SkipIfShortMode(t, "complete-workspace-serverless plan with private_access_settings_id")
	common.RequireDatabricksEnv(t)

	pasID := common.GetEnvOrDefault("TEST_PRIVATE_ACCESS_SETTINGS_ID", "aaaaaaaa-bbbb-cccc-dddd-eeeeeeeeeeee")
	vars := mergeVars(baseServerlessPlanVars(t, "plan-pas"), map[string]interface{}{
		"private_access_settings_id": pasID,
	})

	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: planRootDir(),
		Vars:         vars,
		NoColor:      true,
	})

	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	// Terraform plan renders quoted strings: private_access_settings_id = "uuid"
	pasRe := regexp.MustCompile(regexp.QuoteMeta("private_access_settings_id") + `\s*=\s*"` + regexp.QuoteMeta(pasID) + `"`)
	assert.Regexp(t, pasRe, plan,
		"MWS workspace must receive private_access_settings_id for PrivateLink / PAS attachment")
	t.Log("private_access_settings_id plan validated")
}
