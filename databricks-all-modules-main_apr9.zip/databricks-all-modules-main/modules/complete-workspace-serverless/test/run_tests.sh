#!/bin/bash
# Run complete-workspace-serverless tests with env vars from the repo secrets file.
# Input-only tests always run; Terraform plan tests need fresh AWS credentials (STS)
# and DATABRICKS_* (see common.RequireDatabricksEnv). Skip plan tests with:
#   go test -short -run 'TestCompleteWorkspaceServerless' ./...
# Usage: from repo root: ./modules/complete-workspace-serverless/test/run_tests.sh
#        or from this dir: ./run_tests.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
SECRETS="$REPO_ROOT/secrets"

if [ -f "$SECRETS" ]; then
  echo "Sourcing secrets from $SECRETS"
  # shellcheck source=/dev/null
  source "$SECRETS"
fi

cd "$SCRIPT_DIR"
go test -v -run 'TestCompleteWorkspaceServerless' -timeout 10m -count=1 .
