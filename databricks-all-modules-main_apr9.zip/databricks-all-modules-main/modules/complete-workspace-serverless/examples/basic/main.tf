# =============================================================================
# Complete Databricks Serverless Workspace - Example
# =============================================================================
# This example runs the complete-workspace-serverless module with variables
# supplied via terraform.tfvars (copy terraform.tfvars.example to terraform.tfvars
# and set your Databricks account ID, OAuth credentials, workspace name, and
# S3 bucket name).
#
# The module creates:
#   - S3 bucket for workspace root (with KMS, versioning, bucket policy)
#   - MWS storage configuration, customer-managed keys (storage + managed services)
#   - MWS serverless workspace (optional private_access_settings_id for PrivateLink)
#   - Optional dedicated VPC + internal NLB + VPC endpoint service + private
#     Route53 zone when create_internal_nlb_vpc_endpoint is true; values are
#     passed into the module for the NCC private endpoint rule
#   - Optional MWS Network Connectivity Config (NCC) and workspace binding when
#     enable_network_connectivity_config is true or NLB stack is created
#   - Metastore assignment to an existing Unity Catalog metastore
#   - Optional inbound PrivateLink (steps 1–3) when create_inbound_privatelink is true:
#     transit VPC, Workspace API interface endpoint, MWS VPC endpoint registration, PAS module, workspace attachment
#     https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
# =============================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.80.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Providers
# -----------------------------------------------------------------------------
provider "aws" {
  region = var.aws_region
}

provider "databricks" {
  alias      = "mws"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

# -----------------------------------------------------------------------------
# Module
# -----------------------------------------------------------------------------
module "complete_workspace_serverless" {
  source = "../.."

  providers = {
    databricks.mws = databricks.mws
  }

  aws_region                 = var.aws_region
  databricks_account_id      = var.databricks_account_id
  databricks_aws_account_id  = var.databricks_aws_account_id
  name_prefix                = var.name_prefix
  workspace_name             = var.workspace_name
  workspace_root_bucket_name = var.workspace_root_bucket_name
  existing_metastore_name    = var.existing_metastore_name
  private_access_settings_id = (
    var.create_inbound_privatelink
    ? module.inbound_private_access_settings[0].private_access_settings_id
    : var.private_access_settings_id
  )
  force_destroy_buckets              = var.force_destroy_buckets
  databricks_cross_account_role_arn  = var.databricks_cross_account_role_arn
  enable_network_connectivity_config = local.ncc_enabled
  ncc_nlb_vpc_endpoint_service_name  = local.nlb_service_name_for_module
  ncc_nlb_domain_names               = local.nlb_domain_names_for_module

  # Explicit ordering: PAS and NLB / VPC endpoint service must exist before the
  # serverless module (workspace + optional NCC) when those stacks are enabled.
  # time_sleep runs a destroy-phase wait (see nlb_vpc_endpoint.tf) so Databricks
  # can drop interface endpoints before aws_vpc_endpoint_service is deleted.
  # Counted resources/modules with count = 0 are valid here (no-op dependency).
  depends_on = [
    module.inbound_private_access_settings,
    module.nlb_vpc,
    aws_vpc_endpoint_service.ncc_nlb,
    time_sleep.nlb_endpoint_service_destroy_grace,
  ]
}

# -----------------------------------------------------------------------------
# Outputs
# -----------------------------------------------------------------------------
output "workspace_id" {
  description = "Created Databricks serverless workspace ID."
  value       = module.complete_workspace_serverless.workspace_id
}

output "workspace_url" {
  description = "Created Databricks workspace URL."
  value       = module.complete_workspace_serverless.workspace_url
}

output "private_access_settings_id" {
  description = "MWS private access settings ID attached to the workspace (created by this example when create_inbound_privatelink is true, else from var.private_access_settings_id)."
  value       = module.complete_workspace_serverless.private_access_settings_id
}

output "storage_configuration_id" {
  description = "Databricks account storage configuration ID."
  value       = module.complete_workspace_serverless.storage_configuration_id
}

output "kms_key_arn" {
  description = "AWS KMS key ARN used for workspace encryption."
  value       = module.complete_workspace_serverless.kms_key_arn
}

output "metastore_id" {
  description = "Assigned Unity Catalog metastore ID."
  value       = module.complete_workspace_serverless.metastore_id
}

output "network_connectivity_config_id" {
  description = "MWS Network Connectivity Config ID when enable_network_connectivity_config is true."
  value       = module.complete_workspace_serverless.network_connectivity_config_id
}

output "ncc_egress_config" {
  description = "Computed NCC egress rules when NCC is enabled."
  value       = module.complete_workspace_serverless.ncc_egress_config
}

output "ncc_nlb_private_endpoint_rule_id" {
  description = "NLB private endpoint rule ID when NLB variables are set and NCC is enabled."
  value       = module.complete_workspace_serverless.ncc_nlb_private_endpoint_rule_id
}

output "nlb_vpc_id" {
  description = "VPC ID for the internal NLB when create_internal_nlb_vpc_endpoint is true."
  value       = try(module.nlb_vpc[0].vpc_id, null)
}

output "internal_nlb_dns_name" {
  description = "DNS name of the internal NLB when create_internal_nlb_vpc_endpoint is true."
  value       = try(aws_lb.ncc_nlb[0].dns_name, null)
}

output "nlb_vpc_endpoint_service_name" {
  description = "AWS VPC endpoint service name for the NLB (passed to the Databricks NCC rule) when create_internal_nlb_vpc_endpoint is true."
  value       = try(aws_vpc_endpoint_service.ncc_nlb[0].service_name, null)
}

output "nlb_private_dns_fqdns" {
  description = "FQDNs used for the NCC private endpoint rule when the example creates Route53 records."
  value       = var.create_internal_nlb_vpc_endpoint ? local.nlb_domain_names_for_module : []
}

# -----------------------------------------------------------------------------
# Inbound PrivateLink (steps 1–3)
# -----------------------------------------------------------------------------
output "inbound_privatelink_private_access_settings_id" {
  description = "Private access settings ID created by mws-private-access-settings when create_inbound_privatelink is true (also passed to the serverless workspace)."
  value       = try(module.inbound_private_access_settings[0].private_access_settings_id, null)
}

output "inbound_privatelink_vpc_id" {
  description = "Transit VPC ID when create_inbound_privatelink is true."
  value       = try(module.inbound_privatelink_vpc[0].vpc_id, null)
}

output "inbound_privatelink_vpc_endpoint_id" {
  description = "AWS interface VPC endpoint ID for Databricks Workspace (REST API) when create_inbound_privatelink is true."
  value       = try(aws_vpc_endpoint.inbound_databricks_workspace[0].id, null)
}

output "inbound_privatelink_mws_vpc_endpoint_id" {
  description = "Databricks MWS VPC endpoint registration ID when create_inbound_privatelink is true."
  value       = try(databricks_mws_vpc_endpoint.inbound_workspace_api[0].vpc_endpoint_id, null)
}

output "inbound_privatelink_mws_vpc_endpoint_name" {
  description = "Databricks-registered name for the inbound workspace API endpoint."
  value       = try(databricks_mws_vpc_endpoint.inbound_workspace_api[0].vpc_endpoint_name, null)
}
