# =============================================================================
# Inbound PrivateLink — Databricks docs steps 1 and 2
# =============================================================================
# https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
#
# Step 1: Create an interface VPC endpoint in your transit VPC to the Databricks
#         service labeled "Workspace (including REST API)" (PrivateLink VPC
#         endpoint services table in Databricks docs).
# Step 2: Register the AWS VPC endpoint in the Databricks account console path
#         Cloud resources → Network → VPC endpoint registrations; here via
#         databricks_mws_vpc_endpoint.
#
# Step 3: Private access settings (mws-private-access-settings module) — created
#         here when create_inbound_privatelink is true; wired to the workspace.
# Steps 4–5: Workspace uses PAS via complete-workspace-serverless; configure DNS
#            per https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
# Enterprise plan and correct IAM permissions are required.
# =============================================================================

data "aws_caller_identity" "current" {}

locals {
  # "Workspace (including REST API)" — align with Databricks PrivateLink docs / complete-workspace-custom example.
  inbound_pl_workspace_api_services = {
    "ap-northeast-1" = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02691fd610d24fd64"
    "ap-northeast-2" = "com.amazonaws.vpce.ap-northeast-2.vpce-svc-0babb9bde64f34d7e"
    "ap-south-1"     = "com.amazonaws.vpce.ap-south-1.vpce-svc-0dbfe5d9ee18d6411"
    "ap-southeast-1" = "com.amazonaws.vpce.ap-southeast-1.vpce-svc-02535b257fc253ff4"
    "ap-southeast-2" = "com.amazonaws.vpce.ap-southeast-2.vpce-svc-0b87155ddd6954974"
    "eu-central-1"   = "com.amazonaws.vpce.eu-central-1.vpce-svc-081f78503812597f7"
    "eu-west-1"      = "com.amazonaws.vpce.eu-west-1.vpce-svc-0da6ebf1461278016"
    "eu-west-2"      = "com.amazonaws.vpce.eu-west-2.vpce-svc-01148c7cdc1d1326c"
    "us-east-1"      = "com.amazonaws.vpce.us-east-1.vpce-svc-09143d1e626de2f04"
    "us-east-2"      = "com.amazonaws.vpce.us-east-2.vpce-svc-041dc2b4d7796b8d3"
    "us-west-1"      = "com.amazonaws.vpce.us-west-1.vpce-svc-09bb6ca26208063f2"
    "us-west-2"      = "com.amazonaws.vpce.us-west-2.vpce-svc-0129f463fcfbc46c5"
  }

  inbound_pl_workspace_service_name = coalesce(
    var.inbound_privatelink_workspace_service_name,
    lookup(local.inbound_pl_workspace_api_services, var.aws_region, null)
  )
}

check "inbound_privatelink_workspace_service" {
  assert {
    condition     = !var.create_inbound_privatelink || local.inbound_pl_workspace_service_name != null
    error_message = "When create_inbound_privatelink is true, set inbound_privatelink_workspace_service_name or use an aws_region present in inbound_pl_workspace_api_services (see Databricks PrivateLink VPC endpoint services documentation)."
  }
}

check "inbound_privatelink_no_manual_pas" {
  assert {
    condition     = !var.create_inbound_privatelink || var.private_access_settings_id == null
    error_message = "When create_inbound_privatelink is true, leave private_access_settings_id unset; this example creates PAS (step 3) and attaches it to the workspace."
  }
}

module "inbound_privatelink_vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"
  count   = var.create_inbound_privatelink ? 1 : 0

  name = substr(replace("${var.name_prefix}-${local.dns_safe_workspace}-ipl", "_", "-"), 0, 32)
  cidr = var.inbound_privatelink_vpc_cidr

  azs             = slice(data.aws_availability_zones.available.names, 0, 2)
  private_subnets = [cidrsubnet(var.inbound_privatelink_vpc_cidr, 8, 1), cidrsubnet(var.inbound_privatelink_vpc_cidr, 8, 2)]

  create_igw           = false
  enable_nat_gateway   = false
  single_nat_gateway   = false
  enable_dns_hostnames = true
  enable_dns_support   = true

  tags = {
    Name        = "${var.name_prefix}-inbound-pl-transit"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_security_group" "inbound_privatelink" {
  count = var.create_inbound_privatelink ? 1 : 0

  name        = substr(replace("${var.name_prefix}-${local.dns_safe_workspace}-ipl-sg", "_", "-"), 0, 255)
  description = "HTTPS to Databricks Workspace (REST API) PrivateLink endpoint"
  vpc_id      = module.inbound_privatelink_vpc[0].vpc_id

  ingress {
    from_port = 443
    to_port   = 443
    protocol  = "tcp"
    cidr_blocks = coalesce(
      var.inbound_privatelink_https_ingress_cidr_blocks,
      [module.inbound_privatelink_vpc[0].vpc_cidr_block]
    )
    description = "Allow clients that can reach this VPC to use the inbound endpoint (tighten to corp CIDRs in production)"
  }

  egress {
    from_port   = 0
    to_port     = 0
    protocol    = "-1"
    cidr_blocks = ["0.0.0.0/0"]
  }

  lifecycle {
    create_before_destroy = true
  }

  tags = {
    Name        = "${var.name_prefix}-inbound-pl-sg"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_vpc_endpoint" "inbound_databricks_workspace" {
  count = var.create_inbound_privatelink ? 1 : 0

  vpc_id              = module.inbound_privatelink_vpc[0].vpc_id
  service_name        = local.inbound_pl_workspace_service_name
  vpc_endpoint_type   = "Interface"
  subnet_ids          = module.inbound_privatelink_vpc[0].private_subnets
  security_group_ids  = [aws_security_group.inbound_privatelink[0].id]
  private_dns_enabled = true

  tags = {
    Name        = substr(replace("${var.name_prefix}-${var.aws_region}-inbound-ws-vpce", "_", "-"), 0, 256)
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "databricks_mws_vpc_endpoint" "inbound_workspace_api" {
  provider = databricks.mws
  count    = var.create_inbound_privatelink ? 1 : 0

  account_id          = var.databricks_account_id
  vpc_endpoint_name   = "${var.name_prefix}-${var.aws_region}-inbound-workspace-rest"
  region              = var.aws_region
  aws_vpc_endpoint_id = aws_vpc_endpoint.inbound_databricks_workspace[0].id
  aws_account_id      = data.aws_caller_identity.current.account_id

  depends_on = [aws_vpc_endpoint.inbound_databricks_workspace]
}

# Step 3: Private access settings (Databricks account console: Security → Private access settings)
module "inbound_private_access_settings" {
  source = "../../../mws-private-access-settings"
  count  = var.create_inbound_privatelink ? 1 : 0

  private_access_settings_name = coalesce(
    var.inbound_privatelink_private_access_settings_name,
    substr(replace("${var.name_prefix}-${local.dns_safe_workspace}-pas", "_", "-"), 0, 256)
  )
  region = var.aws_region

  private_access_level = var.inbound_privatelink_private_access_level
  allowed_vpc_endpoint_ids = (
    var.inbound_privatelink_private_access_level == "ENDPOINT"
    ? [databricks_mws_vpc_endpoint.inbound_workspace_api[0].vpc_endpoint_id]
    : null
  )

  depends_on = [databricks_mws_vpc_endpoint.inbound_workspace_api]
}
