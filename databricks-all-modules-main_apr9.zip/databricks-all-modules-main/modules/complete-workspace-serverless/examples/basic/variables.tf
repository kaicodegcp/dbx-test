# =============================================================================
# Example variables for complete-workspace-serverless
# Set these in terraform.tfvars (copy from terraform.tfvars.example).
# The module requires aws_region, name_prefix, and existing_metastore_name
# (no defaults in module); this example provides defaults for convenience.
# =============================================================================

variable "databricks_account_id" {
  description = "Databricks account ID."
  type        = string
}

# Client ID and secret for Databricks provider come from env (e.g. source secrets file: DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET)

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID (used in S3 bucket policy principal)."
  type        = string
}

variable "aws_region" {
  description = "AWS region where the workspace and S3 bucket will be created."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  description = "Prefix for resource names (e.g. MWS storage config, KMS alias)."
  type        = string
  default     = "serverless-ncc-example"
}

variable "workspace_name" {
  description = "Name for the new Databricks serverless workspace."
  type        = string
}

variable "workspace_root_bucket_name" {
  description = "S3 bucket name for the workspace root storage configuration. Must be globally unique."
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace."
  type        = string
  default     = "yankaiz-us-east-1"
}

variable "private_access_settings_id" {
  description = "Optional MWS private access settings ID for PrivateLink when create_inbound_privatelink is false. When create_inbound_privatelink is true, leave null (the example creates PAS via mws-private-access-settings)."
  type        = string
  default     = null
}

variable "force_destroy_buckets" {
  description = "Allow Terraform to delete non-empty S3 buckets on destroy (use with caution)."
  type        = bool
  default     = true
}

variable "databricks_cross_account_role_arn" {
  description = "Optional Databricks cross-account IAM role ARN for EBS KMS (leave null if not using)."
  type        = string
  default     = null
}

variable "enable_network_connectivity_config" {
  description = "Create an MWS Network Connectivity Config and bind it to the serverless workspace. Implied true when create_internal_nlb_vpc_endpoint is true."
  type        = bool
  default     = false
}

variable "create_internal_nlb_vpc_endpoint" {
  description = "Create a dedicated VPC, internal NLB, VPC endpoint service, and private Route53 zone; pass service name and FQDNs into the module for the NCC private endpoint rule."
  type        = bool
  default     = false
}

variable "nlb_vpc_endpoint_service_destroy_wait_duration" {
  description = "Destroy-phase delay (hashicorp/time format, e.g. 600s, 15m) after the serverless module is destroyed and before deleting the NLB VPC endpoint service, so Databricks can release interface endpoint connections. Only applies when create_internal_nlb_vpc_endpoint is true."
  type        = string
  default     = "600s"
}

variable "nlb_vpc_cidr" {
  description = "IPv4 CIDR for the NLB VPC (only used when create_internal_nlb_vpc_endpoint is true)."
  type        = string
  default     = "10.48.0.0/16"
}

variable "nlb_vpc_endpoint_allowed_principal_arns" {
  description = "IAM principal ARNs allowed to create interface VPC endpoints to the NLB service. Defaults to the Databricks private connectivity role for aws_region."
  type        = list(string)
  default     = null
}

variable "ncc_nlb_vpc_endpoint_service_name" {
  description = "Optional VPC endpoint service name when not using create_internal_nlb_vpc_endpoint (use with ncc_nlb_domain_names and enable_network_connectivity_config)."
  type        = string
  default     = null
}

variable "ncc_nlb_domain_names" {
  description = "FQDNs for the NCC private endpoint rule. When create_internal_nlb_vpc_endpoint is true and this is empty, defaults to [\"api.<workspace>.internal\"] (underscores in workspace_name become hyphens)."
  type        = list(string)
  default     = []
}

# -----------------------------------------------------------------------------
# Inbound PrivateLink (Databricks docs steps 1–3)
# https://docs.databricks.com/aws/en/security/network/front-end/front-end-private-connect
# -----------------------------------------------------------------------------

variable "create_inbound_privatelink" {
  description = "When true, runs steps 1–3: transit VPC + Workspace (REST API) interface endpoint + MWS VPC endpoint registration + private access settings (mws-private-access-settings), and passes PAS to the serverless workspace. Do not set private_access_settings_id. DNS (step 5) remains manual."
  type        = bool
  default     = false
}

variable "inbound_privatelink_vpc_cidr" {
  description = "IPv4 CIDR for the inbound PrivateLink transit VPC when create_inbound_privatelink is true."
  type        = string
  default     = "10.49.0.0/16"
}

variable "inbound_privatelink_workspace_service_name" {
  description = "Override for the AWS endpoint service name (Workspace including REST API). When null, uses the built-in map for aws_region; if your region is missing, set this from the Databricks PrivateLink VPC endpoint services table."
  type        = string
  default     = null
}

variable "inbound_privatelink_https_ingress_cidr_blocks" {
  description = "CIDRs allowed to connect to the interface endpoint on TCP 443. When null, defaults to the transit VPC CIDR only; add on-premises or TGW-connected ranges as needed."
  type        = list(string)
  default     = null
}

variable "inbound_privatelink_private_access_settings_name" {
  description = "Name for the private access settings object (step 3). When null, defaults to \"<name_prefix>-<workspace>-pas\"."
  type        = string
  default     = null
}

variable "inbound_privatelink_private_access_level" {
  description = "Private access level for step 3: ENDPOINT restricts to the inbound MWS VPC endpoint registration; ACCOUNT allows any VPC endpoint registered in the Databricks account."
  type        = string
  default     = "ENDPOINT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.inbound_privatelink_private_access_level)
    error_message = "inbound_privatelink_private_access_level must be ACCOUNT or ENDPOINT."
  }
}
