output "workspace_id" {
  description = "Created Databricks workspace ID."
  value       = databricks_mws_workspaces.this.workspace_id
}

output "workspace_url" {
  description = "Created Databricks workspace URL."
  value       = databricks_mws_workspaces.this.workspace_url
}

output "private_access_settings_id" {
  description = "MWS private access settings ID on the workspace (same as var.private_access_settings_id when set)."
  value       = databricks_mws_workspaces.this.private_access_settings_id
}

output "storage_configuration_id" {
  description = "Databricks account storage configuration ID."
  value       = databricks_mws_storage_configurations.this.storage_configuration_id
}

output "kms_key_arn" {
  description = "AWS KMS key ARN used for workspace encryption."
  value       = aws_kms_key.workspace.arn
}

output "metastore_id" {
  description = "Assigned Unity Catalog metastore ID."
  value       = data.databricks_metastore.existing.metastore_id
}

output "network_connectivity_config_id" {
  description = "MWS Network Connectivity Config ID when enable_network_connectivity_config is true."
  value       = length(module.network_connectivity_config) > 0 ? module.network_connectivity_config[0].network_connectivity_config_id : null
}

output "ncc_egress_config" {
  description = "Computed NCC egress rules from Databricks (when NCC is enabled)."
  value       = length(module.network_connectivity_config) > 0 ? module.network_connectivity_config[0].egress_config : null
}

output "ncc_nlb_private_endpoint_rule_id" {
  description = "NLB private endpoint rule ID when NLB variables are set and NCC is enabled."
  value       = length(module.network_connectivity_config) > 0 ? module.network_connectivity_config[0].nlb_private_endpoint_rule_id : null
}
