variable "databricks_account_id" {
  description = "Databricks Account ID"
  type        = string
}

variable "workspace_name" {
  description = "Name for the workspace"
  type        = string
  default     = "example-workspace"
}

variable "aws_region" {
  description = "AWS Region"
  type        = string
  default     = "us-east-2"
}

# -----------------------------------------------------------------------------
# PrivateLink (set enable_private_link = true and provide AWS VPC endpoint IDs,
# or use the example's built-in endpoint creation when enable_private_link = true)
# -----------------------------------------------------------------------------
variable "enable_private_link" {
  description = "Enable PrivateLink; example creates VPC endpoints and passes IDs to the module when true (default true so all necessary AWS resources are created)"
  type        = bool
  default     = true
}

variable "rest_api_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks REST API. Set when using your own endpoints; ignored if enable_private_link and example creates endpoints."
  type        = string
  default     = null
}

variable "dataplane_relay_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks SCC dataplane relay. Set when using your own endpoints; ignored if enable_private_link and example creates endpoints."
  type        = string
  default     = null
}

variable "public_access_enabled" {
  description = "When PrivateLink is enabled, whether public access is still allowed"
  type        = bool
  default     = true
}

variable "private_access_level" {
  description = "When PrivateLink is enabled: ACCOUNT or ENDPOINT"
  type        = string
  default     = "ACCOUNT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.private_access_level)
    error_message = "private_access_level must be ACCOUNT or ENDPOINT."
  }
}

# -----------------------------------------------------------------------------
# Optional: disable to avoid account limits
# -----------------------------------------------------------------------------
variable "enable_ncc" {
  description = "Enable Network Connectivity Configuration (disable if account limit reached)"
  type        = bool
  default     = true
}

variable "enable_audit_logs" {
  description = "Enable audit log delivery to S3 (disable if account limit of 2 reached)"
  type        = bool
  default     = true
}

# -----------------------------------------------------------------------------
# Optional: NCC private endpoint rule for AWS Network Load Balancer
# -----------------------------------------------------------------------------
variable "enable_nlb_private_endpoint" {
  description = "Create an internal NLB and VPC endpoint service in this example and add an NCC private endpoint rule. Requires enable_ncc = true."
  type        = bool
  default     = true
}

variable "nlb_vpc_endpoint_service_name" {
  description = "Use an existing AWS VPC endpoint service name for an NLB (e.g. com.amazonaws.vpce.us-west-2.vpce-svc-xxx). Ignored when enable_nlb_private_endpoint is true."
  type        = string
  default     = null
}

variable "nlb_domain_names" {
  description = "FQDNs reachable via the NLB for the NCC private endpoint rule. When enable_nlb_private_endpoint is true, defaults to [\"api.<workspace_name>.internal\"] if empty."
  type        = list(string)
  default     = []
}

