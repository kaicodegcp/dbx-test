# =============================================================================
# Complete Databricks Workspace (Custom VPC) - Example
# =============================================================================
# This example:
#   1. Creates all necessary AWS resources (VPC, and when PrivateLink: SG + VPC endpoints)
#   2. Calls the complete-workspace-custom module with those resources
#
# Set enable_private_link = true (default) so the module receives VPC endpoint
# IDs and MWS networks can be created. Set to false only if using your own
# VPC/endpoints and passing rest_api_aws_vpc_endpoint_id and
# dataplane_relay_aws_vpc_endpoint_id.
# =============================================================================

terraform {
  required_version = ">= 1.0"
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.0.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Providers
# -----------------------------------------------------------------------------
provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace"
  host  = module.complete_workspace_custom.workspace_url
}

provider "aws" {
  region = var.aws_region
}

# =============================================================================
# Part 1: AWS resources (required for the module)
# =============================================================================

# Databricks PrivateLink endpoint service names per region (for example-created endpoints)
locals {
  scc_relay_service = {
    "ap-northeast-1" = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02aa633bda3edbec0"
    "ap-northeast-2" = "com.amazonaws.vpce.ap-northeast-2.vpce-svc-0dc0e98a5800db5c4"
    "ap-south-1"     = "com.amazonaws.vpce.ap-south-1.vpce-svc-03fd4d9b61414f3de"
    "ap-southeast-1" = "com.amazonaws.vpce.ap-southeast-1.vpce-svc-0557367c6fc1a0c5c"
    "ap-southeast-2" = "com.amazonaws.vpce.ap-southeast-2.vpce-svc-0b4a72e8f825495f6"
    "eu-central-1"   = "com.amazonaws.vpce.eu-central-1.vpce-svc-08e5dfca9572c85c4"
    "eu-west-1"      = "com.amazonaws.vpce.eu-west-1.vpce-svc-09b4eb2bc775f4e8c"
    "eu-west-2"      = "com.amazonaws.vpce.eu-west-2.vpce-svc-05279412bf5353a45"
    "us-east-1"      = "com.amazonaws.vpce.us-east-1.vpce-svc-00018a8c3ff62ffdf"
    "us-east-2"      = "com.amazonaws.vpce.us-east-2.vpce-svc-090a8fab0d73e39a6"
    "us-west-1"      = "com.amazonaws.vpce.us-west-1.vpce-svc-04cb91f9372b792fe"
    "us-west-2"      = "com.amazonaws.vpce.us-west-2.vpce-svc-0158114c0c730c3bb"
  }
  workspace_api_service = {
    "ap-northeast-1" = "com.amazonaws.vpce.ap-northeast-1.vpce-svc-02691fd610d24fd64"
    "ap-northeast-2" = "com.amazonaws.vpce.ap-northeast-2.vpce-svc-0babb9bde64f34d7e"
    "ap-south-1"     = "com.amazonaws.vpce.ap-south-1.vpce-svc-0dbfe5d9ee18d6411"
    "ap-southeast-1" = "com.amazonaws.vpce.ap-southeast-1.vpce-svc-02535b257fc253ff4"
    "ap-southeast-2" = "com.amazonaws.vpce.ap-southeast-2.vpce-svc-0b87155ddd6954974"
    "eu-central-1"   = "com.amazonaws.vpce.eu-central-1.vpce-svc-081f78503812597f7"
    "eu-west-1"      = "com.amazonaws.vpce.eu-west-1.vpce-svc-0da6ebf1461278016"
    "eu-west-2"      = "com.amazonaws.vpce.eu-west-2.vpce-svc-01148c7cdc1d1326c"
    "us-east-1"      = "com.amazonaws.vpce.us-east-1.vpce-svc-09143d1e626de2f04"
    "us-east-2"      = "com.amazonaws.vpce.us-east-2.vpce-svc-041dc2b4d7796b8d3"
    "us-west-1"      = "com.amazonaws.vpce.us-west-1.vpce-svc-09bb6ca26208063f2"
    "us-west-2"      = "com.amazonaws.vpce.us-west-2.vpce-svc-0129f463fcfbc46c5"
  }
}

# -----------------------------------------------------------------------------
# 1a. VPC (private subnets for workspace; intra subnets for PrivateLink when enabled)
# -----------------------------------------------------------------------------
module "vpc" {
  source  = "terraform-aws-modules/vpc/aws"
  version = "~> 5.0"

  name = "${var.workspace_name}-vpc"
  cidr = "10.0.0.0/16"

  azs             = ["${var.aws_region}a", "${var.aws_region}b"]
  private_subnets = ["10.0.1.0/24", "10.0.2.0/24"]
  public_subnets  = var.enable_private_link ? [] : ["10.0.101.0/24", "10.0.102.0/24"]
  intra_subnets   = var.enable_private_link ? ["10.0.201.0/24", "10.0.202.0/24"] : []

  enable_nat_gateway   = !var.enable_private_link
  single_nat_gateway   = !var.enable_private_link
  create_igw           = !var.enable_private_link
  enable_dns_hostnames = true
  enable_dns_support   = true
}

# -----------------------------------------------------------------------------
# 1b. PrivateLink security group (when we create endpoints in this example)
# -----------------------------------------------------------------------------
module "sg_privatelink" {
  source  = "terraform-aws-modules/security-group/aws"
  version = "~> 5.0"
  count   = var.enable_private_link && var.rest_api_aws_vpc_endpoint_id == null ? 1 : 0

  name   = "${var.workspace_name}-privatelink-sg"
  vpc_id = module.vpc.vpc_id

  ingress_with_cidr_blocks = [
    { from_port = 443, to_port = 443, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "REST API" },
    { from_port = 2443, to_port = 2443, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "SCC Relay" },
    { from_port = 5432, to_port = 5432, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "PostgreSQL" },
    { from_port = 8443, to_port = 8451, protocol = "tcp", cidr_blocks = "10.0.0.0/16", description = "Control plane" },
  ]
}

# -----------------------------------------------------------------------------
# 1c. VPC endpoints for PrivateLink (S3 gateway, STS, Kinesis, Databricks REST + relay)
# -----------------------------------------------------------------------------
module "vpc_endpoints" {
  source  = "terraform-aws-modules/vpc/aws//modules/vpc-endpoints"
  version = "~> 5.0"
  count   = var.enable_private_link && var.rest_api_aws_vpc_endpoint_id == null ? 1 : 0

  vpc_id             = module.vpc.vpc_id
  security_group_ids = [module.sg_privatelink[0].security_group_id]

  endpoints = {
    s3 = {
      service         = "s3"
      service_type    = "Gateway"
      route_table_ids = module.vpc.private_route_table_ids
    }
    sts = {
      service            = "sts"
      private_dns_enabled = true
      subnet_ids         = module.vpc.intra_subnets
    }
    kinesis-streams = {
      service            = "kinesis-streams"
      private_dns_enabled = true
      subnet_ids         = module.vpc.intra_subnets
    }
    backend_rest = {
      service_name        = local.workspace_api_service[var.aws_region]
      private_dns_enabled = true
      subnet_ids          = module.vpc.intra_subnets
    }
    backend_relay = {
      service_name        = local.scc_relay_service[var.aws_region]
      private_dns_enabled = true
      subnet_ids          = module.vpc.intra_subnets
    }
  }
}

# -----------------------------------------------------------------------------
# 1d. Internal NLB and VPC endpoint service (for NCC private endpoint rule)
# -----------------------------------------------------------------------------
# When enable_nlb_private_endpoint is true, creates an internal NLB, exposes it
# via a VPC endpoint service, and passes the service name into the module so
# serverless compute can reach resources behind the NLB via the NCC private
# endpoint rule.
# -----------------------------------------------------------------------------
resource "aws_lb" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  name               = "${var.workspace_name}-nlb"
  internal           = true
  load_balancer_type  = "network"
  subnets            = module.vpc.private_subnets
  ip_address_type    = "ipv4"
  enable_cross_zone_load_balancing = true

  tags = {
    Name        = "${var.workspace_name}-nlb"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb_target_group" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  name     = "${var.workspace_name}-nlb-tg"
  port     = 443
  protocol = "TCP"
  vpc_id   = module.vpc.vpc_id
  target_type = "ip"

  health_check {
    enabled             = true
    healthy_threshold   = 2
    interval            = 30
    protocol            = "TCP"
    unhealthy_threshold = 2
  }

  tags = {
    Name        = "${var.workspace_name}-nlb-tg"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

resource "aws_lb_listener" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  load_balancer_arn = aws_lb.nlb[0].arn
  port              = "443"
  protocol          = "TCP"

  default_action {
    type             = "forward"
    target_group_arn = aws_lb_target_group.nlb[0].arn
  }
}

resource "aws_vpc_endpoint_service" "nlb" {
  count = var.enable_nlb_private_endpoint ? 1 : 0

  acceptance_required        = false
  network_load_balancer_arns = [aws_lb.nlb[0].arn]
  # Allow Databricks serverless to create a VPC endpoint to this service (private connectivity)
  # https://docs.databricks.com/aws/security/network/serverless-network-security/pl-to-internal-network
  allowed_principals         = ["arn:aws:iam::565502421330:role/private-connectivity-role-${var.aws_region}"]

  tags = {
    Name        = "${var.workspace_name}-nlb-vpce-service"
    Environment = "example"
    ManagedBy   = "Terraform"
  }
}

# When we create the NLB, use its VPC endpoint service name and default or provided domain names for the NCC rule
locals {
  nlb_endpoint_service_name = try(aws_vpc_endpoint_service.nlb[0].service_name, var.nlb_vpc_endpoint_service_name)
  nlb_domain_names_for_rule = var.enable_nlb_private_endpoint ? (length(var.nlb_domain_names) > 0 ? var.nlb_domain_names : ["api.${var.workspace_name}.internal"]) : var.nlb_domain_names
}

# =============================================================================
# Part 2: complete-workspace-custom module (uses AWS resources above)
# =============================================================================
module "complete_workspace_custom" {
  source = "../../"

  providers = {
    databricks.account   = databricks.account
    databricks.workspace = databricks.workspace
  }

  databricks_account_id = var.databricks_account_id
  workspace_name        = var.workspace_name
  aws_region            = var.aws_region

  # From Part 1: VPC
  vpc_id             = module.vpc.vpc_id
  private_subnet_ids = module.vpc.private_subnets
  vpc_cidr           = module.vpc.vpc_cidr_block
  public_subnet_ids  = module.vpc.public_subnets
  nat_gateway_ids    = module.vpc.natgw_ids

  # PrivateLink: use example-created endpoints or variables
  enable_private_link                = var.enable_private_link
  rest_api_aws_vpc_endpoint_id       = var.enable_private_link ? (var.rest_api_aws_vpc_endpoint_id != null ? var.rest_api_aws_vpc_endpoint_id : try(module.vpc_endpoints[0].endpoints["backend_rest"].id, null)) : null
  dataplane_relay_aws_vpc_endpoint_id = var.enable_private_link ? (var.dataplane_relay_aws_vpc_endpoint_id != null ? var.dataplane_relay_aws_vpc_endpoint_id : try(module.vpc_endpoints[0].endpoints["backend_relay"].id, null)) : null
  public_access_enabled              = var.public_access_enabled
  private_access_level               = var.private_access_level

  enable_ncc         = var.enable_ncc
  enable_audit_logs  = var.enable_audit_logs

  create_nlb_private_endpoint_rule = var.enable_nlb_private_endpoint || (var.nlb_vpc_endpoint_service_name != null && length(var.nlb_domain_names) > 0)
  nlb_vpc_endpoint_service_name   = local.nlb_endpoint_service_name
  nlb_domain_names                = local.nlb_domain_names_for_rule

  enable_cmk                   = true
  create_metastore             = true
  create_default_catalog       = true
  configure_workspace_security = true
  create_cluster_policy        = true
  create_admin_group           = true

  tags = {
    Environment = "example"
    ManagedBy   = "Terraform"
  }

  depends_on = [
    module.vpc,
    module.sg_privatelink,
    module.vpc_endpoints,
    aws_lb.nlb,
    aws_vpc_endpoint_service.nlb,
  ]
}

# =============================================================================
# Outputs
# =============================================================================
output "workspace_url" {
  description = "Databricks workspace URL"
  value       = module.complete_workspace_custom.workspace_url
}

output "workspace_id" {
  description = "Workspace ID"
  value       = module.complete_workspace_custom.workspace_id
}

output "metastore_id" {
  description = "Unity Catalog metastore ID"
  value       = module.complete_workspace_custom.metastore_id
}

output "catalog_name" {
  description = "Default catalog name"
  value       = module.complete_workspace_custom.default_catalog_name
}

output "security_info" {
  description = "Security configuration summary"
  value = {
    cmk_encryption_enabled    = module.complete_workspace_custom.managed_services_cmk_id != null
    unity_catalog_enabled     = module.complete_workspace_custom.metastore_id != null
    security_settings_applied = true
    cluster_policy_created    = module.complete_workspace_custom.secure_cluster_policy_id != null
    admin_group_created       = module.complete_workspace_custom.admin_group_id != null
  }
}

output "aws_infrastructure" {
  description = "AWS infrastructure created by the example and used by the module"
  value = {
    vpc_id             = module.complete_workspace_custom.vpc_id
    s3_bucket          = module.complete_workspace_custom.s3_bucket_name
    security_group_id  = module.complete_workspace_custom.security_group_id
    cross_account_role = module.complete_workspace_custom.cross_account_role_arn
  }
}

output "private_link_enabled" {
  description = "Whether PrivateLink is enabled"
  value       = var.enable_private_link
}

output "nlb_private_endpoint_rule" {
  description = "NCC private endpoint rule for NLB (when NLB is created or nlb_vpc_endpoint_service_name and nlb_domain_names are set)"
  value = local.nlb_endpoint_service_name != null && length(local.nlb_domain_names_for_rule) > 0 ? {
    rule_id          = module.complete_workspace_custom.nlb_private_endpoint_rule_id
    connection_state = module.complete_workspace_custom.nlb_private_endpoint_connection_state
  } : null
}

output "nlb_vpc_endpoint_service_name" {
  description = "VPC endpoint service name for the example-created NLB (when enable_nlb_private_endpoint is true)"
  value       = try(aws_vpc_endpoint_service.nlb[0].service_name, null)
}
