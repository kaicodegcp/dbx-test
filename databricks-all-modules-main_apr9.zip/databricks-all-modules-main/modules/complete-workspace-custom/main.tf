# =============================================================================
# Complete Databricks Workspace Module (Custom VPC) - SRA-Aligned
# Same as complete-workspace but does NOT create VPC or PrivateLink VPC endpoints.
# Provide vpc_id, private_subnet_ids, vpc_cidr and (when using PrivateLink) MWS
# VPC endpoint IDs and private_access_settings_id as variables.
# =============================================================================

# Provider requirements are in versions.tf

# =============================================================================
# DATA SOURCES
# =============================================================================

data "aws_caller_identity" "current" {}

data "aws_availability_zones" "available" {
  state = "available"
}

data "aws_prefix_list" "s3" {
  name = "com.amazonaws.${var.aws_region}.s3"
}

data "databricks_aws_assume_role_policy" "this" {
  provider    = databricks.account
  external_id = var.databricks_account_id
}


# =============================================================================
# LOCALS
# =============================================================================

locals {
  prefix = var.workspace_name
  suffix = random_string.suffix.result

  computed_aws_partition = var.databricks_gov_shard != null ? "aws-us-gov" : "aws"

  databricks_aws_account_id = var.databricks_gov_shard == "civilian" ? "044793339203" : (
    var.databricks_gov_shard == "dod" ? "170661010020" : "414351767826"
  )

  databricks_ec2_image_account_id = var.databricks_gov_shard != null ? "044732911619" : "601306020600"



  assume_role_partition = var.databricks_gov_shard == "dod" ? "aws-us-gov-dod" : (
    var.databricks_gov_shard == "civilian" ? "aws-us-gov" : "aws"
  )

  cmk_admin_value = var.cmk_admin_arn != null ? var.cmk_admin_arn : "arn:${local.computed_aws_partition}:iam::${data.aws_caller_identity.current.account_id}:root"

  root_bucket_name = module.s3_bucket.s3_bucket_id

  # Egress ports with GovCloud port 6666 exclusion
  effective_sg_egress_ports = var.databricks_gov_shard == "civilian" || var.databricks_gov_shard == "dod" ? [for port in var.sg_egress_ports : port if port != 6666] : var.sg_egress_ports
}

# =============================================================================
# RANDOM SUFFIX MODULE
# =============================================================================

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

# =============================================================================
# AWS WORKSPACE SECURITY GROUP MODULE (SRA-aligned, GovCloud-aware)
# Uses existing VPC (var.vpc_id) - no VPC created by this module.
# =============================================================================

module "sg_workspace" {
  source  = "terraform-aws-modules/security-group/aws"
  version = "~> 5.0"

  name   = "${local.prefix}-workspace-sg-${local.suffix}"
  vpc_id = var.vpc_id

  ingress_with_self = [
    {
      from_port   = 0
      to_port     = 65535
      protocol    = "tcp"
      description = "Databricks - Workspace SG - Internode Communication"
    },
    {
      from_port   = 0
      to_port     = 65535
      protocol    = "udp"
      description = "Databricks - Workspace SG - Internode Communication"
    }
  ]

  egress_with_self = [
    {
      from_port   = 0
      to_port     = 65535
      protocol    = "tcp"
      description = "Databricks - Workspace SG - Internode Communication"
    },
    {
      from_port   = 0
      to_port     = 65535
      protocol    = "udp"
      description = "Databricks - Workspace SG - Internode Communication"
    }
  ]

  egress_with_cidr_blocks = [for port in local.effective_sg_egress_ports : {
    from_port   = port
    to_port     = port
    protocol    = "tcp"
    cidr_blocks = var.vpc_cidr
    description = "Databricks - Workspace SG - Control plane port ${port}"
  }]

  egress_with_prefix_list_ids = [
    {
      from_port       = 443
      to_port         = 443
      protocol        = "tcp"
      prefix_list_ids = data.aws_prefix_list.s3.id
      description     = "S3 Gateway Endpoint"
    }
  ]

  tags = merge(var.tags, { Name = "${local.prefix}-workspace-sg-${local.suffix}" })
}

# =============================================================================
# AWS S3 ROOT STORAGE BUCKET
# =============================================================================

module "s3_bucket" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"

  bucket = "${local.prefix}-root-${local.suffix}"

  force_destroy       = var.force_destroy
  acceleration_status = "Suspended"

  versioning = {
    enabled = var.root_bucket_versioning
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  server_side_encryption_configuration = {
    rule = {
      apply_server_side_encryption_by_default = {
        sse_algorithm     = var.enable_cmk ? "aws:kms" : "AES256"
        kms_master_key_id = var.enable_cmk ? module.kms_workspace_storage[0].key_arn : null
      }
      bucket_key_enabled = var.enable_cmk
    }
  }

  attach_policy = true
  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "Grant Databricks Access"
        Effect = "Allow"
        Principal = {
          AWS = "arn:${local.computed_aws_partition}:iam::${local.databricks_aws_account_id}:root"
        }
        Action = [
          "s3:GetObject",
          "s3:GetObjectVersion",
          "s3:ListBucket",
          "s3:GetBucketLocation",
          "s3:PutObject",
          "s3:DeleteObject"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:s3:::${local.prefix}-root-${local.suffix}/*",
          "arn:${local.computed_aws_partition}:s3:::${local.prefix}-root-${local.suffix}"
        ]
        Condition = {
          StringEquals = {
            "aws:PrincipalTag/DatabricksAccountId" = var.databricks_account_id
          }
        }
      }
    ]
  })

  tags = merge(var.tags, {
    Name    = "Databricks Workspace Storage"
    Purpose = "Databricks Root Storage"
  })
}

# =============================================================================
# DATABRICKS PRIVATELINK REGISTRATION (register caller-provided AWS VPC endpoints)
# =============================================================================

resource "databricks_mws_vpc_endpoint" "backend_rest" {
  provider = databricks.account
  count    = var.enable_private_link ? 1 : 0

  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.rest_api_aws_vpc_endpoint_id
  vpc_endpoint_name   = "${local.prefix}-vpce-backend-${var.vpc_id}"
  region              = var.aws_region
}

resource "databricks_mws_vpc_endpoint" "backend_relay" {
  provider = databricks.account
  count    = var.enable_private_link ? 1 : 0

  account_id          = var.databricks_account_id
  aws_vpc_endpoint_id = var.dataplane_relay_aws_vpc_endpoint_id
  vpc_endpoint_name   = "${local.prefix}-vpce-relay-${var.vpc_id}"
  region              = var.aws_region
}

resource "databricks_mws_private_access_settings" "this" {
  provider = databricks.account
  count    = var.enable_private_link ? 1 : 0

  private_access_settings_name = "${local.prefix}-PAS-${local.suffix}"
  region                       = var.aws_region
  public_access_enabled        = var.public_access_enabled
  private_access_level         = var.private_access_level
}

# =============================================================================
# AWS KMS - WORKSPACE STORAGE (SRA-aligned with DatabricksAccountId + EBS)
# =============================================================================

module "kms_workspace_storage" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"
  count   = var.enable_cmk ? 1 : 0

  description = "KMS key for Databricks workspace storage encryption"
  key_usage   = "ENCRYPT_DECRYPT"

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.cmk_admin_value]
        }
      ]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow Databricks to use KMS key for DBFS"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = ["arn:${local.computed_aws_partition}:iam::${local.databricks_aws_account_id}:root"]
        }
      ]
      actions = [
        "kms:Encrypt",
        "kms:Decrypt",
        "kms:ReEncrypt*",
        "kms:GenerateDataKey*",
        "kms:DescribeKey"
      ]
      resources = ["*"]
      conditions = [
        {
          test     = "StringEquals"
          variable = "aws:PrincipalTag/DatabricksAccountId"
          values   = [var.databricks_account_id]
        }
      ]
    },
    {
      sid    = "Allow Databricks to use KMS key for EBS"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [module.iam_assumable_role_databricks.iam_role_arn]
        }
      ]
      actions = [
        "kms:Decrypt",
        "kms:GenerateDataKey*",
        "kms:CreateGrant",
        "kms:DescribeKey"
      ]
      resources = ["*"]
      conditions = [
        {
          test     = "ForAnyValue:StringLike"
          variable = "kms:ViaService"
          values   = ["ec2.*.amazonaws.com"]
        }
      ]
    }
  ]

  tags = merge(var.tags, { Name = "databricks-workspace-storage-cmk" })
}

# =============================================================================
# AWS KMS - MANAGED SERVICES (SRA-aligned: Encrypt/Decrypt only)
# =============================================================================

module "kms_managed_services" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"
  count   = var.enable_cmk ? 1 : 0

  description = "KMS key for Databricks managed services encryption"
  key_usage   = "ENCRYPT_DECRYPT"

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.cmk_admin_value]
        }
      ]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow Databricks to use KMS key for managed services"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = ["arn:${local.computed_aws_partition}:iam::${local.databricks_aws_account_id}:root"]
        }
      ]
      actions = [
        "kms:Encrypt",
        "kms:Decrypt"
      ]
      resources = ["*"]
      conditions = [
        {
          test     = "StringEquals"
          variable = "aws:PrincipalTag/DatabricksAccountId"
          values   = [var.databricks_account_id]
        }
      ]
    }
  ]

  tags = merge(var.tags, { Name = "databricks-managed-services-cmk" })
}

# =============================================================================
# AWS IAM ROLE MODULE
# =============================================================================

module "iam_assumable_role_databricks" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role"
  version = "~> 5.0"

  trusted_role_arns = []

  create_role                       = true
  role_name                         = "${local.prefix}-cross-account-${local.suffix}"
  role_requires_mfa                 = false
  create_custom_role_trust_policy   = true
  custom_role_trust_policy          = data.databricks_aws_assume_role_policy.this.json

  custom_role_policy_arns = [module.iam_policy_databricks.arn]

  tags = merge(var.tags, { Name = "Databricks Cross-Account Role" })
}

# =============================================================================
# AWS IAM POLICY MODULE (SRA-aligned: GetLaunchTemplateData, GetSpotPlacementScores, AllowEC2Tagging)
# =============================================================================

module "iam_policy_databricks" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-policy"
  version = "~> 5.0"

  name        = "${local.prefix}-databricks-policy-${local.suffix}"
  description = "Databricks cross-account policy with full EC2 and networking permissions"

  policy = jsonencode({
    Version = "2012-10-17"
    Statement = [
      {
        Sid    = "CreateEC2ResourcesWithRequestTag"
        Effect = "Allow"
        Action = [
          "ec2:CreateFleet",
          "ec2:CreateLaunchTemplate",
          "ec2:CreateLaunchTemplateVersion",
          "ec2:CreateVolume",
          "ec2:RequestSpotInstances",
          "ec2:RunInstances"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*"
        ]
        Condition = {
          StringEquals = {
            "aws:RequestTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "AllowDatabricksTagOnCreate"
        Effect = "Allow"
        Action = ["ec2:CreateTags"]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:CreateAction" = [
              "CreateFleet",
              "CreateLaunchTemplate",
              "CreateVolume",
              "RequestSpotInstances",
              "RunInstances"
            ]
            "aws:RequestTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "ModifyEC2ResourcesByResourceTags"
        Effect = "Allow"
        Action = [
          "ec2:AssignPrivateIpAddresses",
          "ec2:AssociateIamInstanceProfile",
          "ec2:AttachVolume",
          "ec2:CancelSpotInstanceRequests",
          "ec2:CreateLaunchTemplateVersion",
          "ec2:DetachVolume",
          "ec2:DisassociateIamInstanceProfile",
          "ec2:ModifyFleet",
          "ec2:ModifyLaunchTemplate",
          "ec2:RequestSpotInstances",
          "ec2:CreateFleet",
          "ec2:CreateLaunchTemplate",
          "ec2:CreateVolume",
          "ec2:RunInstances"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:spot-instance-request/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "GetEC2LaunchTemplateDataByTag"
        Effect = "Allow"
        Action = [
          "ec2:GetLaunchTemplateData"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "DescribeEC2Resources"
        Effect = "Allow"
        Action = [
          "ec2:DescribeAvailabilityZones",
          "ec2:DescribeFleetHistory",
          "ec2:DescribeFleetInstances",
          "ec2:DescribeVpcAttribute",
          "ec2:DescribeFleets",
          "ec2:DescribeIamInstanceProfileAssociations",
          "ec2:DescribeInstanceStatus",
          "ec2:DescribeInstances",
          "ec2:DescribeInternetGateways",
          "ec2:DescribeLaunchTemplates",
          "ec2:DescribeLaunchTemplateVersions",
          "ec2:DescribeNatGateways",
          "ec2:DescribeNetworkAcls",
          "ec2:DescribePrefixLists",
          "ec2:DescribeReservedInstancesOfferings",
          "ec2:DescribeRouteTables",
          "ec2:DescribeSecurityGroups",
          "ec2:DescribeSpotInstanceRequests",
          "ec2:DescribeSpotPriceHistory",
          "ec2:DescribeSubnets",
          "ec2:DescribeVolumes",
          "ec2:DescribeVpcs",
          "ec2:GetSpotPlacementScores"
        ]
        Resource = "*"
      },
      {
        Sid    = "DeleteEC2ResourcesByTag"
        Effect = "Allow"
        Action = [
          "ec2:DeleteFleets",
          "ec2:DeleteLaunchTemplate",
          "ec2:DeleteLaunchTemplateVersions",
          "ec2:DeleteTags",
          "ec2:DeleteVolume",
          "ec2:TerminateInstances"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:spot-instance-request/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "AllowEC2TaggingOnDatabricksResources"
        Effect = "Allow"
        Action = [
          "ec2:CreateTags",
          "ec2:DeleteTags"
        ]
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:instance/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:volume/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:network-interface/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:launch-template/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:fleet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:spot-instance-request/*"
        ]
        Condition = {
          StringEquals = {
            "ec2:ResourceTag/Vendor" = "Databricks"
          }
        }
      },
      {
        Sid    = "VpcNonresourceSpecificActions"
        Effect = "Allow"
        Action = [
          "ec2:AuthorizeSecurityGroupEgress",
          "ec2:AuthorizeSecurityGroupIngress",
          "ec2:RevokeSecurityGroupEgress",
          "ec2:RevokeSecurityGroupIngress"
        ]
        Resource = "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:security-group/${module.sg_workspace.security_group_id}"
        Condition = {
          StringEquals = {
            "ec2:vpc" = "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:vpc/${var.vpc_id}"
          }
        }
      },
      {
        Sid    = "RestrictAMIUsageToDatabricksDeny"
        Effect = "Deny"
        Action = [
          "ec2:RunInstances",
          "ec2:CreateFleet",
          "ec2:RequestSpotInstances"
        ]
        Resource = "arn:${local.computed_aws_partition}:ec2:*:*:image/*"
        Condition = {
          StringNotEquals = {
            "ec2:Owner" = local.databricks_ec2_image_account_id
          }
        }
      },
      {
        Sid    = "RestrictAMIUsageToDatabricksAllow"
        Effect = "Allow"
        Action = [
          "ec2:RunInstances",
          "ec2:CreateFleet",
          "ec2:RequestSpotInstances"
        ]
        Resource = "arn:${local.computed_aws_partition}:ec2:*:*:image/*"
        Condition = {
          StringEquals = {
            "ec2:Owner" = local.databricks_ec2_image_account_id
          }
        }
      },
      {
        Sid    = "AllowRunInstancesWithScopedResources"
        Effect = "Allow"
        Action = "ec2:RunInstances"
        Resource = [
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:subnet/*",
          "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:security-group/*"
        ]
        Condition = {
          StringEqualsIfExists = {
            "ec2:vpc" = "arn:${local.computed_aws_partition}:ec2:${var.aws_region}:${data.aws_caller_identity.current.account_id}:vpc/${var.vpc_id}"
          }
        }
      },
      {
        Sid    = "IAMRoleForEC2Spot"
        Effect = "Allow"
        Action = ["iam:CreateServiceLinkedRole"]
        Resource = [
          "arn:${local.computed_aws_partition}:iam::*:role/aws-service-role/spot.amazonaws.com/AWSServiceRoleForEC2Spot"
        ]
        Condition = {
          StringLike = {
            "iam:AWSServiceName" = "spot.amazonaws.com"
          }
        }
      }
    ]
  })

  tags = merge(var.tags, { Name = "Databricks Cross-Account Policy" })
}

# =============================================================================
# DATABRICKS MWS MODULES - ACCOUNT LEVEL
# =============================================================================

resource "time_sleep" "iam_role_propagation" {
  depends_on      = [module.iam_assumable_role_databricks]
  create_duration = "20s"
}

module "mws_credentials" {
  source = "./modules/mws-credentials"
  providers = {
    databricks = databricks.account
  }

  account_id       = var.databricks_account_id
  credentials_name = "${local.prefix}-credentials-${local.suffix}"
  role_arn         = module.iam_assumable_role_databricks.iam_role_arn

  depends_on = [time_sleep.iam_role_propagation]
}

module "mws_storage" {
  source = "./modules/mws-storage-configuration"
  providers = {
    databricks = databricks.account
  }

  account_id                 = var.databricks_account_id
  storage_configuration_name = "${local.prefix}-storage-${local.suffix}"
  bucket_name                = module.s3_bucket.s3_bucket_id
}

module "mws_networks" {
  source = "./modules/mws-networks"
  providers = {
    databricks = databricks.account
  }

  account_id         = var.databricks_account_id
  network_name       = "${local.prefix}-network-${local.suffix}"
  vpc_id             = var.vpc_id
  subnet_ids         = var.private_subnet_ids
  security_group_ids = [module.sg_workspace.security_group_id]

  vpc_endpoints = {
    dataplane_relay = var.enable_private_link ? [databricks_mws_vpc_endpoint.backend_relay[0].vpc_endpoint_id] : []
    rest_api        = var.enable_private_link ? [databricks_mws_vpc_endpoint.backend_rest[0].vpc_endpoint_id] : []
  }
}

# Register CMK with Databricks
resource "databricks_mws_customer_managed_keys" "managed_services" {
  provider = databricks.account
  count    = var.enable_cmk ? 1 : 0

  account_id = var.databricks_account_id

  aws_key_info {
    key_arn   = module.kms_managed_services[0].key_arn
    key_alias = "alias/${local.prefix}-managed-services-${local.suffix}"
  }

  use_cases = ["MANAGED_SERVICES"]
}

resource "databricks_mws_customer_managed_keys" "workspace_storage" {
  provider = databricks.account
  count    = var.enable_cmk ? 1 : 0

  account_id = var.databricks_account_id

  aws_key_info {
    key_arn   = module.kms_workspace_storage[0].key_arn
    key_alias = "alias/${local.prefix}-workspace-storage-${local.suffix}"
  }

  use_cases = ["STORAGE"]
}

# =============================================================================
# NETWORK CONNECTIVITY CONFIGURATION (NCC) - SRA Gap #1
# =============================================================================

resource "databricks_mws_network_connectivity_config" "ncc" {
  provider = databricks.account
  count    = var.enable_ncc ? 1 : 0

  name   = "${local.prefix}-ncc-${local.suffix}"
  region = var.aws_region
}

resource "databricks_mws_ncc_private_endpoint_rule" "nlb" {
  provider = databricks.account
  count    = var.enable_ncc && var.create_nlb_private_endpoint_rule ? 1 : 0

  network_connectivity_config_id = databricks_mws_network_connectivity_config.ncc[0].network_connectivity_config_id
  endpoint_service               = var.nlb_vpc_endpoint_service_name
  domain_names                   = var.nlb_domain_names

  lifecycle {
    ignore_changes = [connection_state]
  }
}


# =============================================================================
# DATABRICKS WORKSPACE MODULE
# =============================================================================

module "workspace" {
  source = "./modules/workspace"
  providers = {
    databricks = databricks.account
  }

  account_id      = var.databricks_account_id
  workspace_name  = "${local.prefix}-${local.suffix}"
  aws_region      = var.aws_region
  deployment_name = var.deployment_name

  credentials_id           = module.mws_credentials.credentials_id
  storage_configuration_id = module.mws_storage.storage_configuration_id
  network_id               = module.mws_networks.network_id

  managed_services_customer_managed_key_id = var.enable_cmk ? databricks_mws_customer_managed_keys.managed_services[0].customer_managed_key_id : null
  storage_customer_managed_key_id          = var.enable_cmk ? databricks_mws_customer_managed_keys.workspace_storage[0].customer_managed_key_id : null

  private_access_settings_id = var.enable_private_link ? databricks_mws_private_access_settings.this[0].private_access_settings_id : null

  pricing_tier = var.pricing_tier
  custom_tags  = var.tags

  depends_on = [module.s3_bucket]
}

# =============================================================================
# POST-WORKSPACE: NCC BINDING - SRA Gap #1
# =============================================================================

resource "databricks_mws_ncc_binding" "this" {
  provider = databricks.account
  count    = var.enable_ncc ? 1 : 0

  network_connectivity_config_id = databricks_mws_network_connectivity_config.ncc[0].network_connectivity_config_id
  workspace_id                   = module.workspace.workspace_id
}


# =============================================================================
# AUDIT LOG DELIVERY - SRA Gap #3
# =============================================================================

module "s3_audit_log_delivery" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"
  count   = var.enable_audit_logs ? 1 : 0

  bucket        = "${local.prefix}-audit-log-delivery-${local.suffix}"
  force_destroy = var.force_destroy

  versioning = {
    enabled = false
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  attach_policy = true
  policy        = data.databricks_aws_bucket_policy.audit_log_delivery[0].json

  tags = merge(var.tags, {
    Name    = "${local.prefix}-audit-log-delivery-${local.suffix}"
    Purpose = "Databricks Audit Log Delivery"
  })
}

data "databricks_aws_assume_role_policy" "log_delivery" {
  provider         = databricks.account
  count            = var.enable_audit_logs ? 1 : 0
  external_id      = var.databricks_account_id
  for_log_delivery = true
  aws_partition    = local.assume_role_partition
}

module "iam_role_audit_log_delivery" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role"
  version = "~> 5.0"
  count   = var.enable_audit_logs ? 1 : 0

  create_role                     = true
  role_name                       = "${local.prefix}-audit-log-delivery-role-${local.suffix}"
  role_description                = "(${local.prefix}) Audit Log Delivery role"
  role_requires_mfa               = false
  create_custom_role_trust_policy = true
  custom_role_trust_policy        = data.databricks_aws_assume_role_policy.log_delivery[0].json
  trusted_role_arns               = []

  tags = merge(var.tags, {
    Name = "${local.prefix}-audit-log-delivery-role-${local.suffix}"
  })
}

resource "time_sleep" "audit_log_role_propagation" {
  count = var.enable_audit_logs ? 1 : 0

  depends_on      = [module.iam_role_audit_log_delivery]
  create_duration = "10s"
}

data "databricks_aws_bucket_policy" "audit_log_delivery" {
  provider         = databricks.account
  count            = var.enable_audit_logs ? 1 : 0
  full_access_role = module.iam_role_audit_log_delivery[0].iam_role_arn
  aws_partition    = local.assume_role_partition
  bucket           = "${local.prefix}-audit-log-delivery-${local.suffix}"
}

resource "databricks_mws_credentials" "audit_log_writer" {
  provider = databricks.account
  count    = var.enable_audit_logs ? 1 : 0

  credentials_name = "${local.prefix}-audit-log-delivery-credential-${local.suffix}"
  role_arn         = module.iam_role_audit_log_delivery[0].iam_role_arn

  depends_on = [time_sleep.audit_log_role_propagation]
}

resource "databricks_mws_storage_configurations" "audit_log_bucket" {
  provider = databricks.account
  count    = var.enable_audit_logs ? 1 : 0

  account_id                 = var.databricks_account_id
  storage_configuration_name = "${local.prefix}-audit-log-delivery-storage-${local.suffix}"
  bucket_name                = module.s3_audit_log_delivery[0].s3_bucket_id
}

resource "databricks_mws_log_delivery" "audit_logs" {
  provider = databricks.account
  count    = var.enable_audit_logs ? 1 : 0

  account_id               = var.databricks_account_id
  credentials_id           = databricks_mws_credentials.audit_log_writer[0].credentials_id
  storage_configuration_id = databricks_mws_storage_configurations.audit_log_bucket[0].storage_configuration_id
  delivery_path_prefix     = "audit-logs"
  config_name              = "Audit Logs"
  log_type                 = "AUDIT_LOGS"
  output_format            = "JSON"
}

# =============================================================================
# UNITY CATALOG MODULES
# =============================================================================

module "metastore" {
  source = "./modules/metastore"
  providers = {
    databricks = databricks.account
  }
  count = var.create_metastore ? 1 : 0

  name   = "${local.prefix}-metastore-${var.aws_region}-${local.suffix}"
  region = var.aws_region
  owner  = var.metastore_owner

  force_destroy = var.force_destroy
}

resource "databricks_metastore_assignment" "this" {
  provider     = databricks.account
  count        = var.create_metastore ? 1 : (var.metastore_id != null ? 1 : 0)
  workspace_id = module.workspace.workspace_id
  metastore_id = var.create_metastore ? module.metastore[0].metastore_id : var.metastore_id

  depends_on = [module.metastore, module.workspace]
}

# =============================================================================
# UNITY CATALOG: Catalog Infrastructure (SRA-aligned)
# Creates dedicated S3 bucket, KMS key, IAM role, storage credential,
# external location, and catalog - following the SRA pattern.
# =============================================================================

locals {
  uc_catalog_bucket_name = "${local.prefix}-catalog-${module.workspace.workspace_id}"
  uc_catalog_role_name   = "${local.prefix}-catalog-${module.workspace.workspace_id}"
  uc_catalog_name_safe   = replace(local.uc_catalog_bucket_name, "-", "_")
  uc_iam_arn             = "arn:${local.computed_aws_partition}:iam::${data.aws_caller_identity.current.account_id}:role/${local.uc_catalog_role_name}"
}

module "kms_catalog_storage" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"
  count   = var.create_default_catalog ? 1 : 0

  description = "KMS key for Databricks catalog storage"
  key_usage   = "ENCRYPT_DECRYPT"

  computed_aliases = {
    "catalog-storage" = {
      name = "${local.prefix}-catalog-storage-${local.suffix}-key"
    }
  }

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.cmk_admin_value]
        }
      ]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow IAM Role to use the key"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.uc_iam_arn]
        }
      ]
      actions   = ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey*"]
      resources = ["*"]
    }
  ]

  tags = merge(var.tags, { Name = "${local.prefix}-catalog-storage-key-${local.suffix}" })
}

resource "databricks_storage_credential" "catalog" {
  provider = databricks.workspace
  count    = var.create_default_catalog ? 1 : 0
  name     = "${local.uc_catalog_bucket_name}-storage-credential"

  aws_iam_role {
    role_arn = local.uc_iam_arn
  }
  isolation_mode = "ISOLATION_MODE_ISOLATED"

  depends_on = [databricks_metastore_assignment.this]
}

data "databricks_aws_unity_catalog_assume_role_policy" "this" {
  provider              = databricks.workspace
  count                 = var.create_default_catalog ? 1 : 0
  aws_account_id        = data.aws_caller_identity.current.account_id
  role_name             = local.uc_catalog_role_name
  unity_catalog_iam_arn = var.unity_catalog_iam_arn
  external_id           = databricks_storage_credential.catalog[0].aws_iam_role[0].external_id
}

data "databricks_aws_unity_catalog_policy" "this" {
  provider       = databricks.workspace
  count          = var.create_default_catalog ? 1 : 0
  aws_account_id = data.aws_caller_identity.current.account_id
  bucket_name    = local.uc_catalog_bucket_name
  role_name      = local.uc_catalog_role_name
  kms_name       = module.kms_catalog_storage[0].key_arn
}

module "iam_policy_unity_catalog" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-policy"
  version = "~> 5.0"
  count   = var.create_default_catalog ? 1 : 0

  name   = "${local.prefix}-catalog-policy-${local.suffix}"
  policy = data.databricks_aws_unity_catalog_policy.this[0].json
}

module "iam_role_unity_catalog" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role"
  version = "~> 5.0"
  count   = var.create_default_catalog ? 1 : 0

  create_role                     = true
  role_name                       = local.uc_catalog_role_name
  role_requires_mfa               = false
  create_custom_role_trust_policy = true
  custom_role_trust_policy        = data.databricks_aws_unity_catalog_assume_role_policy.this[0].json
  trusted_role_arns               = []

  custom_role_policy_arns = [module.iam_policy_unity_catalog[0].arn]

  tags = merge(var.tags, { Name = local.uc_catalog_role_name })
}

module "s3_unity_catalog" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"
  count   = var.create_default_catalog ? 1 : 0

  bucket        = local.uc_catalog_bucket_name
  force_destroy = var.force_destroy

  versioning = {
    enabled = false
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  server_side_encryption_configuration = {
    rule = {
      bucket_key_enabled = true
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "aws:kms"
        kms_master_key_id = module.kms_catalog_storage[0].key_arn
      }
    }
  }

  tags = merge(var.tags, { Name = local.uc_catalog_bucket_name })
}

resource "time_sleep" "catalog_iam_propagation" {
  count           = var.create_default_catalog ? 1 : 0
  depends_on      = [module.iam_role_unity_catalog]
  create_duration = "60s"
}

resource "databricks_external_location" "catalog" {
  provider        = databricks.workspace
  count           = var.create_default_catalog ? 1 : 0
  name            = "${local.uc_catalog_bucket_name}-external-location"
  url             = "s3://${local.uc_catalog_bucket_name}/"
  credential_name = databricks_storage_credential.catalog[0].id
  comment         = "External location for catalog"
  isolation_mode  = "ISOLATION_MODE_ISOLATED"

  depends_on = [time_sleep.catalog_iam_propagation]
}

resource "databricks_catalog" "default" {
  provider       = databricks.workspace
  count          = var.create_default_catalog ? 1 : 0
  name           = local.uc_catalog_name_safe
  comment        = "Catalog for workspace ${module.workspace.workspace_id}"
  isolation_mode = var.catalog_isolation_mode
  storage_root   = "s3://${local.uc_catalog_bucket_name}/"
  owner          = var.catalog_owner
  force_destroy  = var.force_destroy

  properties = merge(
    var.catalog_properties,
    { created_by = "terraform-complete-workspace-module" }
  )

  depends_on = [databricks_external_location.catalog]
}

resource "databricks_default_namespace_setting" "this" {
  provider = databricks.workspace
  count    = var.create_default_catalog ? 1 : 0
  namespace {
    value = local.uc_catalog_name_safe
  }
  depends_on = [databricks_catalog.default]
}

# =============================================================================
# MEDALLION ARCHITECTURE SCHEMAS
# =============================================================================

module "schema_bronze" {
  source = "./modules/schema"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_default_catalog && var.create_bronze_schema ? 1 : 0

  catalog_name  = databricks_catalog.default[0].name
  name          = "bronze"
  comment       = "Bronze layer - raw data"
  properties    = { layer = "bronze", data_class = "raw" }
  force_destroy = var.force_destroy

  depends_on = [databricks_catalog.default]
}

module "schema_silver" {
  source = "./modules/schema"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_default_catalog && var.create_silver_schema ? 1 : 0

  catalog_name  = databricks_catalog.default[0].name
  name          = "silver"
  comment       = "Silver layer - cleaned and transformed data"
  properties    = { layer = "silver", data_class = "cleansed" }
  force_destroy = var.force_destroy

  depends_on = [databricks_catalog.default]
}

module "schema_gold" {
  source = "./modules/schema"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_default_catalog && var.create_gold_schema ? 1 : 0

  catalog_name  = databricks_catalog.default[0].name
  name          = "gold"
  comment       = "Gold layer - aggregated business-level data"
  properties    = { layer = "gold", data_class = "aggregated" }
  force_destroy = var.force_destroy

  depends_on = [databricks_catalog.default]
}

# =============================================================================
# WORKSPACE SECURITY MODULES
# =============================================================================

module "workspace_security" {
  source = "./modules/workspace-conf"
  providers = {
    databricks = databricks.workspace
  }
  count = var.configure_workspace_security ? 1 : 0

  enable_results_downloading      = false
  enable_notebook_table_clipboard = false
  enable_export_notebook          = false
  enable_dbfs_file_browser        = false
  enable_upload_data_uis          = false

  enable_verbose_audit_logs         = true
  enforce_user_isolation            = true
  store_results_in_customer_account = true

  disable_legacy_access = true
  disable_legacy_dbfs   = true
}

# =============================================================================
# COMPLIANCE SECURITY PROFILE (CSP) - SRA Gap #5
# =============================================================================

resource "databricks_compliance_security_profile_workspace_setting" "this" {
  provider = databricks.workspace
  count    = var.enable_csp ? 1 : 0

  compliance_security_profile_workspace {
    is_enabled           = true
    compliance_standards = var.compliance_standards
  }
}

# =============================================================================
# CLUSTER POLICY, IP ACCESS LIST, ADMIN GROUP
# =============================================================================

module "secure_cluster_policy" {
  source = "./modules/cluster-policy"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_cluster_policy ? 1 : 0

  name        = var.cluster_policy_name
  description = "Secure cluster policy - unlimited capacity with security controls"

  definition = jsonencode(merge(
    {
      "data_security_mode" = {
        type  = "fixed"
        value = "USER_ISOLATION"
      }
      "enable_local_disk_encryption" = {
        type  = "fixed"
        value = true
      }
      "autotermination_minutes" = {
        type     = "range"
        minValue = var.min_autotermination_minutes
        maxValue = var.max_autotermination_minutes
      }
      "ssh_public_keys" = {
        type  = "fixed"
        value = []
      }
      "spark_conf.spark.databricks.acl.dfAclsEnabled" = {
        type  = "fixed"
        value = "true"
      }
      "spark_conf.spark.databricks.passthrough.enabled" = {
        type  = "fixed"
        value = "false"
      }
      "spark_conf.spark.databricks.repl.allowedLanguages" = {
        type  = "fixed"
        value = "python,sql,scala,r"
      }
    },
    var.allowed_spark_versions != null ? {
      "spark_version" = { type = "regex", pattern = var.allowed_spark_versions }
    } : {
      "spark_version" = { type = "regex", pattern = "^[0-9]+\\.[0-9]+\\.x-.*" }
    },
    length(var.allowed_instance_types) > 0 ? {
      "node_type_id" = { type = "allowlist", values = var.allowed_instance_types }
    } : {}
  ))

  max_clusters_per_user = var.max_clusters_per_user
}

module "ip_access_list" {
  source = "./modules/ip-access-list"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_ip_access_list && length(var.allowed_ip_addresses) > 0 ? 1 : 0

  label        = var.ip_access_list_label
  list_type    = "ALLOW"
  ip_addresses = var.allowed_ip_addresses
  enabled      = true
}

module "admin_group" {
  source = "./modules/group"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_admin_group ? 1 : 0

  display_name = var.admin_group_name

  allow_cluster_create       = true
  allow_instance_pool_create = true
  databricks_sql_access      = true
  workspace_access           = true

  force = true
}

module "data_engineers_group" {
  source = "./modules/group"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_data_engineers_group ? 1 : 0

  display_name = var.data_engineers_group_name

  allow_cluster_create       = true
  allow_instance_pool_create = false
  databricks_sql_access      = true
  workspace_access           = true

  force = true

  depends_on = [module.admin_group]
}

module "data_scientists_group" {
  source = "./modules/group"
  providers = {
    databricks = databricks.workspace
  }
  count = var.create_data_scientists_group ? 1 : 0

  display_name = var.data_scientists_group_name

  allow_cluster_create       = true
  allow_instance_pool_create = false
  databricks_sql_access      = true
  workspace_access           = true

  force = true

  depends_on = [module.admin_group]
}
