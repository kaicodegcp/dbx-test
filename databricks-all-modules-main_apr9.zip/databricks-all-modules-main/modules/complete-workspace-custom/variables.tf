# =============================================================================
# Required Variables
# =============================================================================

variable "databricks_account_id" {
  description = "Databricks account ID"
  type        = string
}

variable "workspace_name" {
  description = "Name prefix for the workspace and all resources"
  type        = string
}

variable "aws_region" {
  description = "AWS region for deployment"
  type        = string
  default     = "us-west-2"
}

# =============================================================================
# Network Configuration (custom VPC - no VPC or PrivateLink creation by this module)
# =============================================================================

variable "vpc_id" {
  description = "Existing VPC ID where the workspace will be deployed"
  type        = string

  validation {
    condition     = can(regex("^vpc-[a-f0-9]{8,}$", var.vpc_id))
    error_message = "VPC ID must be in format: vpc-xxxxxxxx"
  }
}

variable "private_subnet_ids" {
  description = "List of private subnet IDs for the Databricks workspace (at least 2 in different AZs)"
  type        = list(string)
}

variable "vpc_cidr" {
  description = "CIDR block of the VPC (used for workspace security group egress to control plane)"
  type        = string
}

variable "public_subnet_ids" {
  description = "Optional list of public subnet IDs (for output passthrough only)"
  type        = list(string)
  default     = []
}

variable "nat_gateway_ids" {
  description = "Optional list of NAT gateway IDs (for output passthrough only)"
  type        = list(string)
  default     = []
}

# =============================================================================
# PrivateLink Configuration (pass AWS VPC endpoint IDs; module registers them with Databricks)
# =============================================================================

variable "enable_private_link" {
  description = "Use PrivateLink for workspace connectivity; provide AWS VPC endpoint IDs via rest_api_aws_vpc_endpoint_id and dataplane_relay_aws_vpc_endpoint_id"
  type        = bool
  default     = false
}

variable "rest_api_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks REST API. Required when enable_private_link = true. Module registers it with Databricks via databricks_mws_vpc_endpoint."
  type        = string
  default     = null
}

variable "dataplane_relay_aws_vpc_endpoint_id" {
  description = "AWS VPC endpoint ID for Databricks SCC dataplane relay. Required when enable_private_link = true. Module registers it with Databricks via databricks_mws_vpc_endpoint."
  type        = string
  default     = null
}

variable "privatelink_security_group_id" {
  description = "Optional PrivateLink security group ID (for output passthrough when using custom PrivateLink)"
  type        = string
  default     = null
}

variable "private_access_level" {
  description = "Private access level for the workspace (ACCOUNT or ENDPOINT)"
  type        = string
  default     = "ACCOUNT"

  validation {
    condition     = contains(["ACCOUNT", "ENDPOINT"], var.private_access_level)
    error_message = "Private access level must be ACCOUNT or ENDPOINT."
  }
}

variable "public_access_enabled" {
  description = "Whether public access is enabled for the workspace when PrivateLink is active"
  type        = bool
  default     = true
}

variable "sg_egress_ports" {
  description = "Egress ports for workspace SG to VPC CIDR (Databricks control plane ports)"
  type        = list(number)
  default     = [443, 2443, 5432, 6666, 8443, 8444, 8445, 8446, 8447, 8448, 8449, 8450, 8451]
}

# =============================================================================
# Security Configuration
# =============================================================================

variable "enable_cmk" {
  description = "Enable customer-managed keys for encryption (SRA recommended)"
  type        = bool
  default     = true
}

variable "pricing_tier" {
  description = "Workspace pricing tier (ENTERPRISE required for Unity Catalog)"
  type        = string
  default     = "ENTERPRISE"

  validation {
    condition     = contains(["STANDARD", "PREMIUM", "ENTERPRISE"], var.pricing_tier)
    error_message = "Pricing tier must be STANDARD, PREMIUM, or ENTERPRISE."
  }
}

variable "allowed_ip_addresses" {
  description = "List of allowed IP addresses/CIDR blocks for workspace access"
  type        = list(string)
  default     = []
}

variable "ip_access_list_label" {
  description = "Label for IP access list"
  type        = string
  default     = "corporate-network"
}

# =============================================================================
# Unity Catalog Configuration
# =============================================================================

variable "create_metastore" {
  description = "Create Unity Catalog metastore; set to false to attach to an existing metastore (provide metastore_id)"
  type        = bool
  default     = true
}

variable "metastore_id" {
  description = "Existing Unity Catalog metastore ID to attach to the workspace; required when create_metastore is false"
  type        = string
  default     = null
}

variable "metastore_owner" {
  description = "Owner of the metastore"
  type        = string
  default     = "account users"
}

variable "create_default_catalog" {
  description = "Create default catalog"
  type        = bool
  default     = true
}

variable "default_catalog_name" {
  description = "Name of the default catalog"
  type        = string
  default     = "main"
}

variable "catalog_owner" {
  description = "Owner of the default catalog"
  type        = string
  default     = "account users"
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for trust policy"
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

variable "catalog_properties" {
  description = "Properties/tags for the default catalog"
  type        = map(string)
  default     = {}
}

variable "catalog_isolation_mode" {
  description = "Catalog isolation mode (ISOLATED or OPEN). ISOLATED recommended for security"
  type        = string
  default     = "ISOLATED"

  validation {
    condition     = contains(["ISOLATED", "OPEN"], var.catalog_isolation_mode)
    error_message = "Catalog isolation mode must be ISOLATED or OPEN."
  }
}

# =============================================================================
# Medallion Architecture
# =============================================================================

variable "create_bronze_schema" {
  description = "Create bronze schema in default catalog (for medallion architecture)"
  type        = bool
  default     = false
}

variable "create_silver_schema" {
  description = "Create silver schema in default catalog (for medallion architecture)"
  type        = bool
  default     = false
}

variable "create_gold_schema" {
  description = "Create gold schema in default catalog (for medallion architecture)"
  type        = bool
  default     = false
}

# =============================================================================
# Workspace Security Configuration
# =============================================================================

variable "configure_workspace_security" {
  description = "Apply workspace security settings (data exfiltration prevention)"
  type        = bool
  default     = true
}

variable "create_cluster_policy" {
  description = "Create secure cluster policy"
  type        = bool
  default     = true
}

variable "cluster_policy_name" {
  description = "Name of the cluster policy"
  type        = string
  default     = "secure-production-policy"
}

variable "max_clusters_per_user" {
  description = "Maximum clusters per user (null for unlimited)"
  type        = number
  default     = null
}

variable "min_autotermination_minutes" {
  description = "Minimum autotermination minutes for cluster policy"
  type        = number
  default     = 10
}

variable "max_autotermination_minutes" {
  description = "Maximum autotermination minutes for cluster policy (10080 = 7 days)"
  type        = number
  default     = 10080
}

variable "allowed_instance_types" {
  description = "List of allowed instance types (empty = allow ALL types)"
  type        = list(string)
  default     = []
}

variable "allowed_spark_versions" {
  description = "Allowed Spark versions regex pattern (null = allow all standard versions)"
  type        = string
  default     = null
}

variable "create_ip_access_list" {
  description = "Create IP access list"
  type        = bool
  default     = true
}

variable "enable_web_terminal" {
  description = "Enable web terminal in workspace (SRA: false)"
  type        = bool
  default     = false
}

variable "max_token_lifetime_days" {
  description = "Maximum token lifetime in days (0 = no limit)"
  type        = number
  default     = 90
}

variable "create_admin_group" {
  description = "Create admin group"
  type        = bool
  default     = true
}

variable "admin_group_name" {
  description = "Name of the admin group"
  type        = string
  default     = "workspace-admins"
}

variable "create_data_engineers_group" {
  description = "Create data engineers group"
  type        = bool
  default     = false
}

variable "data_engineers_group_name" {
  description = "Name of data engineers group"
  type        = string
  default     = "data-engineers"
}

variable "create_data_scientists_group" {
  description = "Create data scientists group"
  type        = bool
  default     = false
}

variable "data_scientists_group_name" {
  description = "Name of data scientists group"
  type        = string
  default     = "data-scientists"
}

# =============================================================================
# Additional Configuration
# =============================================================================

variable "tags" {
  description = "Tags to apply to all resources"
  type        = map(string)
  default     = {}
}

variable "force_destroy" {
  description = "Allow force destroy of resources (set to true for testing)"
  type        = bool
  default     = false
}

# =============================================================================
# Deployment Configuration
# =============================================================================

variable "deployment_name" {
  description = "Deployment name for the workspace URL prefix. Must be enabled by a Databricks representative."
  type        = string
  default     = null
  nullable    = true
}

# =============================================================================
# GovCloud Configuration
# =============================================================================

variable "databricks_gov_shard" {
  description = "Databricks GovCloud shard type. Only applicable for us-gov-west-1 region."
  type        = string
  default     = null

  validation {
    condition     = var.databricks_gov_shard == null || can(contains(["civilian", "dod"], var.databricks_gov_shard))
    error_message = "Allowed values: null, civilian, dod."
  }
}

# =============================================================================
# KMS Configuration
# =============================================================================

variable "cmk_admin_arn" {
  description = "ARN of the CMK admin principal. Defaults to the AWS account root if not specified."
  type        = string
  default     = null
}

variable "root_bucket_versioning" {
  description = "Enable versioning on the root storage bucket. SRA recommends disabled."
  type        = bool
  default     = false
}

# =============================================================================
# Network Connectivity Configuration (NCC)
# =============================================================================

variable "enable_ncc" {
  description = "Enable Network Connectivity Configuration for serverless compute egress control (SRA recommended)"
  type        = bool
  default     = true
}

variable "create_nlb_private_endpoint_rule" {
  description = "Create NCC private endpoint rule for an NLB. Set to true when nlb_vpc_endpoint_service_name and nlb_domain_names are provided (or when the example creates the NLB). Must be known at plan time."
  type        = bool
  default     = false
}

variable "nlb_vpc_endpoint_service_name" {
  description = "Optional: AWS VPC endpoint service name for an NLB to add a private endpoint rule (e.g. com.amazonaws.vpce.us-west-2.vpce-svc-xxx). Required when create_nlb_private_endpoint_rule is true."
  type        = string
  default     = null
}

variable "nlb_domain_names" {
  description = "Optional: FQDNs reachable via the NLB for the NCC private endpoint rule. Required when create_nlb_private_endpoint_rule is true."
  type        = list(string)
  default     = []
}


# =============================================================================
# Audit Log Delivery
# =============================================================================

variable "enable_audit_logs" {
  description = "Enable audit log delivery to S3 (SRA recommended)"
  type        = bool
  default     = true
}

# =============================================================================
# Compliance Security Profile
# =============================================================================

variable "enable_csp" {
  description = "Enable Compliance Security Profile on the workspace (SRA recommended for regulated workloads)"
  type        = bool
  default     = false
}

variable "compliance_standards" {
  description = "List of compliance standards for CSP (e.g., HIPAA, PCI_DSS, FEDRAMP_MODERATE)"
  type        = list(string)
  default     = null
  nullable    = true
}


