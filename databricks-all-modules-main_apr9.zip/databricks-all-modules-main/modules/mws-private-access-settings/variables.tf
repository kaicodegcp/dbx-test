variable "private_access_settings_name" {
  description = "Human-readable name for the private access settings object in the Databricks account"
  type        = string

  validation {
    condition     = length(var.private_access_settings_name) > 0 && length(var.private_access_settings_name) <= 256
    error_message = "private_access_settings_name must be 1–256 characters."
  }
}

variable "region" {
  description = "AWS region where the private access settings apply (e.g. us-east-1)"
  type        = string
}

variable "account_id" {
  description = "Databricks account ID. Deprecated: prefer account_id on the databricks provider; when null (default), the resource omits this argument."
  type        = string
  default     = null
}

variable "allowed_vpc_endpoint_ids" {
  description = "When private_access_level is ENDPOINT, IDs of registered databricks_mws_vpc_endpoint resources allowed to access the workspace"
  type        = list(string)
  default     = null
}

variable "private_access_level" {
  description = "ACCOUNT (private access for entire account) or ENDPOINT (restrict to specific VPC endpoints)"
  type        = string
  default     = null

  validation {
    condition     = var.private_access_level == null || contains(["ACCOUNT", "ENDPOINT"], var.private_access_level)
    error_message = "private_access_level must be ACCOUNT, ENDPOINT, or null (omit)."
  }
}
