# Databricks account-level private access settings (PrivateLink / private connectivity).
# Configure the account provider (host = accounts.cloud.databricks.com) at the root module.
# See: https://registry.terraform.io/providers/databricks/databricks/latest/docs/resources/mws_private_access_settings

resource "databricks_mws_private_access_settings" "this" {
  private_access_settings_name = var.private_access_settings_name
  region                       = var.region

  account_id               = var.account_id
  allowed_vpc_endpoint_ids = var.allowed_vpc_endpoint_ids
  # Module policy: workspaces are not reachable from the public internet.
  public_access_enabled = false
  private_access_level  = var.private_access_level
}
