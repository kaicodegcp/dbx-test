package test

import (
	"regexp"
	"testing"

	"github.com/gruntwork-io/terratest/modules/terraform"
	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestMWSPrivateAccessSettingsModule(t *testing.T) {
	common.SkipIfShortMode(t, "MWS private access settings (terraform plan)")
	common.RequireDatabricksEnv(t)

	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("mws-pas")

	config := common.ModuleTestConfig{
		ModuleName:      "mws-private-access-settings",
		TestDescription: "MWS private access settings: public_access_enabled is fixed false in the module (not a variable)",
		RequiredVars: map[string]interface{}{
			"private_access_settings_name": uniqueID,
			"region":                       defaults.AWSRegion,
		},
		OptionalVars: map[string]interface{}{
			"private_access_level": "ACCOUNT",
		},
		ExpectedOutputs: []string{
			"id",
			"private_access_settings_id",
			"private_access_settings_name",
			"region",
		},
		SkipDestroy: true,
	}

	if config.ModulePath == "" {
		config.ModulePath = common.GetModulePath(config.ModuleName)
	}
	opts := common.GetTestTerraformOptions(t, config)

	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	assert.Regexp(t, regexp.MustCompile(`public_access_enabled\s*=\s*false`), plan,
		"module must set public_access_enabled = false (no variable override)")

	t.Logf("Successfully planned module: %s", config.ModuleName)
}
