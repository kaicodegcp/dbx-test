output "id" {
  description = "Terraform ID of the private access settings resource"
  value       = databricks_mws_private_access_settings.this.id
}

output "private_access_settings_id" {
  description = "Databricks private access settings ID (use when creating workspaces)"
  value       = databricks_mws_private_access_settings.this.private_access_settings_id
}

output "private_access_settings_name" {
  description = "Name of the private access settings"
  value       = databricks_mws_private_access_settings.this.private_access_settings_name
}

output "region" {
  description = "AWS region for these settings"
  value       = databricks_mws_private_access_settings.this.region
}
