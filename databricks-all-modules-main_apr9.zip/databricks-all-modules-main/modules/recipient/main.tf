resource "databricks_recipient" "recipient" {
  name                               = var.recipient_name
  comment                            = "Made by Terraform"
  authentication_type                = "DATABRICKS"
  data_recipient_global_metastore_id = var.metastore_global_id
}