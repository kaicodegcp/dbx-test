variable "recipient_name" {
  type = string
}

variable "metastore_global_id" {
  type = string
}
