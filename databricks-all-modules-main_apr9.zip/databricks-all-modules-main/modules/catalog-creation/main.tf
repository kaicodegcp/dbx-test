# =============================================================================
# Unity Catalog: Catalog + Schema Creation (from complete-workspace pattern)
# =============================================================================
# Creates: KMS key, storage credential, IAM role + policy, S3 bucket,
# external location, catalog, default namespace, and optional schemas with permissions.
# Requires: workspace has metastore assigned; AWS and Databricks workspace providers.
# =============================================================================

data "aws_caller_identity" "current" {}

resource "random_string" "suffix" {
  length  = 6
  special = false
  upper   = false
}

locals {
  suffix                 = random_string.suffix.result
  uc_catalog_bucket_name = "${var.name_prefix}-catalog-${var.workspace_id}"
  uc_catalog_role_name   = "${var.name_prefix}-catalog-${var.workspace_id}"
  uc_catalog_name_safe   = replace(local.uc_catalog_bucket_name, "-", "_")
  uc_iam_arn             = "arn:${var.aws_partition}:iam::${data.aws_caller_identity.current.account_id}:role/${local.uc_catalog_role_name}"
  cmk_admin_value        = var.cmk_admin_arn != null ? var.cmk_admin_arn : "arn:${var.aws_partition}:iam::${data.aws_caller_identity.current.account_id}:root"

  # SQS SSE-KMS: IAM + optional KMS grant (grant helps when the CMK is not managed here)
  catalog_file_events_sqs_uses_kms = var.enable_catalog_file_events && var.catalog_file_events_sqs_kms_key_id != null && trimspace(var.catalog_file_events_sqs_kms_key_id) != ""
}

# -----------------------------------------------------------------------------
# KMS - Catalog storage
# -----------------------------------------------------------------------------
module "kms_catalog_storage" {
  source  = "terraform-aws-modules/kms/aws"
  version = "~> 3.0"

  description = "KMS key for Databricks catalog storage"
  key_usage   = "ENCRYPT_DECRYPT"

  computed_aliases = {
    "catalog-storage" = {
      name = "${var.name_prefix}-catalog-storage-${local.suffix}-key"
    }
  }

  key_statements = [
    {
      sid    = "Enable IAM User Permissions"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.cmk_admin_value]
        }
      ]
      actions   = ["kms:*"]
      resources = ["*"]
    },
    {
      sid    = "Allow IAM Role to use the key"
      effect = "Allow"
      principals = [
        {
          type        = "AWS"
          identifiers = [local.uc_iam_arn]
        }
      ]
      actions   = ["kms:Decrypt", "kms:Encrypt", "kms:GenerateDataKey*"]
      resources = ["*"]
    }
  ]

  tags = merge(var.tags, { Name = "${var.name_prefix}-catalog-storage-key-${local.suffix}" })
}

# -----------------------------------------------------------------------------
# Storage credential (create before IAM role; Databricks returns external_id)
# -----------------------------------------------------------------------------
resource "databricks_storage_credential" "catalog" {
  name = "${local.uc_catalog_bucket_name}-storage-credential"

  aws_iam_role {
    role_arn = local.uc_iam_arn
  }
  isolation_mode = "ISOLATION_MODE_ISOLATED"
}

data "databricks_aws_unity_catalog_assume_role_policy" "this" {
  aws_account_id        = data.aws_caller_identity.current.account_id
  role_name             = local.uc_catalog_role_name
  unity_catalog_iam_arn = var.unity_catalog_iam_arn
  external_id           = databricks_storage_credential.catalog.aws_iam_role[0].external_id
}

data "databricks_aws_unity_catalog_policy" "this" {
  aws_account_id = data.aws_caller_identity.current.account_id
  bucket_name    = local.uc_catalog_bucket_name
  role_name      = local.uc_catalog_role_name
  kms_name       = module.kms_catalog_storage.key_arn
}

module "iam_policy_unity_catalog" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-policy"
  version = "~> 5.0"

  name   = "${var.name_prefix}-catalog-policy-${local.suffix}"
  policy = data.databricks_aws_unity_catalog_policy.this.json
}

module "iam_role_unity_catalog" {
  source  = "terraform-aws-modules/iam/aws//modules/iam-assumable-role"
  version = "~> 5.0"

  create_role                     = true
  role_name                       = local.uc_catalog_role_name
  role_requires_mfa               = false
  create_custom_role_trust_policy = true
  custom_role_trust_policy        = data.databricks_aws_unity_catalog_assume_role_policy.this.json
  trusted_role_arns               = []

  custom_role_policy_arns = [module.iam_policy_unity_catalog.arn]

  tags = merge(var.tags, { Name = local.uc_catalog_role_name })
}

module "s3_unity_catalog" {
  source  = "terraform-aws-modules/s3-bucket/aws"
  version = "~> 4.0"

  bucket        = local.uc_catalog_bucket_name
  force_destroy = var.force_destroy

  versioning = {
    enabled = false
  }

  block_public_acls       = true
  block_public_policy     = true
  ignore_public_acls      = true
  restrict_public_buckets = true

  server_side_encryption_configuration = {
    rule = {
      bucket_key_enabled = true
      apply_server_side_encryption_by_default = {
        sse_algorithm     = "aws:kms"
        kms_master_key_id = module.kms_catalog_storage.key_arn
      }
    }
  }

  tags = merge(var.tags, { Name = local.uc_catalog_bucket_name })
}

# -----------------------------------------------------------------------------
# Optional: SQS + S3 event notifications for Unity Catalog file events
# (e.g. Auto Loader). When enabled, wires queue_url into the external location.
# -----------------------------------------------------------------------------
module "catalog_file_events_sqs" {
  count   = var.enable_catalog_file_events ? 1 : 0
  source  = "terraform-aws-modules/sqs/aws"
  version = "~> 4.3"

  name                      = "${var.name_prefix}-cat-fe-${local.suffix}"
  message_retention_seconds = var.catalog_file_events_sqs_message_retention_seconds
  kms_master_key_id         = var.catalog_file_events_sqs_kms_key_id

  create_queue_policy = true
  queue_policy_statements = {
    AllowS3EventNotifications = {
      sid     = "AllowS3EventNotifications"
      effect  = "Allow"
      actions = ["sqs:SendMessage"]
      principals = [{
        type        = "Service"
        identifiers = ["s3.amazonaws.com"]
      }]
      conditions = [
        {
          test     = "ArnEquals"
          variable = "aws:SourceArn"
          values   = [module.s3_unity_catalog.s3_bucket_arn]
        },
        {
          test     = "StringEquals"
          variable = "aws:SourceAccount"
          values   = [data.aws_caller_identity.current.account_id]
        }
      ]
    }
  }

  tags = merge(var.tags, { Name = "${var.name_prefix}-catalog-file-events-${local.suffix}" })

  depends_on = [module.s3_unity_catalog]
}

resource "aws_s3_bucket_notification" "catalog_file_events" {
  count  = var.enable_catalog_file_events ? 1 : 0
  bucket = module.s3_unity_catalog.s3_bucket_id

  queue {
    id            = "catalog-file-events"
    queue_arn     = module.catalog_file_events_sqs[0].queue_arn
    events        = var.catalog_file_events_s3_events
    filter_prefix = var.catalog_file_events_s3_filter_prefix
    filter_suffix = var.catalog_file_events_s3_filter_suffix
  }

  depends_on = [
    module.s3_unity_catalog,
    module.catalog_file_events_sqs,
  ]
}

# -----------------------------------------------------------------------------
# UC storage credential IAM role: read file-events SQS + use CMK (if any)
# Databricks validates the queue during external location creation (READ_MESSAGE).
# Inline policy is always attached (empty when file events off) so downstream
# resources can use a static depends_on.
# -----------------------------------------------------------------------------
data "aws_iam_policy_document" "catalog_file_events_uc_empty" {}

data "aws_iam_policy_document" "catalog_file_events_uc" {
  count = var.enable_catalog_file_events ? 1 : 0

  # Provided-queue file events: IAM on storage credential role must match Databricks docs.
  # https://docs.databricks.com/aws/en/connect/unity-catalog/cloud-storage/manage-external-locations#using-a-provided-queue-for-s3
  statement {
    sid = "ManagedFileEventsReadStatement"
    actions = [
      "sqs:DeleteMessage",
      "sqs:ReceiveMessage",
      "sqs:SendMessage",
      "sqs:PurgeQueue",
    ]
    resources = [module.catalog_file_events_sqs[0].queue_arn]
  }

  dynamic "statement" {
    for_each = local.catalog_file_events_sqs_uses_kms ? [1] : []
    content {
      sid = "UnityCatalogFileEventsSqsKms"
      actions = [
        "kms:Decrypt",
        "kms:DescribeKey",
        "kms:GenerateDataKey",
        "kms:GenerateDataKeyWithoutPlaintext",
      ]
      resources = [var.catalog_file_events_sqs_kms_key_id]
    }
  }
}

resource "aws_iam_role_policy" "catalog_file_events_uc_access" {
  name = "${var.name_prefix}-catalog-fe-uc-${local.suffix}"
  role = module.iam_role_unity_catalog.iam_role_name

  policy = var.enable_catalog_file_events ? data.aws_iam_policy_document.catalog_file_events_uc[0].json : data.aws_iam_policy_document.catalog_file_events_uc_empty.json

  depends_on = [module.iam_role_unity_catalog]
}

# When the queue uses a customer-managed key, a grant lets the UC role use the key
# even if this module does not own the key policy (catalog storage key already allows the role).
resource "aws_kms_grant" "catalog_file_events_sqs" {
  count = local.catalog_file_events_sqs_uses_kms ? 1 : 0

  key_id            = var.catalog_file_events_sqs_kms_key_id
  grantee_principal = local.uc_iam_arn
  operations = [
    "Decrypt",
    "DescribeKey",
    "GenerateDataKey",
    "GenerateDataKeyWithoutPlaintext",
  ]

  depends_on = [module.iam_role_unity_catalog]
}

resource "time_sleep" "catalog_iam_propagation" {
  # Static list: inline policy always exists; KMS grant (when present) usually
  # finishes before sleep ends (parallel to this resource).
  depends_on = [
    module.iam_role_unity_catalog,
    aws_iam_role_policy.catalog_file_events_uc_access,
  ]
  create_duration = "60s"

  # If this resource already exists in state, Terraform does not re-run
  # create_duration when only a dependency (e.g. new SQS IAM policy) is added.
  # Databricks then validates the queue immediately and can fail with READ_MESSAGE.
  triggers = {
    file_events_iam_policy = aws_iam_role_policy.catalog_file_events_uc_access.policy
  }
}

# -----------------------------------------------------------------------------
# External location and catalog
# -----------------------------------------------------------------------------
resource "databricks_external_location" "catalog" {
  name            = "${local.uc_catalog_bucket_name}-external-location"
  url             = "s3://${local.uc_catalog_bucket_name}/"
  credential_name = databricks_storage_credential.catalog.id
  comment         = "External location for catalog"
  isolation_mode  = "ISOLATION_MODE_ISOLATED"

  enable_file_events = var.enable_catalog_file_events

  dynamic "file_event_queue" {
    for_each = var.enable_catalog_file_events ? [1] : []
    content {
      provided_sqs {
        queue_url = module.catalog_file_events_sqs[0].queue_url
      }
    }
  }

  # depends_on must be a static list (provider constraint). Queue URL in file_event_queue
  # implies dependency on module.catalog_file_events_sqs when file events are enabled.
  depends_on = [time_sleep.catalog_iam_propagation]
}

resource "databricks_catalog" "default" {
  name           = local.uc_catalog_name_safe
  comment        = "Catalog for workspace ${var.workspace_id}"
  isolation_mode = var.catalog_isolation_mode
  storage_root   = "s3://${local.uc_catalog_bucket_name}/"
  owner          = var.catalog_owner
  force_destroy  = var.force_destroy

  properties = merge(
    var.catalog_properties,
    { created_by = "terraform-catalog-creation-module" }
  )

  depends_on = [databricks_external_location.catalog]
}

# =============================================================================
# Catalog permissions (databricks_grant)
# =============================================================================
locals {
  catalog_grant_list = concat(
    [for group_name, privs in var.permissions.groups : {
      catalog_name = databricks_catalog.default.name
      principal    = group_name
      privileges   = privs
    }],
    [for sp_key, privs in var.permissions.service_principals : {
      catalog_name = databricks_catalog.default.name
      principal    = var.databricks_service_principal_app_ids[sp_key]
      privileges   = privs
    }]
  )
  catalog_grants = { for i, g in local.catalog_grant_list : "${g.catalog_name}_${g.principal}" => g }
}

resource "databricks_grant" "catalog_permission" {
  for_each = local.catalog_grants

  catalog    = each.value.catalog_name
  principal  = each.value.principal
  privileges = each.value.privileges
}

# =============================================================================
# Schemas (from var.schemas map)
# =============================================================================
module "schema" {
  for_each = var.schemas
  source   = "./modules/schema"

  catalog_name  = databricks_catalog.default.name
  name          = each.key
  comment       = each.value.comment
  properties    = {}
  force_destroy = var.force_destroy

  depends_on = [databricks_catalog.default]
}

# Flatten schema permissions into one grant per (schema, principal, privileges) for databricks_grant
locals {
  schema_grant_list = concat(
    flatten([
      for schema_name, schema_config in var.schemas : [
        for group_name, privs in try(schema_config.permissions.groups, {}) : {
          schema_full_name = "${databricks_catalog.default.name}.${schema_name}"
          principal        = group_name
          privileges       = privs
        }
      ]
    ]),
    flatten([
      for schema_name, schema_config in var.schemas : [
        for sp_key, privs in try(schema_config.permissions.service_principals, {}) : {
          schema_full_name = "${databricks_catalog.default.name}.${schema_name}"
          principal        = var.databricks_service_principal_app_ids[sp_key]
          privileges       = privs
        }
      ]
    ])
  )
  schema_grants = { for i, g in local.schema_grant_list : "${g.schema_full_name}_${g.principal}" => g }
}

resource "databricks_grant" "schema_permission" {
  for_each = local.schema_grants

  schema     = each.value.schema_full_name
  principal  = each.value.principal
  privileges = each.value.privileges

  depends_on = [module.schema]
}
