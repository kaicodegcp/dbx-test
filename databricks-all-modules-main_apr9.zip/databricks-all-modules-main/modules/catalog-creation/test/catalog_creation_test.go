package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

func TestCatalogCreationModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-creation")

	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests Unity Catalog catalog creation module (S3, KMS, IAM, storage credential, external location, optional file events with SQS IAM + time_sleep propagation, catalog, optional schemas)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"aws_partition":                "aws",
			"catalog_owner":                "account users",
			"catalog_isolation_mode":       "ISOLATED",
			"force_destroy":                true,
			"enable_catalog_file_events":   false,
			"schemas":                      map[string]interface{}{},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
			"tags": map[string]string{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"storage_credential_id",
			"external_location_name",
			"s3_bucket_name",
			"iam_role_arn",
			"kms_key_arn",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogCreationModuleInputValidation(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-inputs")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "999888777666555")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		ModulePath:      "..",
		TestDescription: "Validates catalog creation module required and optional inputs",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"schemas": map[string]interface{}{
				"bronze": map[string]interface{}{"comment": "Bronze layer"},
				"silver": map[string]interface{}{"comment": "Silver layer"},
				"gold":   map[string]interface{}{"comment": "Gold layer"},
			},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateRequiredInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateOptionalInputs", func(t *testing.T) {
		assert.Equal(t, "ISOLATED", opts.Vars["catalog_isolation_mode"])
		assert.NotEmpty(t, opts.Vars["schemas"])
		assert.NotNil(t, opts.Vars["permissions"])
		t.Log("Catalog creation optional inputs validated")
	})

	t.Run("FileEventsOptionalVars", func(t *testing.T) {
		feOpts := common.GetTestTerraformOptions(t, common.ModuleTestConfig{
			ModuleName: "catalog-creation",
			ModulePath: "..",
			RequiredVars: map[string]interface{}{
				"workspace_id": workspaceID,
				"name_prefix":  uniqueID,
			},
			OptionalVars: map[string]interface{}{
				"catalog_owner":          "account users",
				"catalog_isolation_mode": "ISOLATED",
				"schemas":                map[string]interface{}{},
				"permissions": map[string]interface{}{
					"groups":             map[string]interface{}{},
					"service_principals": map[string]interface{}{},
				},
				"enable_catalog_file_events": true,
				"catalog_file_events_s3_filter_prefix":              "landing/",
				"catalog_file_events_s3_filter_suffix":              ".parquet",
				"catalog_file_events_s3_events":                     []string{"s3:ObjectCreated:*"},
				"catalog_file_events_sqs_message_retention_seconds": 86400,
			},
		})
		require.True(t, feOpts.Vars["enable_catalog_file_events"].(bool))
		_, hasSqsKMS := feOpts.Vars["catalog_file_events_sqs_kms_key_id"]
		require.False(t, hasSqsKMS, "omit catalog_file_events_sqs_kms_key_id for SSE-SQS; module treats null/empty safely for optional KMS grants")
		assert.Equal(t, "landing/", feOpts.Vars["catalog_file_events_s3_filter_prefix"])
		assert.Equal(t, ".parquet", feOpts.Vars["catalog_file_events_s3_filter_suffix"])
		assert.Equal(t, []string{"s3:ObjectCreated:*"}, feOpts.Vars["catalog_file_events_s3_events"])
		assert.Equal(t, 86400, feOpts.Vars["catalog_file_events_sqs_message_retention_seconds"])
		t.Log("Catalog file-events optional inputs validated")
	})
}

func TestCatalogCreationModuleWithSchemas(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-schemas")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests catalog creation with configurable schemas (bronze, silver, gold)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"schemas": map[string]interface{}{
				"bronze": map[string]interface{}{"comment": "Bronze layer - raw data"},
				"silver": map[string]interface{}{"comment": "Silver layer - cleansed"},
				"gold":   map[string]interface{}{"comment": "Gold layer - aggregated"},
			},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"schema_ids",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogCreationModuleWithFileEvents(t *testing.T) {
	common.SkipIfShortMode(t, "catalog creation with file events (full terraform plan)")
	common.RequireDatabricksEnv(t)

	uniqueID := common.GenerateUniqueTestID("catalog-file-events")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		ModulePath:      common.GetModulePath("catalog-creation"),
		TestDescription: "Tests catalog creation with Unity Catalog file events: SQS, S3 notifications, UC role SQS IAM policy, time_sleep (triggers on that policy) before external location, file_event_queue",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"aws_partition":          "aws",
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"enable_catalog_file_events": true,
			"catalog_file_events_s3_events": []string{
				"s3:ObjectCreated:*",
			},
			"catalog_file_events_s3_filter_prefix": "raw/",
			"schemas":                              map[string]interface{}{},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
			"tags": map[string]string{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"external_location_name",
			"catalog_file_events_sqs_queue_url",
			"catalog_file_events_sqs_queue_arn",
		},
		SkipDestroy: true,
	}

	opts := common.GetTestTerraformOptions(t, config)
	terraform.Init(t, opts)
	plan := terraform.Plan(t, opts)
	require.NotEmpty(t, plan, "terraform plan should produce output")

	// UC storage credential role: SQS read policy for Databricks file-events validation (READ_MESSAGE).
	assert.Contains(t, plan, "aws_iam_role_policy.catalog_file_events_uc_access")
	// Waits for IAM propagation; triggers on inline policy JSON so replacement runs when file-events IAM changes.
	assert.Contains(t, plan, "time_sleep.catalog_iam_propagation")
	assert.Contains(t, plan, "file_events_iam_policy", "time_sleep triggers must include file_events_iam_policy so policy updates re-run the wait")
	assert.Contains(t, plan, "databricks_external_location.catalog")
	assert.Contains(t, plan, "aws_s3_bucket_notification.catalog_file_events")
	assert.Contains(t, plan, "module.catalog_file_events_sqs")
}

func TestCatalogCreationModuleWithCatalogPermissions(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-perms")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests catalog creation with catalog-level permissions (databricks_grant)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"permissions": map[string]interface{}{
				"groups": map[string]interface{}{
					"account users": []string{"USE_CATALOG", "USE_SCHEMA"},
				},
				"service_principals": map[string]interface{}{},
			},
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogCreationModuleWithSchemaPermissions(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-schema-perms")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests catalog creation with schema-level permissions (databricks_grant)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"schemas": map[string]interface{}{
				"bronze": map[string]interface{}{
					"comment": "Bronze layer",
					"permissions": map[string]interface{}{
						"groups":             map[string]interface{}{"account users": []string{"USE_SCHEMA", "USE_TABLE"}},
						"service_principals": map[string]interface{}{},
					},
				},
			},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"schema_ids",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
