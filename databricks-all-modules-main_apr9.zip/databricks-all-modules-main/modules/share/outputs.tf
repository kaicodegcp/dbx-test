output "id" {
  description = "The unique identifier for the share"
  value       = databricks_share.share.id
}

output "name" {
  description = "The name of the share"
  value       = databricks_share.share.name
}
