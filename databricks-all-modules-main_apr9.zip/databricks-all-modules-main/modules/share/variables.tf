variable "share_name" {
  type = string
}

variable "catalog_name" {
  type = string
}

variable "schema_name" {
  type = string
}

variable "recipients" {
  type = list
}