package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestCatalogReceivingShareModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("receiving-catalog")
	providerName := common.GetEnvOrDefault("TEST_RECEIVING_PROVIDER_NAME", "placeholder-provider")
	shareName := common.GetEnvOrDefault("TEST_RECEIVING_SHARE_NAME", "placeholder-share")

	// permissions: same shape as catalog-creation (groups/service_principals = map(list(string)))
	permissions := map[string]interface{}{
		"groups":             map[string]interface{}{},
		"service_principals": map[string]interface{}{},
	}

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-receiving-share",
		ModulePath:      "..",
		TestDescription: "Tests Databricks receiving catalog from Delta Share (with optional grants)",
		RequiredVars: map[string]interface{}{
			"catalog_name":                       uniqueID,
			"catalog_comment":                    "Test receiving catalog created by terratest",
			"provider_name":                      providerName,
			"share_name":                         shareName,
			"permissions":                        permissions,
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogReceivingShareModuleWithPermissions(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("receiving-catalog-perms")
	providerName := common.GetEnvOrDefault("TEST_RECEIVING_PROVIDER_NAME", "placeholder-provider")
	shareName := common.GetEnvOrDefault("TEST_RECEIVING_SHARE_NAME", "placeholder-share")

	// permissions: groups = map(principal -> list(privileges)), same as catalog-creation
	permissions := map[string]interface{}{
		"groups": map[string]interface{}{
			"account users": []string{"USE_CATALOG", "USE_SCHEMA"},
		},
		"service_principals": map[string]interface{}{},
	}

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-receiving-share",
		ModulePath:      "..",
		TestDescription: "Tests receiving catalog with group permissions",
		RequiredVars: map[string]interface{}{
			"catalog_name":                       uniqueID,
			"catalog_comment":                    "Test receiving catalog with grants",
			"provider_name":                      providerName,
			"share_name":                         shareName,
			"permissions":                        permissions,
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
		},
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogReceivingShareModuleInputValidation(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("receiving-catalog-inputs")
	providerName := common.GetEnvOrDefault("TEST_RECEIVING_PROVIDER_NAME", "placeholder-provider")
	shareName := common.GetEnvOrDefault("TEST_RECEIVING_SHARE_NAME", "placeholder-share")

	permissions := map[string]interface{}{
		"groups":             map[string]interface{}{},
		"service_principals": map[string]interface{}{},
	}

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-receiving-share",
		ModulePath:      "..",
		TestDescription: "Validates catalog-receiving-share module required inputs",
		RequiredVars: map[string]interface{}{
			"catalog_name":                       uniqueID,
			"catalog_comment":                    "Test comment",
			"provider_name":                      providerName,
			"share_name":                         shareName,
			"permissions":                        permissions,
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateRequiredInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}
