variable "catalog_name" {
  type = string
}

variable "catalog_comment" {
  type = string
}

variable "provider_name" {
  type = string
}

variable "share_name" {
  type = string
}

variable "databricks_service_principal_app_ids" {
  description = "Service principal name to application ID map (used for catalog permissions)"
  type        = map(string)
  default     = {}
}

variable "permissions" {
  description = "Catalog-level permissions (groups and service principals with list of privileges). Service principal keys must exist in databricks_service_principal_app_ids."
  type = object({
    groups             = map(list(string))
    service_principals = map(list(string))
  })
  default = {
    groups             = {}
    service_principals = {}
  }
}

