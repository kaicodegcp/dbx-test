# Create catalog
resource "databricks_catalog" "receiving_catalog" {
  name          = var.catalog_name
  comment       = var.catalog_comment
  provider_name = var.provider_name
  share_name    = var.share_name
}

# Catalog permissions (databricks_grant) - same pattern as catalog-creation
locals {
  receiving_catalog_grant_list = concat(
    [for group_name, privs in var.permissions.groups : {
      catalog_name = databricks_catalog.receiving_catalog.name
      principal    = group_name
      privileges   = privs
    }],
    [for sp_key, privs in var.permissions.service_principals : {
      catalog_name = databricks_catalog.receiving_catalog.name
      principal    = var.databricks_service_principal_app_ids[sp_key]
      privileges   = privs
    }]
  )
  receiving_catalog_grants = { for i, g in local.receiving_catalog_grant_list : "${g.catalog_name}_${g.principal}" => g }
}

resource "databricks_grant" "catalog_permission" {
  for_each = local.receiving_catalog_grants

  catalog    = each.value.catalog_name
  principal  = each.value.principal
  privileges = each.value.privileges

  depends_on = [databricks_catalog.receiving_catalog]
}
