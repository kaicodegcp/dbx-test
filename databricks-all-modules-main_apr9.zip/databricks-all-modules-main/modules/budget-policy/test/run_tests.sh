#!/bin/bash
# Run budget-policy tests. This module uses the account-level Budget Policy API.
# Point the Databricks provider at the account console (not a workspace URL), e.g.:
#   export DATABRICKS_HOST="https://accounts.cloud.databricks.com"
#   export DATABRICKS_ACCOUNT_ID="<uuid>"
# alongside DATABRICKS_CLIENT_ID / DATABRICKS_CLIENT_SECRET (or token).
#
# Usage: from repo root: ./modules/budget-policy/test/run_tests.sh
#        or from this dir: ./run_tests.sh
set -e
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
REPO_ROOT="$(cd "$SCRIPT_DIR/../../.." && pwd)"
SECRETS="$REPO_ROOT/secrets"

if [ ! -f "$SECRETS" ]; then
  echo "Secrets file not found: $SECRETS"
  echo "Create it with exports for account-level auth (see header comment)."
  exit 1
fi

echo "Sourcing secrets from $SECRETS"
# shellcheck source=/dev/null
source "$SECRETS"

cd "$SCRIPT_DIR"
go test -v -run 'TestBudgetPolicy' -timeout 10m -count=1 .
