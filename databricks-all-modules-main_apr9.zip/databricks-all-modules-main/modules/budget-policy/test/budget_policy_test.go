package test

import (
	"os"
	"strconv"
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
)

func TestBudgetPolicyModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("budget-policy")

	config := common.ModuleTestConfig{
		ModuleName:      "budget-policy",
		TestDescription: "Tests Databricks serverless budget policy module (account-level provider)",
		RequiredVars: map[string]interface{}{
			"policy_name": uniqueID,
			"custom_tags": []interface{}{
				map[string]interface{}{
					"key":   "terraform-module-test",
					"value": "budget-policy",
				},
			},
		},
		ExpectedOutputs: []string{
			"id",
			"policy_id",
			"policy_name",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestBudgetPolicyModuleWithWorkspaceBinding(t *testing.T) {
	raw := os.Getenv("TEST_BUDGET_POLICY_WORKSPACE_ID")
	if raw == "" {
		t.Skip("Set TEST_BUDGET_POLICY_WORKSPACE_ID (numeric workspace ID) to run workspace binding test")
	}
	wsID, err := strconv.ParseInt(raw, 10, 64)
	if err != nil {
		t.Fatalf("TEST_BUDGET_POLICY_WORKSPACE_ID must be a numeric workspace id: %v", err)
	}

	uniqueID := common.GenerateUniqueTestID("budget-policy-ws")

	config := common.ModuleTestConfig{
		ModuleName:      "budget-policy",
		TestDescription: "Tests budget policy with binding_workspace_ids",
		RequiredVars: map[string]interface{}{
			"policy_name": uniqueID,
			"custom_tags": []interface{}{
				map[string]interface{}{
					"key":   "terraform-module-test",
					"value": "budget-policy-bound",
				},
			},
			"binding_workspace_ids": []interface{}{float64(wsID)},
		},
		ExpectedOutputs: []string{
			"id",
			"policy_id",
			"policy_name",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
