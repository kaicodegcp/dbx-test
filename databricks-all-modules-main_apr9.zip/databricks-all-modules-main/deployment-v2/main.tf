# =============================================================================
# Databricks Workspace Deployment - Using complete-workspace Module
# =============================================================================

terraform {
  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.0.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
  }
}

provider "databricks" {
  alias      = "account"
  host       = "https://accounts.cloud.databricks.com"
  account_id = var.databricks_account_id
}

provider "databricks" {
  alias = "workspace"
  host  = module.complete_workspace.workspace_url
}

provider "aws" {
  region = var.aws_region
}

# =============================================================================
# CREATE COMPLETE WORKSPACE
# =============================================================================

module "complete_workspace" {
  source = "../databricks-all-modules/modules/complete-workspace"

  providers = {
    databricks.account   = databricks.account
    databricks.workspace = databricks.workspace
  }

  # Required
  databricks_account_id = var.databricks_account_id
  workspace_name        = var.workspace_name
  aws_region            = var.aws_region

  # Deployment
  deployment_name = var.deployment_name

  # Network Configuration
  vpc_cidr             = var.vpc_cidr
  private_subnets_cidr = var.private_subnets_cidr
  public_subnets_cidr  = var.public_subnets_cidr
  single_nat_gateway   = var.single_nat_gateway

  # PrivateLink Configuration
  enable_private_link      = var.enable_private_link
  privatelink_subnets_cidr = var.privatelink_subnets_cidr

  # GovCloud Configuration
  databricks_gov_shard = var.databricks_gov_shard

  # Security Configuration
  enable_cmk           = var.enable_cmk
  cmk_admin_arn        = var.cmk_admin_arn
  pricing_tier         = var.pricing_tier
  allowed_ip_addresses = var.allowed_ip_addresses
  ip_access_list_label = var.ip_access_list_label

  # Root Bucket
  root_bucket_versioning = var.root_bucket_versioning

  # NCC
  enable_ncc = var.enable_ncc

  # Audit Log Delivery
  enable_audit_logs = var.enable_audit_logs

  # Compliance Security Profile
  enable_csp           = var.enable_csp
  compliance_standards = var.compliance_standards

  # Unity Catalog Configuration
  create_metastore       = var.create_metastore
  metastore_owner        = var.metastore_owner
  create_default_catalog = var.create_default_catalog
  default_catalog_name   = var.default_catalog_name
  catalog_owner          = var.catalog_owner

  # Workspace Security
  configure_workspace_security = var.configure_workspace_security

  # Cluster Policy
  create_cluster_policy       = var.create_cluster_policy
  cluster_policy_name         = var.cluster_policy_name
  max_clusters_per_user       = var.max_clusters_per_user
  min_autotermination_minutes = var.min_autotermination_minutes
  max_autotermination_minutes = var.max_autotermination_minutes
  allowed_instance_types      = var.allowed_instance_types
  allowed_spark_versions      = var.allowed_spark_versions

  # Groups
  create_admin_group          = var.create_admin_group
  admin_group_name            = var.admin_group_name
  create_data_engineers_group = var.create_data_engineers_group
  data_engineers_group_name   = var.data_engineers_group_name
  create_data_scientists_group = var.create_data_scientists_group
  data_scientists_group_name  = var.data_scientists_group_name

  # Catalog
  catalog_isolation_mode = var.catalog_isolation_mode

  # Medallion Architecture
  create_bronze_schema = var.create_bronze_schema
  create_silver_schema = var.create_silver_schema
  create_gold_schema   = var.create_gold_schema

  # Tags & Operational
  tags          = var.tags
  force_destroy = var.force_destroy
}

# =============================================================================
# OUTPUTS
# =============================================================================

output "workspace_url" {
  description = "Databricks Workspace URL"
  value       = module.complete_workspace.workspace_url
}

output "workspace_id" {
  description = "Databricks Workspace ID"
  value       = module.complete_workspace.workspace_id
}

output "workspace_info" {
  description = "Complete workspace information"
  value       = module.complete_workspace.workspace_info
}

output "vpc_id" {
  description = "VPC ID"
  value       = module.complete_workspace.vpc_id
}

output "s3_bucket_name" {
  description = "S3 bucket name"
  value       = module.complete_workspace.s3_bucket_name
}

output "metastore_id" {
  description = "Unity Catalog metastore ID"
  value       = module.complete_workspace.metastore_id
}

output "default_catalog_name" {
  description = "Default catalog name"
  value       = module.complete_workspace.default_catalog_name
}

output "security_summary" {
  description = "Security features enabled"
  value = {
    cmk_encryption          = module.complete_workspace.managed_services_cmk_id != null
    private_link            = var.enable_private_link
    unity_catalog           = module.complete_workspace.metastore_id != null
    security_settings       = true
    cluster_policy          = module.complete_workspace.secure_cluster_policy_id != null
    admin_group             = module.complete_workspace.admin_group_id != null
    ncc                     = var.enable_ncc
    audit_logs              = var.enable_audit_logs
    csp                     = var.enable_csp
  }
}

output "private_access_settings_id" {
  description = "Private access settings ID (when PrivateLink enabled)"
  value       = module.complete_workspace.private_access_settings_id
}

output "privatelink_security_group_id" {
  description = "PrivateLink security group ID"
  value       = module.complete_workspace.privatelink_security_group_id
}

output "ncc_id" {
  description = "Network Connectivity Configuration ID"
  value       = module.complete_workspace.ncc_id
}


output "audit_log_s3_bucket_name" {
  description = "Audit log delivery S3 bucket name"
  value       = module.complete_workspace.audit_log_s3_bucket_name
}
