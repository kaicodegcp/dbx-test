# =============================================================================
# Required Variables
# =============================================================================

variable "databricks_account_id" {
  description = "Databricks Account ID"
  type        = string
  default     = "0d26daa6-5e44-4c97-a497-ef015f91254a"
}

variable "workspace_name" {
  description = "Workspace name"
  type        = string
  default     = "terraform-workspace"
}

variable "aws_region" {
  description = "AWS Region"
  type        = string
  default     = "us-west-2"
}

# =============================================================================
# Deployment Configuration
# =============================================================================

variable "deployment_name" {
  description = "Deployment name for the workspace URL prefix. Must be enabled by a Databricks representative."
  type        = string
  default     = null
}

# =============================================================================
# Network Configuration
# =============================================================================

variable "vpc_cidr" {
  description = "VPC CIDR block"
  type        = string
  default     = "10.0.0.0/16"
}

variable "private_subnets_cidr" {
  description = "Private subnet CIDR blocks"
  type        = list(string)
  default     = ["10.0.1.0/24", "10.0.2.0/24"]
}

variable "public_subnets_cidr" {
  description = "Public subnet CIDR blocks"
  type        = list(string)
  default     = ["10.0.101.0/24", "10.0.102.0/24"]
}

variable "single_nat_gateway" {
  description = "Use single NAT gateway (cost optimization, ignored when PrivateLink enabled)"
  type        = bool
  default     = true
}

# =============================================================================
# PrivateLink Configuration
# =============================================================================

variable "enable_private_link" {
  description = "Enable AWS PrivateLink for workspace connectivity (SRA recommended)"
  type        = bool
  default     = true
}

variable "privatelink_subnets_cidr" {
  description = "CIDR blocks for PrivateLink (intra) subnets"
  type        = list(string)
  default     = ["10.0.201.0/24", "10.0.202.0/24"]
}

# =============================================================================
# GovCloud Configuration
# =============================================================================

variable "databricks_gov_shard" {
  description = "Databricks GovCloud shard type. Only applicable for us-gov-west-1 region."
  type        = string
  default     = null
}

# =============================================================================
# Security Configuration
# =============================================================================

variable "enable_cmk" {
  description = "Enable customer-managed keys"
  type        = bool
  default     = true
}

variable "cmk_admin_arn" {
  description = "ARN of the CMK admin principal. Defaults to the AWS account root."
  type        = string
  default     = null
}

variable "pricing_tier" {
  description = "Workspace pricing tier"
  type        = string
  default     = "ENTERPRISE"
}

variable "allowed_ip_addresses" {
  description = "Allowed IP addresses for workspace access"
  type        = list(string)
  default     = []
}

variable "ip_access_list_label" {
  description = "IP access list label"
  type        = string
  default     = "corporate-network"
}

variable "root_bucket_versioning" {
  description = "Enable versioning on the root storage bucket. SRA recommends disabled."
  type        = bool
  default     = false
}

# =============================================================================
# NCC
# =============================================================================

variable "enable_ncc" {
  description = "Enable Network Connectivity Configuration for serverless compute egress control"
  type        = bool
  default     = false
}

# =============================================================================
# Audit Log Delivery
# =============================================================================

variable "enable_audit_logs" {
  description = "Enable audit log delivery to S3"
  type        = bool
  default     = false
}

# =============================================================================
# Compliance Security Profile
# =============================================================================

variable "enable_csp" {
  description = "Enable Compliance Security Profile on the workspace"
  type        = bool
  default     = false
}

variable "compliance_standards" {
  description = "List of compliance standards for CSP"
  type        = list(string)
  default     = null
}

# =============================================================================
# Unity Catalog Configuration
# =============================================================================

variable "create_metastore" {
  description = "Create Unity Catalog metastore"
  type        = bool
  default     = true
}

variable "metastore_owner" {
  description = "Metastore owner"
  type        = string
  default     = "account users"
}

variable "create_default_catalog" {
  description = "Create default catalog"
  type        = bool
  default     = true
}

variable "default_catalog_name" {
  description = "Default catalog name"
  type        = string
  default     = "main"
}

variable "catalog_owner" {
  description = "Catalog owner"
  type        = string
  default     = "account users"
}

# =============================================================================
# Workspace Security
# =============================================================================

variable "configure_workspace_security" {
  description = "Configure workspace security settings"
  type        = bool
  default     = true
}

# =============================================================================
# Cluster Policy
# =============================================================================

variable "create_cluster_policy" {
  description = "Create secure cluster policy"
  type        = bool
  default     = true
}

variable "cluster_policy_name" {
  description = "Cluster policy name"
  type        = string
  default     = "secure-production-policy"
}

variable "max_clusters_per_user" {
  description = "Max clusters per user (null = unlimited)"
  type        = number
  default     = null
}

variable "min_autotermination_minutes" {
  description = "Minimum autotermination minutes for cluster policy"
  type        = number
  default     = 10
}

variable "max_autotermination_minutes" {
  description = "Maximum autotermination minutes for cluster policy (10080 = 7 days)"
  type        = number
  default     = 10080
}

variable "allowed_instance_types" {
  description = "List of allowed instance types (empty = allow all)"
  type        = list(string)
  default     = []
}

variable "allowed_spark_versions" {
  description = "Allowed Spark versions regex (null = allow all standard versions)"
  type        = string
  default     = null
}

# =============================================================================
# Groups
# =============================================================================

variable "create_admin_group" {
  description = "Create admin group"
  type        = bool
  default     = true
}

variable "admin_group_name" {
  description = "Admin group name"
  type        = string
  default     = "workspace-admins"
}

variable "create_data_engineers_group" {
  description = "Create data engineers group"
  type        = bool
  default     = false
}

variable "data_engineers_group_name" {
  description = "Name of data engineers group"
  type        = string
  default     = "data-engineers"
}

variable "create_data_scientists_group" {
  description = "Create data scientists group"
  type        = bool
  default     = false
}

variable "data_scientists_group_name" {
  description = "Name of data scientists group"
  type        = string
  default     = "data-scientists"
}

# =============================================================================
# Medallion Architecture
# =============================================================================

variable "create_bronze_schema" {
  description = "Create bronze schema in default catalog"
  type        = bool
  default     = false
}

variable "create_silver_schema" {
  description = "Create silver schema in default catalog"
  type        = bool
  default     = false
}

variable "create_gold_schema" {
  description = "Create gold schema in default catalog"
  type        = bool
  default     = false
}

# =============================================================================
# Catalog Configuration
# =============================================================================

variable "catalog_isolation_mode" {
  description = "Catalog isolation mode (ISOLATED or OPEN)"
  type        = string
  default     = "ISOLATED"
}

# =============================================================================
# Tags & Operational
# =============================================================================

variable "tags" {
  description = "AWS resource tags"
  type        = map(string)
  default = {
    ManagedBy = "Terraform"
  }
}

variable "force_destroy" {
  description = "Allow force destroy (true for dev/test)"
  type        = bool
  default     = true
}
