#!/bin/bash
#
# Databricks Terraform Module Test Runner
# This script sets up the environment and runs all tests
#

set -e

echo "=========================================="
echo "Databricks Terraform Module Test Suite"
echo "=========================================="
echo ""

# Colors for output
RED='\033[0;31m'
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
NC='\033[0m' # No Color

# Function to print colored output
print_success() {
    echo -e "${GREEN}✓ $1${NC}"
}

print_error() {
    echo -e "${RED}✗ $1${NC}"
}

print_warning() {
    echo -e "${YELLOW}⚠ $1${NC}"
}

print_info() {
    echo "ℹ $1"
}

# Set credentials from environment (do not hardcode - use export before running)
# Example: export DATABRICKS_CLIENT_ID="your-client-id"
# Example: export DATABRICKS_CLIENT_SECRET="your-client-secret"
# Example: export AWS_ACCESS_KEY_ID="your-access-key"
# Example: export AWS_SECRET_ACCESS_KEY="your-secret-key"
# Example: export AWS_SESSION_TOKEN="your-session-token"  # if using temporary credentials

# You need to set these based on your Databricks environment
# For workspace-level resources:
export DATABRICKS_HOST="${DATABRICKS_HOST:-https://your-workspace.cloud.databricks.com}"

# For account-level resources (optional):
export DATABRICKS_ACCOUNT_ID="${DATABRICKS_ACCOUNT_ID:-your-account-id}"

echo "Step 1: Checking Prerequisites"
echo "----------------------------------------------"

# Check if Go is installed
if ! command -v go &> /dev/null; then
    print_error "Go is not installed!"
    echo ""
    echo "Please install Go 1.21+ from: https://golang.org/dl/"
    echo "Or use Homebrew: brew install go"
    exit 1
else
    GO_VERSION=$(go version)
    print_success "Go is installed: $GO_VERSION"
fi

# Check if Terraform is installed
if ! command -v terraform &> /dev/null; then
    print_warning "Terraform is not installed (optional for tests)"
    echo "Install from: https://www.terraform.io/downloads"
else
    TF_VERSION=$(terraform version | head -1)
    print_success "Terraform is installed: $TF_VERSION"
fi

echo ""
echo "Step 2: Verifying Environment Variables"
echo "----------------------------------------------"

# Check required environment variables
if [ -z "$DATABRICKS_HOST" ] || [ "$DATABRICKS_HOST" == "https://your-workspace.cloud.databricks.com" ]; then
    print_warning "DATABRICKS_HOST is not set or using default placeholder"
    echo "Please set your actual Databricks workspace URL"
    echo "Example: export DATABRICKS_HOST='https://xxxxx.cloud.databricks.com'"
    echo ""
    read -p "Enter your Databricks workspace URL (or press Enter to skip): " USER_HOST
    if [ -n "$USER_HOST" ]; then
        export DATABRICKS_HOST="$USER_HOST"
        print_success "DATABRICKS_HOST set to: $DATABRICKS_HOST"
    else
        print_warning "Continuing without DATABRICKS_HOST (some tests will be skipped)"
    fi
else
    print_success "DATABRICKS_HOST is set: $DATABRICKS_HOST"
fi

if [ -n "$DATABRICKS_CLIENT_ID" ]; then
    print_success "DATABRICKS_CLIENT_ID is set"
else
    print_error "DATABRICKS_CLIENT_ID is not set"
fi

if [ -n "$DATABRICKS_CLIENT_SECRET" ]; then
    print_success "DATABRICKS_CLIENT_SECRET is set"
else
    print_error "DATABRICKS_CLIENT_SECRET is not set"
fi

if [ -n "$AWS_ACCESS_KEY_ID" ]; then
    print_success "AWS_ACCESS_KEY_ID is set"
else
    print_warning "AWS_ACCESS_KEY_ID is not set"
fi

echo ""
echo "Step 3: Installing Go Dependencies"
echo "----------------------------------------------"

if go mod download; then
    print_success "Go dependencies downloaded successfully"
else
    print_error "Failed to download Go dependencies"
    exit 1
fi

echo ""
echo "Step 4: Test Execution Options"
echo "----------------------------------------------"
echo "Choose test execution mode:"
echo "  1) Quick test (single module - directory)"
echo "  2) Basic tests (5 simple modules)"
echo "  3) Unity Catalog tests"
echo "  4) Compute tests"
echo "  5) Security tests"
echo "  6) All tests (long-running, 30+ minutes)"
echo "  7) Custom test (specify module name)"
echo ""

read -p "Enter your choice (1-7) [default: 1]: " TEST_CHOICE
TEST_CHOICE=${TEST_CHOICE:-1}

echo ""
echo "Starting Tests..."
echo "=========================================="
echo ""

case $TEST_CHOICE in
    1)
        print_info "Running quick test (directory module)..."
        go test -v -timeout 10m ./databricks-modules/ -run TestDirectoryModule
        ;;
    2)
        print_info "Running basic tests (5 simple modules)..."
        go test -v -timeout 20m ./databricks-modules/ -run "TestDirectory|TestNotebook|TestGroup|TestUser|TestToken"
        ;;
    3)
        print_info "Running Unity Catalog tests..."
        go test -v -timeout 30m ./databricks-modules/ -run "Catalog|Schema|Table|Metastore|StorageCredential|ExternalLocation"
        ;;
    4)
        print_info "Running Compute tests..."
        go test -v -timeout 30m ./databricks-modules/ -run "Cluster|InstancePool|Policy|InitScript"
        ;;
    5)
        print_info "Running Security tests..."
        go test -v -timeout 30m ./databricks-modules/ -run "Group|User|ServicePrincipal|Permission|Secret|Token|IPAccess"
        ;;
    6)
        print_info "Running ALL tests (this will take a while)..."
        go test -v -timeout 60m ./databricks-modules/...
        ;;
    7)
        read -p "Enter test name (e.g., TestCatalogModule): " TEST_NAME
        print_info "Running custom test: $TEST_NAME"
        go test -v -timeout 20m ./databricks-modules/ -run "$TEST_NAME"
        ;;
    *)
        print_error "Invalid choice"
        exit 1
        ;;
esac

TEST_EXIT_CODE=$?

echo ""
echo "=========================================="
echo "Test Execution Complete!"
echo "=========================================="

if [ $TEST_EXIT_CODE -eq 0 ]; then
    print_success "All tests passed! 🎉"
    exit 0
else
    print_error "Some tests failed. Check the output above for details."
    exit 1
fi


