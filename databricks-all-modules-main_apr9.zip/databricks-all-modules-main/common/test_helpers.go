package common

import (
	"crypto/tls"
	"fmt"
	"net"
	"net/url"
	"os"
	"testing"
	"time"

	"github.com/stretchr/testify/require"
)

// TLSResult contains TLS validation results
type TLSResult struct {
	Host               string
	Port               int
	NegotiatedVersion  string
	Cipher             string
	CertificateOK      bool
	MeetsMinimum       bool
	LegacyTLS10Rejected *bool
	LegacyTLS11Rejected *bool
	Error              string
}

// GetEnvOrDefault returns environment variable value or default
func GetEnvOrDefault(key, defaultValue string) string {
	if value := os.Getenv(key); value != "" {
		return value
	}
	return defaultValue
}

// RequireEnv requires an environment variable to be set
func RequireEnv(t *testing.T, key string) string {
	value := os.Getenv(key)
	require.NotEmpty(t, value, fmt.Sprintf("Environment variable %s must be set", key))
	return value
}

// GenerateUniqueID generates a unique identifier for test resources
func GenerateUniqueID(prefix string) string {
	timestamp := time.Now().Unix()
	return fmt.Sprintf("%s-%d", prefix, timestamp)
}

// RetryWithBackoff retries a function with exponential backoff
func RetryWithBackoff(t *testing.T, maxRetries int, initialDelay time.Duration, fn func() error) error {
	delay := initialDelay
	var lastErr error

	for i := 0; i < maxRetries; i++ {
		if err := fn(); err == nil {
			return nil
		} else {
			lastErr = err
			t.Logf("Retry %d/%d failed: %v (waiting %v)", i+1, maxRetries, err, delay)
			time.Sleep(delay)
			delay *= 2 // Exponential backoff
		}
	}

	return fmt.Errorf("failed after %d retries: %w", maxRetries, lastErr)
}

// CheckTLSConnection validates TLS configuration for a given URL
func CheckTLSConnection(t *testing.T, targetURL string, minTLSVersion uint16, testLegacy bool) TLSResult {
	parsedURL, err := url.Parse(targetURL)
	require.NoError(t, err, "Invalid URL")
	require.Equal(t, "https", parsedURL.Scheme, "URL must be HTTPS")
	require.NotEmpty(t, parsedURL.Host, "URL must have a hostname")

	host := parsedURL.Hostname()
	port := parsedURL.Port()
	if port == "" {
		port = "443"
	}

	result := TLSResult{
		Host: host,
		Port: 443,
	}

	// Test default TLS connection
	tlsConfig := &tls.Config{
		ServerName:         host,
		InsecureSkipVerify: false,
		MinVersion:         minTLSVersion,
	}

	conn, err := tls.Dial("tcp", fmt.Sprintf("%s:%s", host, port), tlsConfig)
	if err != nil {
		result.Error = fmt.Sprintf("TLS handshake failed: %v", err)
		return result
	}
	defer conn.Close()

	state := conn.ConnectionState()
	result.NegotiatedVersion = tlsVersionToString(state.Version)
	if state.CipherSuite > 0 {
		result.Cipher = tls.CipherSuiteName(state.CipherSuite)
	}
	result.CertificateOK = true

	// Check if negotiated version meets minimum
	result.MeetsMinimum = state.Version >= minTLSVersion

	// Test legacy TLS rejection if requested
	if testLegacy {
		tls10Rejected := testTLSVersion(host, port, tls.VersionTLS10)
		tls11Rejected := testTLSVersion(host, port, tls.VersionTLS11)
		result.LegacyTLS10Rejected = &tls10Rejected
		result.LegacyTLS11Rejected = &tls11Rejected
	}

	return result
}

// testTLSVersion tests if a specific TLS version is rejected
func testTLSVersion(host, port string, version uint16) bool {
	tlsConfig := &tls.Config{
		ServerName:         host,
		InsecureSkipVerify: false,
		MinVersion:         version,
		MaxVersion:         version,
	}

	conn, err := tls.Dial("tcp", fmt.Sprintf("%s:%s", host, port), tlsConfig)
	if err != nil {
		// Connection failed, version is rejected (good)
		return true
	}
	defer conn.Close()

	// Connection succeeded, version is accepted (bad)
	return false
}

// tlsVersionToString converts TLS version constant to string
func tlsVersionToString(version uint16) string {
	switch version {
	case tls.VersionTLS10:
		return "TLSv1.0"
	case tls.VersionTLS11:
		return "TLSv1.1"
	case tls.VersionTLS12:
		return "TLSv1.2"
	case tls.VersionTLS13:
		return "TLSv1.3"
	default:
		return fmt.Sprintf("Unknown(0x%04x)", version)
	}
}

// WaitForEndpoint waits for a network endpoint to become available
func WaitForEndpoint(t *testing.T, host string, port string, timeout time.Duration) error {
	deadline := time.Now().Add(timeout)
	address := fmt.Sprintf("%s:%s", host, port)

	for time.Now().Before(deadline) {
		conn, err := net.DialTimeout("tcp", address, 5*time.Second)
		if err == nil {
			conn.Close()
			t.Logf("Endpoint %s is available", address)
			return nil
		}

		t.Logf("Waiting for endpoint %s (error: %v)", address, err)
		time.Sleep(10 * time.Second)
	}

	return fmt.Errorf("endpoint %s did not become available within %v", address, timeout)
}

// SkipIfShort skips test if running in short mode
func SkipIfShort(t *testing.T, reason string) {
	if testing.Short() {
		t.Skipf("Skipping in short mode: %s", reason)
	}
}

// CleanupOnError runs cleanup function only if test has failed
func CleanupOnError(t *testing.T, cleanup func()) {
	if t.Failed() {
		t.Log("Test failed, running cleanup")
		cleanup()
	}
}

// LogJSON logs a JSON-formatted message (useful for structured logging)
func LogJSON(t *testing.T, message string, data interface{}) {
	t.Logf("%s: %+v", message, data)
}

