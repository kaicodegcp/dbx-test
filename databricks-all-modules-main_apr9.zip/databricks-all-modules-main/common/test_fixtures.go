package common

import (
	"encoding/base64"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"os"
	"path/filepath"
	"strings"
	"testing"
	"time"

	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// ModuleTestConfig contains configuration for module testing
type ModuleTestConfig struct {
	ModuleName      string
	ModulePath      string
	RequiredVars    map[string]interface{}
	OptionalVars    map[string]interface{}
	ExpectedOutputs []string
	SkipDestroy     bool
	TestDescription string
}

// GetModulePath returns the absolute path to a module
func GetModulePath(moduleName string) string {
	currentDir, err := os.Getwd()
	if err != nil {
		return filepath.Join("..", "..", "databricks-all-modules", "modules", moduleName)
	}

	if strings.HasSuffix(currentDir, "/test") {
		return filepath.Join("..")
	}

	if strings.HasSuffix(currentDir, "databricks-modules") {
		return filepath.Join("..", "..", "databricks-all-modules", "modules", moduleName)
	}

	if strings.HasSuffix(currentDir, "tests") {
		return filepath.Join("..", "databricks-all-modules", "modules", moduleName)
	}

	return filepath.Join("databricks-all-modules", "modules", moduleName)
}

// GetTestTerraformOptions creates Terraform options for module testing
func GetTestTerraformOptions(t *testing.T, config ModuleTestConfig) *terraform.Options {
	vars := make(map[string]interface{})
	for k, v := range config.RequiredVars {
		if k == "content_base64" {
			if str, ok := v.(string); ok && !isBase64(str) {
				vars[k] = base64.StdEncoding.EncodeToString([]byte(str))
			} else {
				vars[k] = v
			}
		} else {
			vars[k] = v
		}
	}
	for k, v := range config.OptionalVars {
		if k == "content_base64" {
			if str, ok := v.(string); ok && !isBase64(str) {
				vars[k] = base64.StdEncoding.EncodeToString([]byte(str))
			} else {
				vars[k] = v
			}
		} else {
			vars[k] = v
		}
	}

	terraformOptions := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: config.ModulePath,
		Vars:         vars,
		NoColor:      true,
	})

	return terraformOptions
}

func isBase64(s string) bool {
	_, err := base64.StdEncoding.DecodeString(s)
	return err == nil && len(s) > 20
}

// ValidateModuleOutputs validates that expected outputs exist
func ValidateModuleOutputs(t *testing.T, opts *terraform.Options, expectedOutputs []string) map[string]interface{} {
	outputs := make(map[string]interface{})

	for _, outputName := range expectedOutputs {
		output := terraform.OutputRequired(t, opts, outputName)
		require.NotEmpty(t, output, fmt.Sprintf("Output %s should not be empty", outputName))
		outputs[outputName] = output
		t.Logf("Validated output %s: %v", outputName, output)
	}

	return outputs
}

// ValidateModuleInputs validates that inputs are properly processed
func ValidateModuleInputs(t *testing.T, opts *terraform.Options, expectedVars map[string]interface{}) {
	for varName, expectedValue := range expectedVars {
		actualValue, exists := opts.Vars[varName]
		require.True(t, exists, fmt.Sprintf("Variable %s should exist", varName))

		if varName == "content_base64" {
			if actualStr, ok := actualValue.(string); ok {
				if decoded, err := base64.StdEncoding.DecodeString(actualStr); err == nil {
					assert.Equal(t, expectedValue, string(decoded),
						fmt.Sprintf("Variable %s decoded value should match", varName))
					t.Logf("Validated input %s (base64-decoded): %v", varName, string(decoded))
					continue
				}
			}
		}

		if isComplexType(expectedValue) {
			expectedJSON, _ := json.Marshal(expectedValue)
			actualJSON, _ := json.Marshal(actualValue)
			assert.JSONEq(t, string(expectedJSON), string(actualJSON),
				fmt.Sprintf("Variable %s should match expected value", varName))
		} else {
			assert.Equal(t, expectedValue, actualValue,
				fmt.Sprintf("Variable %s should match expected value", varName))
		}

		t.Logf("Validated input %s: %v", varName, actualValue)
	}
}

func isComplexType(v interface{}) bool {
	switch v.(type) {
	case map[string]interface{}, []interface{}, map[string]string:
		return true
	default:
		return false
	}
}

// GetDatabricksEnvVars returns required Databricks environment variables
func GetDatabricksEnvVars(t *testing.T) map[string]string {
	return map[string]string{
		"DATABRICKS_HOST":          os.Getenv("DATABRICKS_HOST"),
		"DATABRICKS_ACCOUNT_ID":    os.Getenv("DATABRICKS_ACCOUNT_ID"),
		"DATABRICKS_CLIENT_ID":     os.Getenv("DATABRICKS_CLIENT_ID"),
		"DATABRICKS_CLIENT_SECRET": os.Getenv("DATABRICKS_CLIENT_SECRET"),
	}
}

// RequireDatabricksEnv ensures Databricks environment variables are set
func RequireDatabricksEnv(t *testing.T) {
	required := []string{
		"DATABRICKS_HOST",
		"DATABRICKS_CLIENT_ID",
		"DATABRICKS_CLIENT_SECRET",
	}

	for _, env := range required {
		value := os.Getenv(env)
		require.NotEmpty(t, value, fmt.Sprintf("Environment variable %s must be set", env))
	}
}

// GenerateUniqueTestID generates a unique identifier for test resources
func GenerateUniqueTestID(prefix string) string {
	return fmt.Sprintf("%s-test-%d", prefix, os.Getpid())
}

// GetOutboundIP returns the current machine's public IPv4 address.
func GetOutboundIP() string {
	client := &http.Client{Timeout: 5 * time.Second}
	urls := []string{"https://api.ipify.org", "https://ifconfig.me/ip"}
	for _, u := range urls {
		resp, err := client.Get(u)
		if err != nil {
			continue
		}
		body, err := io.ReadAll(resp.Body)
		resp.Body.Close()
		if err != nil || resp.StatusCode != http.StatusOK {
			continue
		}
		ip := strings.TrimSpace(string(body))
		if ip != "" && (strings.Contains(ip, ".") || strings.Contains(ip, ":")) {
			return ip
		}
	}
	return ""
}

// SkipIfShortMode skips test if running in short mode
func SkipIfShortMode(t *testing.T, reason string) {
	if testing.Short() {
		t.Skipf("Skipping in short mode: %s", reason)
	}
}

// TestModuleWithConfig runs a standard module test: init + plan with placeholder
// values. All tests run in plan-only mode by default.
func TestModuleWithConfig(t *testing.T, config ModuleTestConfig) {
	SkipIfShortMode(t, config.TestDescription)
	RequireDatabricksEnv(t)

	if config.ModulePath == "" {
		config.ModulePath = GetModulePath(config.ModuleName)
	}

	opts := GetTestTerraformOptions(t, config)

	terraform.Init(t, opts)
	planOutput := terraform.Plan(t, opts)
	require.NotEmpty(t, planOutput, "terraform plan should produce output")
	t.Logf("Successfully planned module: %s", config.ModuleName)
}

// TestDefaults centralizes environment-driven test configuration so individual
// test files don't hardcode account-specific values. Falls back to placeholder
// values when env vars are not set.
type TestDefaults struct {
	AccountID       string
	AWSRegion       string
	NodeTypeID      string
	SparkVersion    string
	CatalogName     string
	CrossAccountARN string
	S3BucketName    string
	VPCID           string
	SubnetIDs       []string
	SecurityGroupID string
	CredentialName  string
	InstanceProfile string
	VPCEndpointID   string
	ClusterID       string
	ExternalLocURL  string
	RoleARN         string
	QueryID         string
}

// GetTestDefaults reads environment variables and returns a TestDefaults,
// falling back to placeholder values for any unset variable so that
// terraform plan always has valid inputs.
func GetTestDefaults() TestDefaults {
	region := GetEnvOrDefault("AWS_REGION", "")
	if region == "" {
		region = GetEnvOrDefault("AWS_DEFAULT_REGION", "us-west-2")
	}

	subnets := []string{"subnet-00000000000000000", "subnet-00000000000000001"}
	raw := os.Getenv("TEST_SUBNET_IDS")
	if raw != "" {
		subnets = nil
		for _, s := range strings.Split(raw, ",") {
			subnets = append(subnets, strings.TrimSpace(s))
		}
	}

	return TestDefaults{
		AccountID:       GetEnvOrDefault("DATABRICKS_ACCOUNT_ID", "00000000-0000-0000-0000-000000000000"),
		AWSRegion:       region,
		NodeTypeID:      GetEnvOrDefault("TEST_NODE_TYPE", "i3.xlarge"),
		SparkVersion:    GetEnvOrDefault("TEST_SPARK_VERSION", "14.3.x-scala2.12"),
		CatalogName:     GetEnvOrDefault("TEST_CATALOG_NAME", "plan_only_catalog"),
		CrossAccountARN: GetEnvOrDefault("TEST_CROSS_ACCOUNT_ARN", "arn:aws:iam::000000000000:role/plan-only-role"),
		S3BucketName:    GetEnvOrDefault("TEST_S3_BUCKET", "plan-only-bucket"),
		VPCID:           GetEnvOrDefault("TEST_VPC_ID", "vpc-00000000000000000"),
		SubnetIDs:       subnets,
		SecurityGroupID: GetEnvOrDefault("TEST_SECURITY_GROUP_ID", "sg-00000000000000000"),
		CredentialName:  GetEnvOrDefault("TEST_STORAGE_CREDENTIAL_NAME", "plan_only_storage_credential"),
		InstanceProfile: GetEnvOrDefault("TEST_INSTANCE_PROFILE_ARN", "arn:aws:iam::000000000000:instance-profile/plan-only"),
		VPCEndpointID:   GetEnvOrDefault("TEST_VPC_ENDPOINT_ID", "vpce-00000000000000000"),
		ClusterID:       GetEnvOrDefault("TEST_CLUSTER_ID", "00000000-000000-xxxxx0"),
		ExternalLocURL:  GetEnvOrDefault("TEST_EXTERNAL_LOCATION_URL", "s3://plan-only-bucket/external/path/"),
		RoleARN:         GetEnvOrDefault("TEST_ROLE_ARN", "arn:aws:iam::000000000000:role/plan-only-role"),
		QueryID:         GetEnvOrDefault("TEST_SQL_QUERY_ID", "00000000-0000-0000-0000-000000000000"),
	}
}

// ParseTerraformVariables reads variables.tf and extracts variable definitions
func ParseTerraformVariables(modulePath string) ([]string, error) {
	varsFile := filepath.Join(modulePath, "variables.tf")
	content, err := os.ReadFile(varsFile)
	if err != nil {
		return nil, err
	}

	var variables []string
	lines := strings.Split(string(content), "\n")

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "variable \"") {
			varName := strings.TrimPrefix(line, "variable \"")
			varName = strings.TrimSuffix(varName, "\" {")
			varName = strings.TrimSpace(varName)
			variables = append(variables, varName)
		}
	}

	return variables, nil
}

// ParseTerraformOutputs reads outputs.tf and extracts output definitions
func ParseTerraformOutputs(modulePath string) ([]string, error) {
	outputsFile := filepath.Join(modulePath, "outputs.tf")
	content, err := os.ReadFile(outputsFile)
	if err != nil {
		return nil, err
	}

	var outputs []string
	lines := strings.Split(string(content), "\n")

	for _, line := range lines {
		line = strings.TrimSpace(line)
		if strings.HasPrefix(line, "output \"") {
			outputName := strings.TrimPrefix(line, "output \"")
			outputName = strings.TrimSuffix(outputName, "\" {")
			outputName = strings.TrimSpace(outputName)
			outputs = append(outputs, outputName)
		}
	}

	return outputs, nil
}
