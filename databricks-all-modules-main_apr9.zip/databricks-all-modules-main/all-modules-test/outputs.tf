# =============================================================================
# Identity Outputs
# =============================================================================

output "group_id" {
  description = "Test group ID"
  value       = module.test_group.id
}

output "user_id" {
  description = "Test user ID"
  value       = module.test_user.id
}

output "service_principal_id" {
  description = "Test service principal ID"
  value       = module.test_service_principal.id
}

output "group_member_id" {
  description = "Group membership ID"
  value       = module.test_group_member.id
}

# =============================================================================
# Secrets Outputs
# =============================================================================

output "secret_scope_name" {
  description = "Secret scope name"
  value       = module.test_secret_scope.name
}

output "secret_id" {
  description = "Secret ID"
  value       = module.test_secret.id
}

output "token_id" {
  description = "Token ID"
  value       = module.test_token.id
}

# =============================================================================
# Workspace Objects Outputs
# =============================================================================

output "directory_path" {
  description = "Directory path"
  value       = module.test_directory.path
}

output "notebook_path" {
  description = "Notebook path"
  value       = module.test_notebook.path
}

output "notebook_url" {
  description = "Notebook URL"
  value       = module.test_notebook.url
}

output "repo_path" {
  description = "Repo workspace path"
  value       = var.test_repo_url != "" ? module.test_repo[0].workspace_path : null
}

# =============================================================================
# ML Outputs
# =============================================================================

output "mlflow_experiment_id" {
  description = "MLflow experiment ID"
  value       = module.test_mlflow_experiment.experiment_id
}

output "mlflow_model_name" {
  description = "Registered model name"
  value       = module.test_mlflow_model.name
}

# =============================================================================
# Admin Outputs
# =============================================================================

output "global_init_script_id" {
  description = "Global init script ID"
  value       = var.create_test_global_init_script ? module.test_global_init_script[0].id : null
}

# =============================================================================
# Security Outputs
# =============================================================================

output "cluster_policy_id" {
  description = "Cluster policy ID"
  value       = var.create_test_cluster_policy ? module.test_cluster_policy[0].policy_id : null
}

output "ip_access_list_id" {
  description = "IP access list ID"
  value       = module.test_ip_access_list.id
}

# =============================================================================
# Compute Outputs
# =============================================================================

output "instance_pool_id" {
  description = "Instance pool ID"
  value       = var.create_test_instance_pool ? module.test_instance_pool[0].instance_pool_id : null
}

output "cluster_id" {
  description = "Cluster ID"
  value       = var.create_test_cluster ? module.test_cluster[0].cluster_id : null
}

output "cluster_url" {
  description = "Cluster URL"
  value       = var.create_test_cluster ? module.test_cluster[0].url : null
}

output "sql_warehouse_id" {
  description = "SQL warehouse ID"
  value       = module.test_sql_warehouse.id
}

output "sql_warehouse_jdbc_url" {
  description = "SQL warehouse JDBC URL"
  value       = module.test_sql_warehouse.jdbc_url
}

# =============================================================================
# SQL Analytics Outputs
# =============================================================================

output "sql_query_id" {
  description = "SQL query ID"
  value       = module.test_sql_query.id
}

output "sql_alert_id" {
  description = "SQL alert ID"
  value       = module.test_sql_alert.id
}


# =============================================================================
# Job Outputs
# =============================================================================

output "job_id" {
  description = "Job ID"
  value       = module.test_job.job_id
}

output "job_url" {
  description = "Job URL"
  value       = module.test_job.url
}

# =============================================================================
# Unity Catalog Outputs
# =============================================================================

output "catalog_id" {
  description = "Test catalog ID"
  value       = var.create_test_catalog ? module.catalog_creation[0].catalog_id : null
}

output "schema_name" {
  description = "Test schema full name"
  value       = (var.catalog_name != "" || var.create_test_catalog) ? module.test_schema[0].full_name : null
}

output "table_name" {
  description = "Test table full name"
  value       = var.create_test_table && (var.catalog_name != "" || var.create_test_catalog) ? module.test_table[0].full_name : null
}

output "storage_credential_id" {
  description = "Storage credential ID"
  value       = var.create_test_catalog ? module.catalog_creation[0].storage_credential_id : (var.storage_credential_role_arn != "" ? module.test_storage_credential[0].storage_credential_id : null)
}

output "external_location_id" {
  description = "External location ID"
  value       = var.create_test_catalog ? module.catalog_creation[0].external_location_id : (var.external_location_url != "" && var.storage_credential_role_arn != "" ? module.test_external_location[0].id : null)
}

output "catalog_file_events_sqs_queue_url" {
  description = "SQS queue URL for Unity Catalog file events when create_test_catalog and enable_catalog_file_events are true; null otherwise"
  value       = var.create_test_catalog ? module.catalog_creation[0].catalog_file_events_sqs_queue_url : null
}

output "catalog_file_events_sqs_queue_arn" {
  description = "SQS queue ARN for Unity Catalog file events when create_test_catalog and enable_catalog_file_events are true; null otherwise"
  value       = var.create_test_catalog ? module.catalog_creation[0].catalog_file_events_sqs_queue_arn : null
}

# =============================================================================
# Compute (additional) Outputs
# =============================================================================

output "library_id" {
  description = "Library ID"
  value       = var.create_test_cluster ? module.test_library[0].id : null
}

# =============================================================================
# Data Engineering Outputs
# =============================================================================

output "pipeline_id" {
  description = "Pipeline ID"
  value       = module.test_pipeline.id
}

output "pipeline_name" {
  description = "Pipeline name"
  value       = module.test_pipeline.name
}

# =============================================================================
# Model Serving Outputs (conditional)
# =============================================================================

output "model_serving_id" {
  description = "Model serving endpoint ID"
  value       = var.model_serving_entity_name != "" ? module.test_model_serving[0].id : null
}

# =============================================================================
# Mount Outputs (conditional/legacy)
# =============================================================================

output "mount_id" {
  description = "Mount ID"
  value       = var.mount_s3_bucket != "" ? module.test_mount[0].id : null
}

# =============================================================================
# Summary
# =============================================================================

output "test_summary" {
  description = "Summary of all resources created"
  value = {
    identity = {
      group             = module.test_group.display_name
      user              = module.test_user.user_name
      service_principal = module.test_service_principal.display_name
    }
    secrets = {
      scope = module.test_secret_scope.name
    }
    workspace_objects = {
      directory = module.test_directory.path
      notebook  = module.test_notebook.path
      repo      = var.test_repo_url != "" ? module.test_repo[0].workspace_path : "skipped"
    }
    ml = {
      experiment    = module.test_mlflow_experiment.name
      model         = module.test_mlflow_model.name
      model_serving = var.model_serving_entity_name != "" ? module.test_model_serving[0].name : "skipped"
    }
    compute = {
      cluster       = var.create_test_cluster ? module.test_cluster[0].cluster_name : "skipped"
      instance_pool = var.create_test_instance_pool ? module.test_instance_pool[0].instance_pool_name : "skipped"
      sql_warehouse = module.test_sql_warehouse.name
      library       = var.create_test_cluster ? module.test_library[0].id : "skipped"
    }
    data_engineering = {
      pipeline = module.test_pipeline.name
    }
    sql_analytics = {
      query = module.test_sql_query.name
      alert = module.test_sql_alert.name
    }
    job = module.test_job.name
    unity_catalog = {
      catalog             = var.create_test_catalog ? module.catalog_creation[0].catalog_name : "skipped"
      schema              = (var.catalog_name != "" || var.create_test_catalog) ? module.test_schema[0].full_name : "skipped"
      table               = var.create_test_table && (var.catalog_name != "" || var.create_test_catalog) ? module.test_table[0].full_name : "skipped"
      storage_credential  = var.create_test_catalog ? module.catalog_creation[0].storage_credential_id : (var.storage_credential_role_arn != "" ? module.test_storage_credential[0].name : "skipped")
      external_location   = var.create_test_catalog ? module.catalog_creation[0].external_location_name : (var.external_location_url != "" && var.storage_credential_role_arn != "" ? module.test_external_location[0].name : "skipped")
      file_events_enabled = var.create_test_catalog ? var.enable_catalog_file_events : false
      file_events_sqs_arn = var.create_test_catalog && var.enable_catalog_file_events ? module.catalog_creation[0].catalog_file_events_sqs_queue_arn : null
    }
    storage = {
      mount = var.mount_s3_bucket != "" ? module.test_mount[0].name : "skipped"
    }
    modules_exercised = local.modules_exercised
  }
}
