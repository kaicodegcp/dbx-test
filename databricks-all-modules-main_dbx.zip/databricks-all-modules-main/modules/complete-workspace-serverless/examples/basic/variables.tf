# =============================================================================
# Example variables for complete-workspace-serverless
# Set these in terraform.tfvars (copy from terraform.tfvars.example).
# The module requires aws_region, name_prefix, and existing_metastore_name
# (no defaults in module); this example provides defaults for convenience.
# =============================================================================

variable "databricks_account_id" {
  description = "Databricks account ID."
  type        = string
}

# Client ID and secret for Databricks provider come from env (e.g. source secrets file: DATABRICKS_CLIENT_ID, DATABRICKS_CLIENT_SECRET)

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID (used in S3 bucket policy principal)."
  type        = string
}

variable "aws_region" {
  description = "AWS region where the workspace and S3 bucket will be created."
  type        = string
  default     = "us-east-1"
}

variable "name_prefix" {
  description = "Prefix for resource names (e.g. MWS storage config, KMS alias)."
  type        = string
  default     = "serverless-example"
}

variable "workspace_name" {
  description = "Name for the new Databricks serverless workspace."
  type        = string
}

variable "workspace_root_bucket_name" {
  description = "S3 bucket name for the workspace root storage configuration. Must be globally unique."
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace."
  type        = string
  default     = "yankaiz-us-east-1"
}

variable "force_destroy_buckets" {
  description = "Allow Terraform to delete non-empty S3 buckets on destroy (use with caution)."
  type        = bool
  default     = false
}

variable "databricks_cross_account_role_arn" {
  description = "Optional Databricks cross-account IAM role ARN for EBS KMS (leave null if not using)."
  type        = string
  default     = null
}
