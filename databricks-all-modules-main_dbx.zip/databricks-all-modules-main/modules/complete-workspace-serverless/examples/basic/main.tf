# =============================================================================
# Complete Databricks Serverless Workspace - Example
# =============================================================================
# This example runs the complete-workspace-serverless module with variables
# supplied via terraform.tfvars (copy terraform.tfvars.example to terraform.tfvars
# and set your Databricks account ID, OAuth credentials, workspace name, and
# S3 bucket name).
#
# The module creates:
#   - S3 bucket for workspace root (with KMS, versioning, bucket policy)
#   - MWS storage configuration, customer-managed keys (storage + managed services)
#   - MWS serverless workspace
#   - Metastore assignment to an existing Unity Catalog metastore
# =============================================================================

terraform {
  required_version = ">= 1.5.0"
  required_providers {
    aws = {
      source  = "hashicorp/aws"
      version = ">= 5.0"
    }
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.80.0"
    }
  }
}

# -----------------------------------------------------------------------------
# Providers
# -----------------------------------------------------------------------------
provider "aws" {
  region = var.aws_region
}

provider "databricks" {
  alias       = "mws"
  host        = "https://accounts.cloud.databricks.com"
  account_id  = var.databricks_account_id
}

# -----------------------------------------------------------------------------
# Module
# -----------------------------------------------------------------------------
module "complete_workspace_serverless" {
  source = "../.."

  providers = {
    databricks.mws = databricks.mws
  }

  aws_region                   = var.aws_region
  databricks_account_id        = var.databricks_account_id
  databricks_aws_account_id    = var.databricks_aws_account_id
  name_prefix                  = var.name_prefix
  workspace_name               = var.workspace_name
  workspace_root_bucket_name   = var.workspace_root_bucket_name
  existing_metastore_name      = var.existing_metastore_name
  force_destroy_buckets        = var.force_destroy_buckets
  databricks_cross_account_role_arn = var.databricks_cross_account_role_arn
}

# -----------------------------------------------------------------------------
# Outputs
# -----------------------------------------------------------------------------
output "workspace_id" {
  description = "Created Databricks serverless workspace ID."
  value       = module.complete_workspace_serverless.workspace_id
}

output "workspace_url" {
  description = "Created Databricks workspace URL."
  value       = module.complete_workspace_serverless.workspace_url
}

output "storage_configuration_id" {
  description = "Databricks account storage configuration ID."
  value       = module.complete_workspace_serverless.storage_configuration_id
}

output "kms_key_arn" {
  description = "AWS KMS key ARN used for workspace encryption."
  value       = module.complete_workspace_serverless.kms_key_arn
}

output "metastore_id" {
  description = "Assigned Unity Catalog metastore ID."
  value       = module.complete_workspace_serverless.metastore_id
}
