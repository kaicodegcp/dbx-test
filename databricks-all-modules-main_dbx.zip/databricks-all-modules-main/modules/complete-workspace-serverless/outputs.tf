output "workspace_id" {
  description = "Created Databricks workspace ID."
  value       = databricks_mws_workspaces.this.workspace_id
}

output "workspace_url" {
  description = "Created Databricks workspace URL."
  value       = databricks_mws_workspaces.this.workspace_url
}

output "storage_configuration_id" {
  description = "Databricks account storage configuration ID."
  value       = databricks_mws_storage_configurations.this.storage_configuration_id
}

output "kms_key_arn" {
  description = "AWS KMS key ARN used for workspace encryption."
  value       = aws_kms_key.workspace.arn
}

output "metastore_id" {
  description = "Assigned Unity Catalog metastore ID."
  value       = data.databricks_metastore.existing.metastore_id
}
