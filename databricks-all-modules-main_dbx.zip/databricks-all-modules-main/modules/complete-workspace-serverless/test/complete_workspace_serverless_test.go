package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
)

func TestCompleteWorkspaceServerlessModule(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-ws")
	workspaceName := uniqueID
	bucketName := "terratest-serverless-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates complete workspace serverless module inputs (parameter-only)",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":             defaults.AWSRegion,
			"name_prefix":            "terratest-serverless",
			"existing_metastore_name": "yankaiz-us-east-1",
			"force_destroy_buckets":   false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateOptionalInputs", func(t *testing.T) {
		assert.Equal(t, defaults.AccountID, opts.Vars["databricks_account_id"])
		assert.Equal(t, defaults.AWSRegion, opts.Vars["aws_region"])
		assert.Equal(t, "terratest-serverless", opts.Vars["name_prefix"])
		assert.Equal(t, "yankaiz-us-east-1", opts.Vars["existing_metastore_name"])
		assert.Equal(t, false, opts.Vars["force_destroy_buckets"])
		t.Log("All optional inputs validated")
	})
}

func TestCompleteWorkspaceServerlessModuleMinimal(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-min")
	workspaceName := uniqueID
	bucketName := "terratest-min-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates minimal complete workspace serverless inputs",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":             defaults.AWSRegion,
			"name_prefix":            "terratest-serverless-min",
			"existing_metastore_name": "yankaiz-us-east-1",
			"force_destroy_buckets":   false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateMinimalConfig", func(t *testing.T) {
		assert.Equal(t, defaults.AWSRegion, opts.Vars["aws_region"])
		assert.Equal(t, "terratest-serverless-min", opts.Vars["name_prefix"])
		assert.Equal(t, "yankaiz-us-east-1", opts.Vars["existing_metastore_name"])
		assert.Equal(t, false, opts.Vars["force_destroy_buckets"])
		t.Log("Minimal configuration validated")
	})
}

func TestCompleteWorkspaceServerlessModuleWithCrossAccountRole(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("serverless-ebs")
	workspaceName := uniqueID
	bucketName := "terratest-ebs-" + uniqueID
	if len(bucketName) > 63 {
		bucketName = bucketName[:63]
	}

	config := common.ModuleTestConfig{
		ModuleName:      "complete-workspace-serverless",
		ModulePath:      "..",
		TestDescription: "Validates serverless workspace with cross-account EBS role",
		RequiredVars: map[string]interface{}{
			"databricks_account_id":      defaults.AccountID,
			"databricks_aws_account_id":  common.GetEnvOrDefault("DATABRICKS_AWS_ACCOUNT_ID", "414351767826"),
			"workspace_name":             workspaceName,
			"workspace_root_bucket_name": bucketName,
		},
		OptionalVars: map[string]interface{}{
			"aws_region":                       defaults.AWSRegion,
			"name_prefix":                      "terratest-serverless-ebs",
			"existing_metastore_name":           "yankaiz-us-east-1",
			"databricks_cross_account_role_arn": defaults.RoleARN,
			"force_destroy_buckets":             false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateCrossAccountRole", func(t *testing.T) {
		assert.NotNil(t, opts.Vars["databricks_cross_account_role_arn"])
		t.Log("Cross-account role configuration validated")
	})
}
