variable "aws_region" {
  description = "AWS region where the Databricks workspace will be created."
  type        = string
}

variable "databricks_account_id" {
  description = "Databricks account ID."
  type        = string
}

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID used in S3 bucket policy principal."
  type        = string
}

variable "databricks_cross_account_role_arn" {
  description = "Optional Databricks cross-account IAM role ARN for EBS KMS usage."
  type        = string
  default     = null
}

variable "name_prefix" {
  description = "Prefix for resource names."
  type        = string
}

variable "workspace_name" {
  description = "Name for the new Databricks workspace."
  type        = string
}

variable "workspace_root_bucket_name" {
  description = "S3 bucket name used for Databricks workspace root storage configuration."
  type        = string
}

variable "existing_metastore_name" {
  description = "Existing Unity Catalog metastore name to assign to the workspace."
  type        = string
}

variable "force_destroy_buckets" {
  description = "Whether Terraform can delete non-empty S3 buckets on destroy."
  type        = bool
  default     = false
}
