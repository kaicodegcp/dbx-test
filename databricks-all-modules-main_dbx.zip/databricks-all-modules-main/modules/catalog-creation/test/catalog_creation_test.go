package test

import (
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/stretchr/testify/assert"
)

func TestCatalogCreationModule(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-creation")

	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests Unity Catalog catalog creation module (S3, KMS, IAM, storage credential, catalog, optional schemas)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"aws_partition":          "aws",
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"schemas":                map[string]interface{}{},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
			"tags": map[string]string{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"storage_credential_id",
			"external_location_name",
			"s3_bucket_name",
			"iam_role_arn",
			"kms_key_arn",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogCreationModuleInputValidation(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-inputs")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "999888777666555")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		ModulePath:      "..",
		TestDescription: "Validates catalog creation module required and optional inputs",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"schemas": map[string]interface{}{
				"bronze": map[string]interface{}{"comment": "Bronze layer"},
				"silver": map[string]interface{}{"comment": "Silver layer"},
				"gold":   map[string]interface{}{"comment": "Gold layer"},
			},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)

	t.Run("ValidateRequiredInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})

	t.Run("ValidateOptionalInputs", func(t *testing.T) {
		assert.Equal(t, "ISOLATED", opts.Vars["catalog_isolation_mode"])
		assert.NotEmpty(t, opts.Vars["schemas"])
		assert.NotNil(t, opts.Vars["permissions"])
		t.Log("Catalog creation optional inputs validated")
	})
}

func TestCatalogCreationModuleWithSchemas(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-schemas")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests catalog creation with configurable schemas (bronze, silver, gold)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"schemas": map[string]interface{}{
				"bronze": map[string]interface{}{"comment": "Bronze layer - raw data"},
				"silver": map[string]interface{}{"comment": "Silver layer - cleansed"},
				"gold":   map[string]interface{}{"comment": "Gold layer - aggregated"},
			},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"schema_ids",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogCreationModuleWithCatalogPermissions(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-perms")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests catalog creation with catalog-level permissions (databricks_grant)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"permissions": map[string]interface{}{
				"groups": map[string]interface{}{
					"account users": []string{"USE_CATALOG", "USE_SCHEMA"},
				},
				"service_principals": map[string]interface{}{},
			},
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}

func TestCatalogCreationModuleWithSchemaPermissions(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("catalog-schema-perms")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")

	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		TestDescription: "Tests catalog creation with schema-level permissions (databricks_grant)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  uniqueID,
		},
		OptionalVars: map[string]interface{}{
			"catalog_owner":          "account users",
			"catalog_isolation_mode": "ISOLATED",
			"force_destroy":          true,
			"schemas": map[string]interface{}{
				"bronze": map[string]interface{}{
					"comment": "Bronze layer",
					"permissions": map[string]interface{}{
						"groups":             map[string]interface{}{"account users": []string{"USE_SCHEMA", "USE_TABLE"}},
						"service_principals": map[string]interface{}{},
					},
				},
			},
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
			"databricks_service_principal_app_ids": map[string]interface{}{},
		},
		ExpectedOutputs: []string{
			"catalog_id",
			"catalog_name",
			"schema_ids",
		},
		SkipDestroy: true,
	}

	common.TestModuleWithConfig(t, config)
}
