package test

import (
	"fmt"
	"testing"

	common "github.com/sandbox45/databricks-all-modules/common"
	"github.com/gruntwork-io/terratest/modules/terraform"
	"github.com/stretchr/testify/assert"
	"github.com/stretchr/testify/require"
)

// =============================================================================
// ALL-MODULES VALIDATION SMOKE TEST
// Validates that the full all-modules-test configuration is syntactically
// correct and all module references resolve. Uses terraform validate (no API
// calls) so it completes in seconds regardless of module count.
// =============================================================================

func TestWorkspaceIntegration(t *testing.T) {
	opts := terraform.WithDefaultRetryableErrors(t, &terraform.Options{
		TerraformDir: "..",
		NoColor:      true,
	})

	terraform.Init(t, opts)
	output := terraform.Validate(t, opts)
	require.NotEmpty(t, output, "terraform validate should produce output")
	t.Logf("All-modules configuration validated successfully")
}

// =============================================================================
// INDIVIDUAL MODULE SMOKE TESTS
// Each tests a single module in isolation using the standalone module path.
// =============================================================================

func TestGroupModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("grp")
	config := common.ModuleTestConfig{
		ModuleName:      "group",
		ModulePath:      "../../modules/group",
		TestDescription: "Smoke test: group module",
		RequiredVars: map[string]interface{}{
			"display_name": fmt.Sprintf("%s-smoke-group", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"workspace_access": true,
			"force":            true,
		},
		ExpectedOutputs: []string{"id", "display_name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestUserModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("usr")
	config := common.ModuleTestConfig{
		ModuleName:      "user",
		ModulePath:      "../../modules/user",
		TestDescription: "Smoke test: user module",
		RequiredVars: map[string]interface{}{
			"user_name": fmt.Sprintf("%s-smoke@example.com", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"force": true,
		},
		ExpectedOutputs: []string{"id", "user_name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestSecretScopeModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("scope")
	config := common.ModuleTestConfig{
		ModuleName:      "secret-scope",
		ModulePath:      "../../modules/secret-scope",
		TestDescription: "Smoke test: secret-scope module",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("%s-smoke-scope", uniqueID),
		},
		ExpectedOutputs: []string{"id", "name", "backend_type"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestDirectoryModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("dir")
	config := common.ModuleTestConfig{
		ModuleName:      "directory",
		ModulePath:      "../../modules/directory",
		TestDescription: "Smoke test: directory module",
		RequiredVars: map[string]interface{}{
			"path": fmt.Sprintf("/Shared/%s-smoke-dir", uniqueID),
		},
		ExpectedOutputs: []string{"id", "path", "object_id"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestNotebookModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("nb")
	config := common.ModuleTestConfig{
		ModuleName:      "notebook",
		ModulePath:      "../../modules/notebook",
		TestDescription: "Smoke test: notebook module",
		RequiredVars: map[string]interface{}{
			"path":     fmt.Sprintf("/Shared/%s-smoke-notebook", uniqueID),
			"language": "PYTHON",
		},
		OptionalVars: map[string]interface{}{
			"content_base64": "IyBTbW9rZSB0ZXN0IG5vdGVib29rCnByaW50KCdoZWxsbycpCg==",
		},
		ExpectedOutputs: []string{"id", "path", "url"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestMLflowExperimentModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("exp")
	config := common.ModuleTestConfig{
		ModuleName:      "mlflow-experiment",
		ModulePath:      "../../modules/mlflow-experiment",
		TestDescription: "Smoke test: mlflow-experiment module",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("/Shared/%s-smoke-experiment", uniqueID),
		},
		ExpectedOutputs: []string{"id", "name", "experiment_id"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestMLflowModelModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("model")
	config := common.ModuleTestConfig{
		ModuleName:      "mlflow-model",
		ModulePath:      "../../modules/mlflow-model",
		TestDescription: "Smoke test: mlflow-model module",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("%s-smoke-model", uniqueID),
		},
		ExpectedOutputs: []string{"id", "name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestGlobalInitScriptModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("init")
	config := common.ModuleTestConfig{
		ModuleName:      "global-init-script",
		ModulePath:      "../../modules/global-init-script",
		TestDescription: "Smoke test: global-init-script module",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("%s-smoke-init", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"enabled":        false,
			"content_base64": "IyEvYmluL2Jhc2gKZWNobyAnc21va2UgdGVzdCcK",
		},
		ExpectedOutputs: []string{"id", "name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestClusterPolicyModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("pol")
	config := common.ModuleTestConfig{
		ModuleName:      "cluster-policy",
		ModulePath:      "../../modules/cluster-policy",
		TestDescription: "Smoke test: cluster-policy module",
		RequiredVars: map[string]interface{}{
			"name":       fmt.Sprintf("%s-smoke-policy", uniqueID),
			"definition": fmt.Sprintf(`{"spark_version":{"type":"fixed","value":"%s"}}`, defaults.SparkVersion),
		},
		ExpectedOutputs: []string{"id", "policy_id", "name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestInstancePoolModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("pool")
	config := common.ModuleTestConfig{
		ModuleName:      "instance-pool",
		ModulePath:      "../../modules/instance-pool",
		TestDescription: "Smoke test: instance-pool module",
		RequiredVars: map[string]interface{}{
			"instance_pool_name": fmt.Sprintf("%s-smoke-pool", uniqueID),
			"node_type_id":       defaults.NodeTypeID,
		},
		OptionalVars: map[string]interface{}{
			"min_idle_instances": 0,
			"max_capacity":      1,
		},
		ExpectedOutputs: []string{"id", "instance_pool_id", "instance_pool_name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestIPAccessListModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("ip")
	config := common.ModuleTestConfig{
		ModuleName:      "ip-access-list",
		ModulePath:      "../../modules/ip-access-list",
		TestDescription: "Smoke test: ip-access-list module",
		RequiredVars: map[string]interface{}{
			"label":        fmt.Sprintf("%s-smoke-ips", uniqueID),
			"list_type":    "ALLOW",
			"ip_addresses": []string{"10.0.0.0/8"},
		},
		ExpectedOutputs: []string{"id", "label"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestTokenModuleSmoke(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "token",
		ModulePath:      "../../modules/token",
		TestDescription: "Smoke test: token module",
		RequiredVars:    map[string]interface{}{},
		OptionalVars: map[string]interface{}{
			"comment":          "smoke-test-token",
			"lifetime_seconds": 3600,
		},
		ExpectedOutputs: []string{"id"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestSQLWarehouseModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("wh")
	config := common.ModuleTestConfig{
		ModuleName:      "sql-warehouse",
		ModulePath:      "../../modules/sql-warehouse",
		TestDescription: "Smoke test: sql-warehouse module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":         fmt.Sprintf("%s-smoke-wh", uniqueID),
			"cluster_size": "2X-Small",
		},
		OptionalVars: map[string]interface{}{
			"auto_stop_mins":            10,
			"warehouse_type":            "PRO",
			"max_num_clusters":          1,
			"enable_serverless_compute": false,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestSQLDashboardModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("dash")
	warehouseID := common.GetEnvOrDefault("TEST_SQL_WAREHOUSE_ID", "test-warehouse-id")

	config := common.ModuleTestConfig{
		ModuleName:      "sql-dashboard",
		ModulePath:      "../../modules/sql-dashboard",
		TestDescription: "Smoke test: sql-dashboard module (Lakeview dashboard)",
		RequiredVars: map[string]interface{}{
			"name":         fmt.Sprintf("%s-smoke-dashboard", uniqueID),
			"warehouse_id": warehouseID,
		},
		OptionalVars: map[string]interface{}{
			"parent": "/Shared",
		},
		ExpectedOutputs: []string{"id", "name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestJobModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("job")
	config := common.ModuleTestConfig{
		ModuleName:      "job",
		ModulePath:      "../../modules/job",
		TestDescription: "Smoke test: job module",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("%s-smoke-job", uniqueID),
		},
		ExpectedOutputs: []string{"id", "job_id", "name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestSchemaModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("sch")
	config := common.ModuleTestConfig{
		ModuleName:      "schema",
		ModulePath:      "../../modules/schema",
		TestDescription: "Smoke test: schema module",
		RequiredVars: map[string]interface{}{
			"catalog_name": catalogName,
			"name":         fmt.Sprintf("%s_smoke_schema", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"force_destroy": true,
		},
		ExpectedOutputs: []string{"id", "name", "full_name"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

func TestServicePrincipalModuleSmoke(t *testing.T) {
	spAppID := common.GetEnvOrDefault("TEST_SP_APPLICATION_ID", "00000000-0000-0000-0000-000000000000")

	config := common.ModuleTestConfig{
		ModuleName:      "service-principal",
		ModulePath:      "../../modules/service-principal",
		TestDescription: "Smoke test: service-principal module",
		RequiredVars: map[string]interface{}{
			"application_id": spAppID,
		},
		OptionalVars: map[string]interface{}{
			"display_name": "smoke-test-sp",
			"force":        true,
		},
		ExpectedOutputs: []string{"id", "application_id"},
		SkipDestroy:     false,
	}
	common.TestModuleWithConfig(t, config)
}

// =============================================================================
// SMOKE TESTS FOR NEWLY ADDED MODULES
// =============================================================================

func TestSQLAlertModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("alert")
	config := common.ModuleTestConfig{
		ModuleName:      "sql-alert",
		ModulePath:      "../../modules/sql-alert",
		TestDescription: "Smoke test: sql-alert module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":           fmt.Sprintf("%s-smoke-alert", uniqueID),
			"query_id":       "placeholder-query-id",
			"options_column": "test_column",
			"options_op":     "==",
			"options_value":  "1",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestCatalogCreationModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("cat")
	workspaceID := common.GetEnvOrDefault("DATABRICKS_WORKSPACE_ID", "123456789012345")
	config := common.ModuleTestConfig{
		ModuleName:      "catalog-creation",
		ModulePath:      "../../modules/catalog-creation",
		TestDescription: "Smoke test: catalog-creation module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"workspace_id": workspaceID,
			"name_prefix":  fmt.Sprintf("%s_smoke", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"unity_catalog_iam_arn":  common.GetEnvOrDefault("UNITY_CATALOG_IAM_ARN", "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"),
			"catalog_isolation_mode": "OPEN",
			"force_destroy":          true,
			"permissions": map[string]interface{}{
				"groups":             map[string]interface{}{},
				"service_principals": map[string]interface{}{},
			},
			"schemas": map[string]interface{}{},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestTableModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()
	catalogName := defaults.CatalogName

	uniqueID := common.GenerateUniqueTestID("tbl")
	config := common.ModuleTestConfig{
		ModuleName:      "table",
		ModulePath:      "../../modules/table",
		TestDescription: "Smoke test: table module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":         fmt.Sprintf("%s_smoke_table", uniqueID),
			"catalog_name": catalogName,
			"schema_name":  "default",
		},
		OptionalVars: map[string]interface{}{
			"table_type": "MANAGED",
			"comment":    "Smoke test table",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestLibraryModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	config := common.ModuleTestConfig{
		ModuleName:      "library",
		ModulePath:      "../../modules/library",
		TestDescription: "Smoke test: library module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"cluster_id": defaults.ClusterID,
		},
		OptionalVars: map[string]interface{}{
			"pypi": map[string]interface{}{"package": "scikit-learn"},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestPipelineModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("pipe")
	config := common.ModuleTestConfig{
		ModuleName:      "pipeline",
		ModulePath:      "../../modules/pipeline",
		TestDescription: "Smoke test: pipeline module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("%s-smoke-pipeline", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"development": true,
			"edition":     "ADVANCED",
			"photon":      true,
			"channel":     "CURRENT",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestModelServingModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("srv")
	config := common.ModuleTestConfig{
		ModuleName:      "model-serving",
		ModulePath:      "../../modules/model-serving",
		TestDescription: "Smoke test: model-serving module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":           fmt.Sprintf("%s-smoke-serving", uniqueID),
			"entity_name":    "placeholder-model",
			"entity_version": "1",
		},
		OptionalVars: map[string]interface{}{
			"workload_size":         "Small",
			"workload_type":         "CPU",
			"scale_to_zero_enabled": true,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestMountModuleSmoke(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "mount",
		ModulePath:      "../../modules/mount",
		TestDescription: "Smoke test: mount module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name": "smoke-test-mount",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestStorageCredentialModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("stcred")
	config := common.ModuleTestConfig{
		ModuleName:      "storage-credential",
		ModulePath:      "../../modules/storage-credential",
		TestDescription: "Smoke test: storage-credential module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name": fmt.Sprintf("%s-smoke-cred", uniqueID),
		},
		OptionalVars: map[string]interface{}{
			"aws_iam_role": map[string]interface{}{"role_arn": defaults.RoleARN},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestExternalLocationModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("extloc")
	config := common.ModuleTestConfig{
		ModuleName:      "external-location",
		ModulePath:      "../../modules/external-location",
		TestDescription: "Smoke test: external-location module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":            fmt.Sprintf("%s-smoke-ext", uniqueID),
			"url":             defaults.ExternalLocURL,
			"credential_name": "placeholder-cred",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestPermissionsModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	config := common.ModuleTestConfig{
		ModuleName:      "permissions",
		ModulePath:      "../../modules/permissions",
		TestDescription: "Smoke test: permissions module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"cluster_id": defaults.ClusterID,
			"access_control_list": []map[string]interface{}{
				{"group_name": "admins", "permission_level": "CAN_RESTART"},
			},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestWorkspaceConfModuleSmoke(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "workspace-conf",
		ModulePath:      "../../modules/workspace-conf",
		TestDescription: "Smoke test: workspace-conf module (parameter validation only)",
		RequiredVars:    map[string]interface{}{},
		OptionalVars: map[string]interface{}{
			"enable_verbose_audit_logs": true,
			"enforce_user_isolation":    true,
			"disable_legacy_access":     true,
			"disable_legacy_dbfs":       true,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		assert.Equal(t, true, opts.Vars["enable_verbose_audit_logs"])
		assert.Equal(t, true, opts.Vars["enforce_user_isolation"])
		t.Log("Workspace conf parameters validated")
	})
}

func TestMetastoreModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("meta")
	config := common.ModuleTestConfig{
		ModuleName:      "metastore",
		ModulePath:      "../../modules/metastore",
		TestDescription: "Smoke test: metastore module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":         fmt.Sprintf("%s-smoke-metastore", uniqueID),
			"storage_root": fmt.Sprintf("s3://%s/metastore", defaults.S3BucketName),
			"region":       defaults.AWSRegion,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestMWSCredentialsModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mwscred")
	config := common.ModuleTestConfig{
		ModuleName:      "mws-credentials",
		ModulePath:      "../../modules/mws-credentials",
		TestDescription: "Smoke test: mws-credentials module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"account_id":       defaults.AccountID,
			"credentials_name": fmt.Sprintf("%s-smoke-creds", uniqueID),
			"role_arn":         defaults.CrossAccountARN,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestMWSNetworksModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mwsnet")
	config := common.ModuleTestConfig{
		ModuleName:      "mws-networks",
		ModulePath:      "../../modules/mws-networks",
		TestDescription: "Smoke test: mws-networks module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"account_id":          defaults.AccountID,
			"network_name":       fmt.Sprintf("%s-smoke-net", uniqueID),
			"vpc_id":             defaults.VPCID,
			"subnet_ids":         []string{"subnet-placeholder"},
			"security_group_ids": []string{"sg-placeholder"},
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestMWSStorageConfigModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mwssc")
	config := common.ModuleTestConfig{
		ModuleName:      "mws-storage-configuration",
		ModulePath:      "../../modules/mws-storage-configuration",
		TestDescription: "Smoke test: mws-storage-configuration module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"account_id":                 defaults.AccountID,
			"storage_configuration_name": fmt.Sprintf("%s-smoke-storage", uniqueID),
			"bucket_name":                defaults.S3BucketName,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestMWSVPCEndpointModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()

	uniqueID := common.GenerateUniqueTestID("mwsvpce")
	config := common.ModuleTestConfig{
		ModuleName:      "mws-vpc-endpoint",
		ModulePath:      "../../modules/mws-vpc-endpoint",
		TestDescription: "Smoke test: mws-vpc-endpoint module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"account_id":              defaults.AccountID,
			"vpc_endpoint_name":       fmt.Sprintf("%s-smoke-vpce", uniqueID),
			"aws_vpc_endpoint_id":     defaults.VPCEndpointID,
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestSecretModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("sec")
	config := common.ModuleTestConfig{
		ModuleName:      "secret",
		ModulePath:      "../../modules/secret",
		TestDescription: "Smoke test: secret module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"scope":        "placeholder-scope",
			"key":          fmt.Sprintf("%s-smoke-key", uniqueID),
			"string_value": "placeholder-value",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestGroupMemberModuleSmoke(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "group-member",
		ModulePath:      "../../modules/group-member",
		TestDescription: "Smoke test: group-member module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"group_id":  "placeholder-group-id",
			"member_id": "placeholder-member-id",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestRepoModuleSmoke(t *testing.T) {
	config := common.ModuleTestConfig{
		ModuleName:      "repo",
		ModulePath:      "../../modules/repo",
		TestDescription: "Smoke test: repo module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"url": "https://github.com/example/repo.git",
		},
		OptionalVars: map[string]interface{}{
			"git_provider": "gitHub",
			"branch":       "main",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestClusterModuleSmoke(t *testing.T) {
	defaults := common.GetTestDefaults()
	uniqueID := common.GenerateUniqueTestID("cls")
	config := common.ModuleTestConfig{
		ModuleName:      "cluster",
		ModulePath:      "../../modules/cluster",
		TestDescription: "Smoke test: cluster module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"cluster_name":  fmt.Sprintf("%s-smoke-cluster", uniqueID),
			"spark_version": defaults.SparkVersion,
			"node_type_id":  defaults.NodeTypeID,
		},
		OptionalVars: map[string]interface{}{
			"num_workers":             0,
			"autotermination_minutes": 10,
			"data_security_mode":      "USER_ISOLATION",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}

func TestSQLQueryModuleSmoke(t *testing.T) {
	uniqueID := common.GenerateUniqueTestID("qry")
	config := common.ModuleTestConfig{
		ModuleName:      "sql-query",
		ModulePath:      "../../modules/sql-query",
		TestDescription: "Smoke test: sql-query module (parameter validation only)",
		RequiredVars: map[string]interface{}{
			"name":           fmt.Sprintf("%s-smoke-query", uniqueID),
			"data_source_id": "placeholder-ds-id",
			"query":          "SELECT 1",
		},
	}

	opts := common.GetTestTerraformOptions(t, config)
	t.Run("ValidateInputs", func(t *testing.T) {
		common.ValidateModuleInputs(t, opts, config.RequiredVars)
	})
}
