# =============================================================================
# Workspace Integration Test - Exercises ALL Workspace-Level Modules
# =============================================================================
# Deploys into an EXISTING workspace created by deployment-v2.
# Exercises up to 32 modules (fewer if classic compute create_* flags are false; sql-dashboard removed):
#   Identity:        group, user, service-principal, group-member
#   Secrets:         secret-scope, secret, token
#   Workspace:       directory, notebook, repo
#   ML:              mlflow-experiment, mlflow-model, model-serving (conditional)
#   Admin:           global-init-script (optional), workspace-conf
#   Security:        cluster-policy (optional), ip-access-list
#   Compute:         instance-pool (optional), cluster (optional), sql-warehouse, library (optional)
#   Data Eng:        pipeline
#   SQL Analytics:   sql-query, sql-alert
#   Jobs:            job (serverless compute via environments)
#   Unity Catalog:   catalog-creation (conditional), schema, table
#   Storage:         storage-credential, external-location, mount (conditional)
#   Governance:      permissions
# =============================================================================

terraform {
  required_version = ">= 1.0"

  required_providers {
    databricks = {
      source  = "databricks/databricks"
      version = ">= 1.0.0"
    }
    aws = {
      source  = "hashicorp/aws"
      version = ">= 4.0"
    }
    random = {
      source  = "hashicorp/random"
      version = ">= 3.0"
    }
    time = {
      source  = "hashicorp/time"
      version = ">= 0.9"
    }
  }
}

provider "databricks" {
  host = var.workspace_url
  http_timeout_seconds = 300
}

provider "aws" {
  region = var.aws_region
}

locals {
  prefix                 = var.test_prefix
  effective_catalog_name = var.create_test_catalog ? module.catalog_creation[0].catalog_name : var.catalog_name
  # Approximate module count when optional classic compute is disabled
  modules_exercised = 32 - (
    !var.create_test_global_init_script ? 1 : 0) - (
    !var.create_test_cluster_policy ? 1 : 0) - (
    !var.create_test_instance_pool ? 1 : 0) - (
    !var.create_test_cluster ? 3 : 0
  )
}

# =============================================================================
# IDENTITY: Group, User, Service Principal, Group Membership
# =============================================================================

module "test_group" {
  source = "../modules/group"

  display_name               = "${local.prefix}-data-engineers"
  allow_cluster_create       = true
  allow_instance_pool_create = true
  databricks_sql_access      = true
  workspace_access           = true
  force                      = true
}

module "test_user" {
  source = "../modules/user"

  user_name              = "${local.prefix}-testuser@example.com"
  display_name           = "${local.prefix} Test User"
  allow_cluster_create   = false
  databricks_sql_access  = true
  workspace_access       = true
  force                  = true
}

module "test_service_principal" {
  source = "../modules/service-principal"

  display_name           = "${local.prefix}-test-sp"
  allow_cluster_create   = false
  databricks_sql_access  = true
  workspace_access       = true
  force                  = true
}

module "test_group_member" {
  source = "../modules/group-member"

  group_id  = module.test_group.id
  member_id = module.test_user.id
}

# =============================================================================
# SECRETS: Scope + Secret + Token
# =============================================================================

module "test_secret_scope" {
  source = "../modules/secret-scope"

  name = "${local.prefix}-test-scope"
}

module "test_secret" {
  source = "../modules/secret"

  scope        = module.test_secret_scope.name
  key          = "${local.prefix}-api-key"
  string_value = var.test_secret_value
}

module "test_token" {
  source = "../modules/token"

  comment          = "${local.prefix} integration test token"
  lifetime_seconds = 3600
}

# =============================================================================
# WORKSPACE OBJECTS: Directory, Notebook, Repo
# =============================================================================

module "test_directory" {
  source = "../modules/directory"

  path = "/Shared/${local.prefix}-test-directory"
}

module "test_notebook" {
  source = "../modules/notebook"

  path           = "/Shared/${local.prefix}-test-directory/${local.prefix}-test-notebook"
  language       = "PYTHON"
  content_base64 = base64encode("# Integration test notebook\nprint('Hello from ${local.prefix}')\n")

  depends_on = [module.test_directory]
}

module "test_repo" {
  count  = var.test_repo_url != "" ? 1 : 0
  source = "../modules/repo"

  url          = var.test_repo_url
  git_provider = var.test_repo_provider
  branch       = var.test_repo_branch
}

# =============================================================================
# ML: MLflow Experiment + MLflow Model
# =============================================================================

module "test_mlflow_experiment" {
  source = "../modules/mlflow-experiment"

  name        = "/Shared/${local.prefix}-test-experiment"
  description = "Integration test MLflow experiment"
}

module "test_mlflow_model" {
  source = "../modules/mlflow-model"

  name        = "${local.prefix}-test-model"
  description = "Integration test registered model"
  tags = [
    { key = "environment", value = "test" },
    { key = "managed_by", value = "terraform" }
  ]
}

# =============================================================================
# ADMIN: Global Init Script, Workspace Conf
# =============================================================================

module "test_global_init_script" {
  count  = var.create_test_global_init_script ? 1 : 0
  source = "../modules/global-init-script"

  name           = "${local.prefix}-test-init-script"
  enabled        = false
  content_base64 = base64encode("#!/bin/bash\necho 'Integration test init script'\n")
  position       = 100
}

module "test_workspace_conf" {
  source = "../modules/workspace-conf"

  enable_verbose_audit_logs         = true
  enforce_user_isolation            = true
  store_results_in_customer_account = true
  enable_results_downloading        = false
  enable_notebook_table_clipboard   = false
  enable_export_notebook            = false
  enable_dbfs_file_browser          = false
  enable_upload_data_uis            = false
  disable_legacy_access             = true
  disable_legacy_dbfs               = true
}

# =============================================================================
# SECURITY: Cluster Policy, IP Access List
# =============================================================================

module "test_cluster_policy" {
  count  = var.create_test_cluster_policy ? 1 : 0
  source = "../modules/cluster-policy"

  name        = "${local.prefix}-test-policy"
  description = "Integration test cluster policy"

  definition = jsonencode({
    "spark_version" = {
      type    = "regex"
      pattern = "^[0-9]+\\.[0-9]+\\.x-.*"
    }
    "data_security_mode" = {
      type  = "fixed"
      value = "USER_ISOLATION"
    }
    "autotermination_minutes" = {
      type     = "range"
      minValue = 10
      maxValue = 120
    }
  })

  max_clusters_per_user = 2
}

module "test_ip_access_list" {
  source = "../modules/ip-access-list"

  label     = "${local.prefix}-test-allow-list"
  list_type = "ALLOW"
  ip_addresses = [
    "0.0.0.0/0",
  ]
  enabled = true
}

# =============================================================================
# COMPUTE: Instance Pool, Cluster, SQL Warehouse
# =============================================================================

module "test_instance_pool" {
  count  = var.create_test_instance_pool ? 1 : 0
  source = "../modules/instance-pool"

  instance_pool_name                    = "${local.prefix}-test-pool"
  node_type_id                          = var.node_type_id
  min_idle_instances                    = 0
  max_capacity                          = 2
  idle_instance_autotermination_minutes = 10

  custom_tags = {
    Environment = "integration-test"
  }
}

module "test_cluster" {
  count  = var.create_test_cluster ? 1 : 0
  source = "../modules/cluster"

  cluster_name            = "${local.prefix}-test-cluster"
  spark_version           = var.spark_version
  node_type_id            = var.node_type_id
  num_workers             = 0
  autotermination_minutes = 10
  data_security_mode      = "USER_ISOLATION"
  policy_id               = var.create_test_cluster_policy ? module.test_cluster_policy[0].policy_id : null
  enable_enhanced_security = false

  spark_conf = {
    "spark.databricks.cluster.profile" = "singleNode"
    "spark.master"                     = "local[*]"
  }

  custom_tags = {
    "ResourceClass" = "SingleNode"
    "Environment"   = "integration-test"
  }
}

module "test_sql_warehouse" {
  source = "../modules/sql-warehouse"

  name                       = "${local.prefix}-test-warehouse"
  cluster_size               = "2X-Small"
  max_num_clusters           = 1
  min_num_clusters           = 1
  auto_stop_mins             = 10
  enable_photon              = true
  enable_serverless_compute  = true
  warehouse_type             = "PRO"
}

# =============================================================================
# SQL ANALYTICS: Dashboard, Query, Alert
# =============================================================================

module "test_sql_query" {
  source = "../modules/sql-query"

  name           = "${local.prefix}-test-query"
  data_source_id = module.test_sql_warehouse.id
  query          = "SELECT 1 AS test_column, current_timestamp() AS test_timestamp"
  description    = "Integration test query"
}

module "test_sql_alert" {
  source = "../modules/sql-alert"

  name           = "${local.prefix}-test-alert"
  query_id       = module.test_sql_query.id
  parent         = null
  options_column = "test_column"
  options_op     = "=="
  options_value  = "1"
}

# =============================================================================
# JOBS
# =============================================================================

module "test_job" {
  source = "../modules/job"

  name        = "${local.prefix}-test-job"
  description = "Integration test job (serverless compute)"

  environments = [
    {
      environment_key = "Default"
      client          = "1"
    }
  ]

  tasks = [
    {
      task_key        = "test_task"
      environment_key = "Default"
      notebook_task = {
        notebook_path = module.test_notebook.path
      }
    }
  ]

  tags = {
    environment = "integration-test"
    managed_by  = "terraform"
  }
}

# =============================================================================
# UNITY CATALOG: catalog-creation module (S3, KMS, IAM, storage credential,
# external location, catalog, default namespace, grants) when create_test_catalog
# =============================================================================

module "catalog_creation" {
  count  = var.create_test_catalog ? 1 : 0
  source = "../modules/catalog-creation"

  workspace_id           = var.workspace_id
  name_prefix            = local.prefix
  unity_catalog_iam_arn  = var.unity_catalog_iam_arn
  catalog_isolation_mode  = "OPEN"
  force_destroy          = true
  catalog_owner          = "account users"

  catalog_properties = {
    environment = "integration-test"
    managed_by  = "terraform"
  }

  permissions = {
    groups = {
      "account users" = ["ALL_PRIVILEGES"]
    }
    service_principals = {}
  }

  schemas = {}

  tags = {
    Purpose = "all-modules-test"
  }
}

# Storage credential + external location for standalone UC tests (not used when catalog_creation runs)
module "test_storage_credential" {
  count  = var.create_test_catalog ? 0 : (var.storage_credential_role_arn != "" ? 1 : 0)
  source = "../modules/storage-credential"

  name           = "${local.prefix}-test-storage-cred"
  comment        = "Integration test storage credential"
  aws_iam_role   = { role_arn = var.storage_credential_role_arn }
  force_destroy  = true
  isolation_mode = "ISOLATION_MODE_ISOLATED"
}

module "test_external_location" {
  count  = var.create_test_catalog ? 0 : (var.external_location_url != "" && var.storage_credential_role_arn != "" ? 1 : 0)
  source = "../modules/external-location"

  name            = "${local.prefix}-test-ext-location"
  url             = var.external_location_url
  credential_name = module.test_storage_credential[0].name
  comment         = "Integration test external location"
  force_destroy   = true
  skip_validation = true
}

# =============================================================================
# UNITY CATALOG: Schema, Table (catalog from catalog_creation or var.catalog_name)
# =============================================================================

resource "databricks_grants" "catalog_grants" {
  count   = (!var.create_test_catalog && var.catalog_name != "") ? 1 : 0
  catalog = local.effective_catalog_name

  grant {
    principal  = "account users"
    privileges = ["ALL_PRIVILEGES"]
  }
}

module "test_schema" {
  count  = (var.catalog_name != "" || var.create_test_catalog) ? 1 : 0
  source = "../modules/schema"

  catalog_name  = local.effective_catalog_name
  name          = "${local.prefix}_test_schema"
  comment       = "Integration test schema"
  force_destroy = true

  # Static list only (no ternary/concat). Empty module/resource when count=0 is valid for depends_on.
  depends_on = [module.catalog_creation, databricks_grants.catalog_grants]

  properties = {
    environment = "integration-test"
    managed_by  = "terraform"
  }
}

resource "databricks_grants" "schema_grants" {
  count  = (var.catalog_name != "" || var.create_test_catalog) ? 1 : 0
  schema = "${local.effective_catalog_name}.${module.test_schema[0].name}"

  grant {
    principal  = "account users"
    privileges = ["ALL_PRIVILEGES"]
  }

  depends_on = [module.test_schema]
}

module "test_table" {
  count  = var.create_test_table && (var.catalog_name != "" || var.create_test_catalog) ? 1 : 0
  source = "../modules/table"

  name         = "${local.prefix}_test_table"
  catalog_name = local.effective_catalog_name
  schema_name  = module.test_schema[0].name
  table_type   = "MANAGED"
  comment      = "Integration test table"
  warehouse_id = module.test_sql_warehouse.id

  columns = [
    {
      name     = "id"
      type     = "INT"
      comment  = "Primary key"
      nullable = false
    },
    {
      name     = "name"
      type     = "STRING"
      comment  = "Name field"
      nullable = true
    },
    {
      name     = "created_at"
      type     = "TIMESTAMP"
      comment  = "Creation timestamp"
      nullable = true
    }
  ]

  depends_on = [databricks_grants.schema_grants, module.test_schema]
}

# =============================================================================
# UNITY CATALOG: Standalone storage credential + external location
# (when create_test_catalog = false; catalog_creation includes its own otherwise)
# =============================================================================

# =============================================================================
# COMPUTE: Library (install on cluster)
# =============================================================================

module "test_library" {
  count  = var.create_test_cluster ? 1 : 0
  source = "../modules/library"

  cluster_id = module.test_cluster[0].cluster_id
  pypi       = { package = "scikit-learn" }

  depends_on = [module.test_cluster]
}

# =============================================================================
# DATA ENGINEERING: Pipeline (DLT)
# =============================================================================

module "test_pipeline" {
  source = "../modules/pipeline"

  name         = "${local.prefix}-test-pipeline"
  development  = true
  edition      = "ADVANCED"
  photon       = true
  serverless   = true
  channel      = "CURRENT"
  catalog      = local.effective_catalog_name != "" ? local.effective_catalog_name : null
  target       = local.effective_catalog_name != "" ? "${local.prefix}_test_schema" : null
  # Do not set clusters[] — classic DLT cluster config is rejected when serverless = true

  libraries = [
    {
      notebook = { path = module.test_notebook.path }
      file     = null
      jar      = null
      whl      = null
      maven    = null
    }
  ]

  depends_on = [module.test_notebook]
}

# =============================================================================
# ML: Model Serving (conditional - requires registered model)
# =============================================================================

module "test_model_serving" {
  count  = var.model_serving_entity_name != "" ? 1 : 0
  source = "../modules/model-serving"

  name           = "${local.prefix}-test-serving"
  entity_name    = var.model_serving_entity_name
  entity_version = var.model_serving_entity_version
  workload_size  = "Small"
  workload_type  = "CPU"
  scale_to_zero_enabled = true
}

# =============================================================================
# STORAGE: Mount (conditional/legacy - requires S3 bucket)
# =============================================================================

module "test_mount" {
  count  = var.mount_s3_bucket != "" ? 1 : 0
  source = "../modules/mount"

  name = "${local.prefix}-test-mount"
  s3_config = {
    bucket_name      = var.mount_s3_bucket
    instance_profile = var.mount_instance_profile
  }
}

# =============================================================================
# PERMISSIONS: Grant permissions on created resources
# =============================================================================

module "test_cluster_permissions" {
  count  = var.create_test_cluster ? 1 : 0
  source = "../modules/permissions"

  cluster_id = module.test_cluster[0].cluster_id

  access_control_list = [
    {
      group_name       = module.test_group.display_name
      permission_level = "CAN_RESTART"
    }
  ]
}

module "test_job_permissions" {
  source = "../modules/permissions"

  job_id = module.test_job.job_id

  access_control_list = [
    {
      group_name       = module.test_group.display_name
      permission_level = "CAN_MANAGE_RUN"
    }
  ]
}

module "test_sql_warehouse_permissions" {
  source = "../modules/permissions"

  sql_endpoint_id = module.test_sql_warehouse.id

  access_control_list = [
    {
      group_name       = module.test_group.display_name
      permission_level = "CAN_USE"
    }
  ]
}
