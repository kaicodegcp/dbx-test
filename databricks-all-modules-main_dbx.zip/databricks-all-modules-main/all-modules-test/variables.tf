# =============================================================================
# Connection
# =============================================================================

variable "workspace_url" {
  description = "URL of the existing Databricks workspace (from deployment-v2 output)"
  type        = string
  default     = "https://dbc-4caaa24a-edaa.cloud.databricks.com"
}

variable "test_prefix" {
  description = "Prefix for all test resource names (enables parallel runs)"
  type        = string
  default     = "inttest"
}

# =============================================================================
# Compute Defaults
# =============================================================================

variable "node_type_id" {
  description = "EC2 instance type for clusters and instance pools"
  type        = string
  default     = "i3.xlarge"
}

variable "spark_version" {
  description = "Databricks Runtime version"
  type        = string
  default     = "14.3.x-scala2.12"
}

# =============================================================================
# Optional classic compute (global init script, cluster policy, pool, cluster)
# =============================================================================

variable "create_test_global_init_script" {
  description = "Create the global init script module"
  type        = bool
  default     = false
}

variable "create_test_cluster_policy" {
  description = "Create the cluster policy module"
  type        = bool
  default     = false
}

variable "create_test_instance_pool" {
  description = "Create the instance pool module"
  type        = bool
  default     = false
}

variable "create_test_cluster" {
  description = "Create the all-purpose cluster module (also enables library + cluster permissions)"
  type        = bool
  default     = false
}

# =============================================================================
# Identity
# =============================================================================

variable "test_sp_application_id" {
  description = "Application (client) ID for the test service principal"
  type        = string
  default     = "f41c5ff6-58ba-49b7-9524-20f6ee4b20b3"
}

# =============================================================================
# Secrets
# =============================================================================

variable "test_secret_value" {
  description = "Value for the test secret"
  type        = string
  default     = "integration-test-secret-value"
  sensitive   = true
}

# =============================================================================
# Repo (optional)
# =============================================================================

variable "test_repo_url" {
  description = "HTTPS URL of a git repo to import (empty to skip)"
  type        = string
  default     = ""
}

variable "test_repo_provider" {
  description = "Git provider (gitHub, bitbucketCloud, azureDevOpsServices, etc.)"
  type        = string
  default     = "gitHub"
}

variable "test_repo_branch" {
  description = "Branch to check out"
  type        = string
  default     = "main"
}

# =============================================================================
# Unity Catalog (optional - requires catalog from deployment-v2)
# =============================================================================

variable "catalog_name" {
  description = "Existing catalog name for schema tests (empty to skip when not creating test catalog)"
  type        = string
  default     = "terraform_workspace_catalog_7474656999765793"
}

variable "workspace_id" {
  description = "Databricks workspace numeric ID (used for catalog-creation naming when create_test_catalog = true)"
  type        = string
  default     = "7474656999765793"
}

# =============================================================================
# AWS (for creating new UC IAM role and S3 bucket when create_test_catalog = true)
# =============================================================================

variable "aws_region" {
  description = "AWS region for Unity Catalog S3 bucket and IAM role"
  type        = string
  default     = "us-east-1"
}

variable "databricks_aws_account_id" {
  description = "Databricks AWS account ID for IAM role trust policy (Unity Catalog assumes this role)"
  type        = string
  default     = "414351767826" # Databricks UC service account for standard AWS regions
}

variable "unity_catalog_iam_arn" {
  description = "Databricks Unity Catalog master role ARN for IAM trust policy (same as complete-workspace)"
  type        = string
  default     = "arn:aws:iam::414351767826:role/unity-catalog-prod-UCMasterRole-14S5ZJVKOTYTL"
}

# =============================================================================
# Storage Credential / External Location (optional)
# =============================================================================

variable "storage_credential_role_arn" {
  description = "IAM role ARN for storage credential test (empty to skip)"
  type        = string
  default     = "arn:aws:iam::332745928618:role/terraform-workspace-catalog-7474656999765793"
}

variable "external_location_url" {
  description = "S3 URL for external location test (empty to skip)"
  type        = string
  default     = "s3://terraform-workspace-catalog-7474656999765793/test_catalog/"
}

# =============================================================================
# Catalog (optional - creates a test catalog)
# =============================================================================

variable "create_test_catalog" {
  description = "Create a test catalog for catalog module testing"
  type        = bool
  default     = true
}

variable "create_test_table" {
  description = "Create a test table (requires catalog storage accessible by SQL warehouse). Disabled by default due to SQL API timeout; create in Databricks and import if needed."
  type        = bool
  default     = false
}

# =============================================================================
# Model Serving (optional - requires a registered model)
# =============================================================================

variable "model_serving_entity_name" {
  description = "Registered model name for model serving test (empty to skip)"
  type        = string
  default     = ""
}

variable "model_serving_entity_version" {
  description = "Model version for model serving test"
  type        = string
  default     = "1"
}

# =============================================================================
# Mount (optional/legacy - requires S3 bucket)
# =============================================================================

variable "mount_s3_bucket" {
  description = "S3 bucket name for mount test (empty to skip)"
  type        = string
  default     = ""
}

variable "mount_instance_profile" {
  description = "Instance profile ARN for mount test"
  type        = string
  default     = ""
}
